# Build sources

The Android SDK setup used the official Android developer documentation:

1. [Android command-line tools](https://developer.android.com/tools) — documents the `cmdline-tools` package, `sdkmanager`, `ANDROID_HOME`, and SDK package layout.
2. [Android Studio downloads](https://developer.android.com/studio) — official command-line tools download page; the Linux archive used in the sandbox was `https://dl.google.com/android/repository/commandlinetools-linux-15859902_latest.zip`.

Museme’s restored core dependency comes from the project manifest URL:

3. [maxrave-dev/core](https://github.com/maxrave-dev/core) — restored at commit `dae3ce98f8b220f9d40ec9bc8134583f3a14c64b`, matching the uploaded development snapshot’s submodule pointer.
