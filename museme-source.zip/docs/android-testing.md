# Museme Android testing checklist

## Build the debug APK

Open a terminal in the Museme repository and run:

```bash
cp local.properties.example local.properties
# Edit local.properties and set sdk.dir to the Android SDK path on this machine.
./gradlew :androidApp:assembleDebug
```

The expected output is:

```text
androidApp/build/outputs/apk/debug/androidApp-debug.apk
```

If the machine has limited memory, close Android Studio emulators and other JVM processes before building. The source and Android Kotlin compilation pass in the sandbox; the sandbox cannot complete the final `mergeExtDexDebug` task because the dex merger exhausts its constrained memory.

## Install on one device

Enable Developer Options and USB debugging on the Android device, connect it by USB, and verify it appears in ADB:

```bash
adb devices
adb install -r androidApp/build/outputs/apk/debug/androidApp-debug.apk
```

Launch **Museme**, open the People shortcut on the home screen, and verify that the Friends screen opens.

## Local room test

Without a deployed server, leave `MUSEME_ROOM_SERVER_URL` blank. The app uses its in-process development transport. Create a room, confirm the room code and member avatars appear, toggle host play/pause, toggle follow-host, share the room link, and leave the room.

## Two-device realtime test

Run the room server on a reachable development machine:

```bash
./gradlew :friend-room-server:run
```

Set the following in the app’s uncommitted `local.properties` before building:

```properties
MUSEME_ROOM_SERVER_URL=ws://YOUR_DEVELOPMENT_MACHINE_IP:8080
```

Install the APK on two Android devices connected to the same network. On device A, create a room. On device B, enter the displayed code and join. Verify that both devices show two members, that host playback changes appear on device B, that device B cannot control host playback, that leaving updates presence, and that briefly disabling/re-enabling the network reconnects the client to the same room.

For a production deployment, use a `wss://` endpoint, real authentication, TLS, rate limiting, room-size limits, and persistent or coordinated room state. Do not expose the development query-parameter identity to public users.
