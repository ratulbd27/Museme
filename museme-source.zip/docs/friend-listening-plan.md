# Museme Friend Listening Plan

## Purpose

Museme is now a separate branded copy of the uploaded SimpMusic project. This document records a low-risk foundation for adding synchronized listening with friends later. It is a design note only; no friend-listening backend or user-facing feature has been added yet.

## Current project observations

| Area | Current state | Implication for shared listening |
|---|---|---|
| UI and platform | Compose Multiplatform with Android and Desktop targets, plus shared common, Android, iOS, and JVM source sets | Room and player state should be modeled in shared Kotlin code, with platform-specific playback hooks kept behind interfaces |
| Android identity | `com.museme.app` | The new app can receive an independent install identity and future deep links |
| Main UI package | `com.museme.app` | Shared screens, navigation, and view models can be extended without reintroducing the original package |
| Networking | Existing Ktor client usage and service modules are present | A room client can use the project’s existing HTTP stack and add WebSocket support where appropriate |
| Local state | Existing `DataStoreManager` usage is visible in the shared UI layer | Room membership, preferred sync mode, and the last joined room can be persisted locally |
| Playback | The project already contains media-player abstractions and Android Media3-related modules | The synchronizer should control logical playback state rather than directly coupling every screen to a platform player |
| Server dependency | The uploaded archive does not contain the `core` git-submodule contents and does not include a friend-room service | Restore the missing submodule before a complete build; add a separate small room service rather than placing mutable room state in the client |

## MVP experience

A host starts a room from the player, receives a short invite code or share link, and invites friends. A guest joins the room, sees the host’s queue and current track, and can choose whether to follow automatically or listen independently. The host controls the canonical queue and playback position in the first release. Guests can send reactions and request tracks, but those actions do not alter the canonical state unless the host accepts them.

The first version should intentionally avoid synchronized audio streaming. Each participant’s device resolves and plays the same track locally, while the room service distributes only metadata and playback commands. This keeps copyrighted media off the room service and allows the existing media pipeline to remain responsible for fetching and decoding audio.

## Suggested client architecture

The feature should be split into five small responsibilities:

1. `ListeningRoomRepository` owns join, leave, reconnect, and room snapshot operations.
2. `ListeningRoomSocket` translates WebSocket frames into typed room events and sends typed commands.
3. `ListeningRoomState` is a shared immutable state model containing room identity, role, queue, current item, playback status, server clock offset, and connection status.
4. `PlaybackSynchronizer` compares the canonical room position with the local player position and applies bounded corrections.
5. `ListeningRoomViewModel` exposes state and user intents to Compose screens without making the UI aware of transport details.

The existing player should expose a small interface similar to `play(itemId, positionMs)`, `pause()`, `seekTo(positionMs)`, `currentPositionMs()`, and `isPlaying()`. The exact method names should follow the project’s current media-player abstraction once the missing `core` submodule is restored.

## Room state and event model

The server should maintain a canonical, versioned room snapshot. Every mutation increments `revision`; clients ignore stale events and request a fresh snapshot when they detect a gap.

| Message | Direction | Required fields | Purpose |
|---|---|---|---|
| `JoinRoom` | Client to server | room code, user/session ID | Request membership |
| `RoomSnapshot` | Server to client | revision, host ID, queue, current item, position, playing, server timestamp | Establish authoritative state |
| `PlaybackCommand` | Host to server, server broadcast | command ID, revision, action, item ID, position | Play, pause, seek, next, previous |
| `QueueCommand` | Host to server, server broadcast | command ID, revision, operation, item ID/index | Modify the canonical queue |
| `PresenceUpdate` | Client to server, server broadcast | user ID, display name, avatar, connected state | Show who is in the room |
| `Reaction` | Client to server, server broadcast | user ID, emoji or reaction ID, created time | Lightweight social interaction |
| `ResyncRequest` | Client to server | last known revision | Recover after disconnect or missed events |

The service should authenticate the connection, validate that only the host can issue canonical playback commands in the MVP, rate-limit reactions, and expire inactive rooms. Room codes should be random, short-lived, and never serve as a substitute for authentication.

## Synchronization strategy

The host’s commands should be timestamped using server time. A guest calculates an approximate server-clock offset during the connection handshake, then derives the expected position from the latest authoritative event. The client should correct small drift gradually by adjusting playback speed if the player supports it; for larger drift, it should seek directly. A practical initial policy is to ignore drift below roughly 250 ms, correct moderate drift gradually, and hard-seek only when the difference is clearly audible or when the track changes.

Reconnect behavior should be deterministic. On reconnect, the client sends its last known revision and receives either the missed events or a complete `RoomSnapshot`. The local UI should show a reconnecting state and must not silently continue presenting the guest as synchronized when the socket is offline.

## Storage and privacy boundaries

Persist only the minimum local room data: the last room code, the user’s chosen display name, a room preference such as follow mode, and a short-lived session credential if the authentication design requires it. Do not persist raw listening history in the room service unless a future product decision explicitly calls for it. The room service should store room state ephemerally, avoid hosting audio or video, and delete inactive rooms automatically.

## Implementation sequence

| Milestone | Scope | Completion signal |
|---|---|---|
| 1. Restore baseline | Restore the missing `core` submodule and confirm the renamed app configures | Gradle configuration reaches dependency resolution without missing project errors |
| 2. Shared models | Add typed room state, commands, events, and serialization in a shared module | Unit tests cover round trips, revisions, and stale-event rejection |
| 3. Local fake room | Implement an in-process fake transport for development | Two test clients converge on the same snapshot and playback commands |
| 4. Minimal service | Add authenticated room creation, join/leave, snapshots, and WebSocket broadcasting | Android and Desktop clients can join the same room over a test environment |
| 5. Player integration | Add host controls, guest follow mode, drift correction, and reconnect recovery | A host and guest remain acceptably synchronized across pause, seek, and track changes |
| 6. Social layer | Add presence, reactions, invite links, and host moderation | Users can discover room members and safely leave or remove a participant |

## Open product decisions

Before implementation, decide whether rooms are public-by-link or require approval, whether guests may vote on the queue, whether a room should survive the host disconnecting, whether friend relationships require accounts, and whether a guest can temporarily disable synchronization. These decisions affect the authorization model more than the player UI, so they should be settled before choosing a production backend.
