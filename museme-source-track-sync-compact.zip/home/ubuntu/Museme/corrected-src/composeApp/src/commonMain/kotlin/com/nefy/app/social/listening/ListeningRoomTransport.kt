package com.nefy.app.social.listening

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

interface ListeningRoomTransport {
    val events: Flow<ListeningRoomEvent>

    suspend fun send(command: ListeningRoomCommand)

    suspend fun sendSocial(command: NefySocialCommand)
}

/**
 * Local development transport. It behaves like a room server in-process so the UI and controller
 * can be developed without credentials or a running backend. Replace this implementation with a
 * WebSocket transport when the production room service is available.
 */
class LocalListeningRoomTransport : ListeningRoomTransport {
    private val _events = MutableSharedFlow<ListeningRoomEvent>(replay = 1, extraBufferCapacity = 8)
    override val events: Flow<ListeningRoomEvent> = _events.asSharedFlow()

    override suspend fun sendSocial(command: NefySocialCommand) {
        when (command) {
            NefySocialCommand.LoadSocial -> _events.emit(ListeningRoomEvent.SocialSnapshot(NefySocialState()))
            else -> _events.emit(ListeningRoomEvent.Error("Saved social playlists are available when connected to the Nefy server"))
        }
    }

    private var roomState = ListeningRoomState()

    override suspend fun send(command: ListeningRoomCommand) {
        when (command) {
            is ListeningRoomCommand.CreateRoom -> {
                emitConnection(ListeningRoomConnection.Connecting)
                roomState =
                    ListeningRoomState(
                        roomCode = "NEFY01",
                        hostId = "you",
                        currentUserId = "you",
                        members =
                            listOf(
                                ListeningRoomMember("you", command.displayName.ifBlank { "You" }, isHost = true),
                            ),
                        currentTrack = null,
                        queue = emptyList(),
                        queueIndex = -1,
                        isPlaying = false,
                        revision = 1L,
                        connection = ListeningRoomConnection.Connected,
                    )
                emitSnapshot()
            }

            is ListeningRoomCommand.JoinRoom -> {
                emitConnection(ListeningRoomConnection.Connecting)
                roomState =
                    ListeningRoomState(
                        roomCode = command.roomCode.trim().uppercase(),
                        hostId = "host",
                        currentUserId = "you",
                        members =
                            listOf(
                                ListeningRoomMember("host", "Room host", isHost = true),
                                ListeningRoomMember("you", command.displayName.ifBlank { "You" }),
                            ),
                        currentTrack = null,
                        queue = emptyList(),
                        queueIndex = -1,
                        isPlaying = false,
                        revision = 1L,
                        connection = ListeningRoomConnection.Connected,
                    )
                emitSnapshot()
            }

            is ListeningRoomCommand.SetRemoteControl -> {
                roomState =
                    roomState.copy(
                        remoteControlEnabled = command.enabled,
                        revision = roomState.revision + 1,
                    )
                emitSnapshot()
            }

            is ListeningRoomCommand.InviteFriend -> emitSnapshot()

            ListeningRoomCommand.LeaveRoom -> {
                roomState = ListeningRoomState(currentUserId = roomState.currentUserId)
                emitSnapshot()
                emitConnection(ListeningRoomConnection.Disconnected)
            }

            is ListeningRoomCommand.Playback -> {
                if (roomState.roomCode == null) return
                roomState =
                    roomState.copy(
                        isPlaying = command.isPlaying,
                        positionMs = command.positionMs,
                        positionUpdatedAtMs = 0L,
                        revision = roomState.revision + 1,
                    )
                emitSnapshot()
            }

            is ListeningRoomCommand.SetTrack -> {
                if (roomState.roomCode == null) return
                roomState =
                    roomState.copy(
                        currentTrack = command.track,
                        queue = (roomState.queue + command.track).distinctBy { it.videoId },
                        queueIndex = (roomState.queue + command.track).distinctBy { it.videoId }.lastIndex,
                        positionMs = 0L,
                        positionUpdatedAtMs = 0L,
                        isPlaying = true,
                        revision = roomState.revision + 1,
                    )
                emitSnapshot()
            }

            is ListeningRoomCommand.EnqueueTrack -> {
                if (roomState.roomCode == null) return
                roomState = roomState.copy(
                    queue = (roomState.queue + command.track).distinctBy { it.videoId },
                    revision = roomState.revision + 1,
                )
                emitSnapshot()
            }

            is ListeningRoomCommand.RemoveQueueTrack -> {
                if (roomState.roomCode == null || command.videoId == roomState.currentTrack?.videoId) return
                val removedIndex = roomState.queue.indexOfFirst { it.videoId == command.videoId }
                if (removedIndex < 0) return
                val nextQueue = roomState.queue.toMutableList().apply { removeAt(removedIndex) }
                roomState = roomState.copy(
                    queue = nextQueue,
                    queueIndex = (roomState.queueIndex - if (removedIndex < roomState.queueIndex) 1 else 0).coerceAtLeast(-1),
                    revision = roomState.revision + 1,
                )
                emitSnapshot()
            }

            is ListeningRoomCommand.SendChat -> {
                if (roomState.roomCode == null) return
                val message = command.message.trim().take(280)
                if (message.isBlank()) return
                val member = roomState.members.firstOrNull { it.id == roomState.currentUserId }
                roomState = roomState.copy(
                    chatMessages = (roomState.chatMessages + RoomChatMessage("local-${roomState.revision + 1}", roomState.currentUserId, member?.displayName ?: "You", message, System.currentTimeMillis())).takeLast(50),
                    revision = roomState.revision + 1,
                )
                emitSnapshot()
            }

            is ListeningRoomCommand.SendReaction -> {
                if (roomState.roomCode == null) return
                val emoji = command.emoji.trim()
                if (emoji !in setOf("❤", "✨", "🔥", "👏", "😂", "🎵")) return
                val member = roomState.members.firstOrNull { it.id == roomState.currentUserId }
                roomState = roomState.copy(
                    recentReactions = (roomState.recentReactions + RoomReaction("local-${roomState.revision + 1}", roomState.currentUserId, member?.displayName ?: "You", emoji, System.currentTimeMillis())).takeLast(24),
                    revision = roomState.revision + 1,
                )
                emitSnapshot()
            }

            ListeningRoomCommand.SkipNext -> {
                if (roomState.queueIndex < roomState.queue.lastIndex) {
                    val nextIndex = roomState.queueIndex + 1
                    roomState = roomState.copy(
                        queueIndex = nextIndex,
                        currentTrack = roomState.queue[nextIndex],
                        positionMs = 0L,
                        positionUpdatedAtMs = 0L,
                        isPlaying = true,
                        revision = roomState.revision + 1,
                    )
                    emitSnapshot()
                }
            }

            ListeningRoomCommand.SkipPrevious -> {
                val previousIndex = (roomState.queueIndex - 1).coerceAtLeast(0)
                roomState = roomState.copy(
                    queueIndex = previousIndex,
                    currentTrack = roomState.queue.getOrNull(previousIndex) ?: roomState.currentTrack,
                    positionMs = 0L,
                    positionUpdatedAtMs = 0L,
                    revision = roomState.revision + 1,
                )
                emitSnapshot()
            }

            is ListeningRoomCommand.AdvanceQueue -> {
                if (roomState.currentTrack?.videoId != command.expectedTrackId) return
                if (roomState.queueIndex < roomState.queue.lastIndex) {
                    val nextIndex = roomState.queueIndex + 1
                    roomState = roomState.copy(
                        queueIndex = nextIndex,
                        currentTrack = roomState.queue[nextIndex],
                        positionMs = 0L,
                        positionUpdatedAtMs = 0L,
                        isPlaying = true,
                        revision = roomState.revision + 1,
                    )
                } else if (roomState.isPlaying) {
                    roomState = roomState.copy(
                        currentTrack = null,
                        queueIndex = -1,
                        positionMs = 0L,
                        isPlaying = false,
                        revision = roomState.revision + 1,
                    )
                } else {
                    return
                }
                emitSnapshot()
            }

            is ListeningRoomCommand.SetFollowHost -> {
                roomState =
                    roomState.copy(
                        followHost = command.enabled,
                        revision = roomState.revision + 1,
                    )
                emitSnapshot()
            }
        }
    }

    private suspend fun emitConnection(connection: ListeningRoomConnection) {
        _events.emit(ListeningRoomEvent.ConnectionChanged(connection))
    }

    private suspend fun emitSnapshot() {
        _events.emit(ListeningRoomEvent.Snapshot(roomState))
    }

}

class ListeningRoomController(
    private val transport: ListeningRoomTransport,
) {
    private val _state = MutableStateFlow(ListeningRoomState())
    val state = _state.asStateFlow()

    private val _socialState = MutableStateFlow(NefySocialState())
    val socialState = _socialState.asStateFlow()

    private val _invitations = MutableStateFlow<List<RoomInvitation>>(emptyList())
    val invitations = _invitations.asStateFlow()

    private val scope =
        CoroutineScope(SupervisorJob() + Dispatchers.Default).apply {
            launch {
                transport.events.collect { event ->
                    when (event) {
                        is ListeningRoomEvent.Snapshot -> _state.value = event.state.copy(
                            errorMessage = null,
                            snapshotReceivedAtMs = if (event.state.serverTimeMs > 0L) System.currentTimeMillis() else 0L,
                        )
                        is ListeningRoomEvent.ConnectionChanged -> {
                            _state.update {
                                it.copy(
                                    connection = event.connection,
                                    errorMessage = if (event.connection == ListeningRoomConnection.Connected) null else it.errorMessage,
                                )
                            }
                        }
                        is ListeningRoomEvent.Error -> {
                            _state.update { it.copy(errorMessage = event.message) }
                        }
                        is ListeningRoomEvent.SocialSnapshot -> _socialState.value = event.state
                        is ListeningRoomEvent.SocialPresence -> _socialState.update { it.copy(presence = event.presence) }
                        is ListeningRoomEvent.RoomInvitationReceived -> _invitations.update { current ->
                            (current + event.invitation).distinctBy { it.id }.takeLast(10)
                        }
                    }
                }
            }
        }

    fun createRoom(displayName: String) {
        val safeDisplayName = displayName.trim().take(24)
        if (safeDisplayName.isBlank()) {
            _state.update { it.copy(errorMessage = "Enter a display name before creating a room") }
            return
        }
        _state.update { it.copy(connection = ListeningRoomConnection.Connecting, errorMessage = null) }
        scope.launch {
            transport.send(ListeningRoomCommand.CreateRoom(safeDisplayName))
        }
    }

    fun joinRoom(roomCode: String, displayName: String) {
        val safeRoomCode = roomCode.trim().uppercase()
        val safeDisplayName = displayName.trim().take(24)
        if (safeDisplayName.isBlank()) {
            _state.update { it.copy(errorMessage = "Enter a display name before joining a room") }
            return
        }
        if (safeRoomCode.isBlank()) {
            _state.update { it.copy(errorMessage = "Enter a room code before joining") }
            return
        }
        _state.update { it.copy(connection = ListeningRoomConnection.Connecting, errorMessage = null) }
        scope.launch {
            transport.send(ListeningRoomCommand.JoinRoom(safeRoomCode, safeDisplayName))
        }
    }

    fun leaveRoom() {
        scope.launch {
            transport.send(ListeningRoomCommand.LeaveRoom)
        }
    }

    fun acceptInvitation(invitation: RoomInvitation, displayName: String) {
        _invitations.update { current -> current.filterNot { it.id == invitation.id } }
        joinRoom(invitation.roomCode, displayName)
    }

    fun declineInvitation(invitationId: String) {
        if (invitationId.isBlank()) return
        _invitations.update { current -> current.filterNot { it.id == invitationId } }
    }

    fun setPlayback(isPlaying: Boolean, positionMs: Long = _state.value.positionMs) {
        scope.launch {
            transport.send(
                ListeningRoomCommand.Playback(
                    isPlaying = isPlaying,
                    positionMs = positionMs.coerceAtLeast(0L),
                ),
            )
        }
    }

    fun setPlaying(isPlaying: Boolean) = setPlayback(isPlaying)

    fun setTrack(track: ListeningTrack) {
        scope.launch {
            transport.send(ListeningRoomCommand.SetTrack(track))
        }
    }

    fun enqueueTrack(track: ListeningTrack) {
        scope.launch {
            transport.send(ListeningRoomCommand.EnqueueTrack(track))
        }
    }

    fun removeQueueTrack(videoId: String) {
        if (videoId.isBlank()) return
        scope.launch { transport.send(ListeningRoomCommand.RemoveQueueTrack(videoId)) }
    }

    fun inviteFriend(friendUserId: String) {
        if (friendUserId.isBlank()) return
        scope.launch { transport.send(ListeningRoomCommand.InviteFriend(friendUserId)) }
    }

    fun sendChat(message: String) {
        val safeMessage = message.trim().take(280)
        if (safeMessage.isBlank()) return
        scope.launch {
            runCatching {
                transport.send(ListeningRoomCommand.SendChat(safeMessage))
            }.onFailure { error ->
                _state.update { it.copy(errorMessage = error.message ?: "Unable to send the room message") }
            }
        }
    }

    fun sendReaction(emoji: String) {
        if (emoji.isBlank()) return
        scope.launch {
            runCatching {
                transport.send(ListeningRoomCommand.SendReaction(emoji))
            }.onFailure { error ->
                _state.update { it.copy(errorMessage = error.message ?: "Unable to send the room reaction") }
            }
        }
    }

    fun skipNext() {
        scope.launch { transport.send(ListeningRoomCommand.SkipNext) }
    }

    fun skipPrevious() {
        scope.launch { transport.send(ListeningRoomCommand.SkipPrevious) }
    }

    fun advanceQueue(expectedTrackId: String) {
        if (expectedTrackId.isBlank()) return
        scope.launch { transport.send(ListeningRoomCommand.AdvanceQueue(expectedTrackId)) }
    }

    fun setFollowHost(enabled: Boolean) {
        scope.launch {
            transport.send(ListeningRoomCommand.SetFollowHost(enabled))
        }
    }

    fun setRemoteControl(enabled: Boolean) {
        scope.launch {
            transport.send(ListeningRoomCommand.SetRemoteControl(enabled))
        }
    }

    fun loadSocial() {
        scope.launch { transport.sendSocial(NefySocialCommand.LoadSocial) }
    }

    fun createPlaylist(name: String, description: String = "", isPublic: Boolean = false) {
        if (name.trim().isBlank()) return
        scope.launch { transport.sendSocial(NefySocialCommand.CreatePlaylist(name.trim(), description.trim(), isPublic)) }
    }

    fun addPlaylistTrack(playlistId: String, track: ListeningTrack) {
        scope.launch { transport.sendSocial(NefySocialCommand.AddPlaylistTrack(playlistId, track)) }
    }

    fun removePlaylistTrack(playlistId: String, videoId: String) {
        scope.launch { transport.sendSocial(NefySocialCommand.RemovePlaylistTrack(playlistId, videoId)) }
    }

    fun createPlaylistInvite(playlistId: String, role: String = "editor") {
        scope.launch { transport.sendSocial(NefySocialCommand.CreatePlaylistInvite(playlistId, role)) }
    }

    fun joinPlaylistInvite(inviteCode: String) {
        if (inviteCode.trim().isBlank()) return
        scope.launch { transport.sendSocial(NefySocialCommand.JoinPlaylistInvite(inviteCode.trim().uppercase())) }
    }

    fun votePlaylistTrack(playlistId: String, videoId: String, value: Int) {
        if (playlistId.isBlank() || videoId.isBlank()) return
        scope.launch { transport.sendSocial(NefySocialCommand.VotePlaylistTrack(playlistId, videoId, value.coerceIn(-1, 1))) }
    }

    fun setPlaylistSortMode(playlistId: String, sortMode: String) {
        if (playlistId.isBlank()) return
        scope.launch { transport.sendSocial(NefySocialCommand.SetPlaylistSortMode(playlistId, if (sortMode == "ranked") "ranked" else "manual")) }
    }

    fun removePlaylistContributor(playlistId: String, userId: String) {
        if (playlistId.isBlank() || userId.isBlank()) return
        scope.launch { transport.sendSocial(NefySocialCommand.RemovePlaylistContributor(playlistId, userId)) }
    }

    fun leavePlaylist(playlistId: String) {
        if (playlistId.isBlank()) return
        scope.launch { transport.sendSocial(NefySocialCommand.LeavePlaylist(playlistId)) }
    }

    fun updateProfile(displayName: String, handle: String) {
        val safeDisplayName = displayName.trim().take(32)
        val safeHandle = handle.trim().removePrefix("@").lowercase().take(24)
        if (safeDisplayName.isBlank() || safeHandle.isBlank()) return
        scope.launch { transport.sendSocial(NefySocialCommand.UpdateProfile(safeDisplayName, safeHandle)) }
    }

    fun removeFriend(friendUserId: String) {
        if (friendUserId.isBlank()) return
        scope.launch { transport.sendSocial(NefySocialCommand.RemoveFriend(friendUserId)) }
    }

    fun setActivityVisibility(enabled: Boolean) {
        scope.launch { transport.sendSocial(NefySocialCommand.SetActivityVisibility(enabled)) }
    }

    fun searchProfiles(query: String) {
        val normalized = query.trim()
        if (normalized.isBlank()) return
        scope.launch { transport.sendSocial(NefySocialCommand.SearchProfiles(normalized.take(64))) }
    }

    fun sendFriendRequest(targetUserId: String) {
        if (targetUserId.isBlank()) return
        scope.launch { transport.sendSocial(NefySocialCommand.SendFriendRequest(targetUserId)) }
    }

    fun respondFriendRequest(requestId: String, accept: Boolean) {
        if (requestId.isBlank()) return
        scope.launch { transport.sendSocial(NefySocialCommand.RespondFriendRequest(requestId, accept)) }
    }

    fun shareLibraryPlaylist(name: String, description: String, tracks: List<ListeningTrack>) {
        if (name.trim().isBlank()) return
        scope.launch {
            transport.sendSocial(
                NefySocialCommand.CreateLibraryPlaylist(
                    name = name.trim().take(96),
                    description = description.trim().take(500),
                    tracks = tracks,
                ),
            )
        }
    }

    fun updatePresence(track: ListeningTrack?, isPlaying: Boolean, positionMs: Long = 0L) {
        scope.launch {
            transport.sendSocial(
                NefySocialCommand.UpdatePresence(
                    track = track,
                    isPlaying = isPlaying,
                    positionMs = positionMs.coerceAtLeast(0L),
                ),
            )
        }
    }
}
