package com.museme.app.ui.navigation.destination.home

import kotlinx.serialization.Serializable

@Serializable
data class MoodDestination(
    val params: String,
)