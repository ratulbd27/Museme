package com.museme.app.expect

expect fun openUrl(url: String)

expect fun shareUrl(
    title: String,
    url: String,
)