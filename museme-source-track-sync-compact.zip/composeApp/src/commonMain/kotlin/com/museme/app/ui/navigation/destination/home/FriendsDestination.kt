package com.museme.app.ui.navigation.destination.home

import kotlinx.serialization.Serializable

@Serializable
data class FriendsDestination(
    val roomCode: String? = null,
)
