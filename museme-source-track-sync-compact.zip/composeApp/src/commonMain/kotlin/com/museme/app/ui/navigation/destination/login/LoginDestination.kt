package com.museme.app.ui.navigation.destination.login

import kotlinx.serialization.Serializable

@Serializable
data object LoginDestination