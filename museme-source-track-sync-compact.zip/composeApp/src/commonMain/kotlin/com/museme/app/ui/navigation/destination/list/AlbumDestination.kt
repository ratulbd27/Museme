package com.museme.app.ui.navigation.destination.list

import kotlinx.serialization.Serializable

@Serializable
data class AlbumDestination(
    val browseId: String,
)