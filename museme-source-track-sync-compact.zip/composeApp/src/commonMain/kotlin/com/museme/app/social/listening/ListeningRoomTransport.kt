package com.museme.app.social.listening

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

interface ListeningRoomTransport {
    val events: Flow<ListeningRoomEvent>

    suspend fun send(command: ListeningRoomCommand)
}

/**
 * Local development transport. It behaves like a room server in-process so the UI and controller
 * can be developed without credentials or a running backend. Replace this implementation with a
 * WebSocket transport when the production room service is available.
 */
class LocalListeningRoomTransport : ListeningRoomTransport {
    private val _events = MutableSharedFlow<ListeningRoomEvent>(replay = 1, extraBufferCapacity = 8)
    override val events: Flow<ListeningRoomEvent> = _events.asSharedFlow()

    private var roomState = ListeningRoomState()

    override suspend fun send(command: ListeningRoomCommand) {
        when (command) {
            is ListeningRoomCommand.CreateRoom -> {
                emitConnection(ListeningRoomConnection.Connecting)
                roomState =
                    ListeningRoomState(
                        roomCode = "MUSEME",
                        hostId = "you",
                        currentUserId = "you",
                        members =
                            listOf(
                                ListeningRoomMember("you", command.displayName.ifBlank { "You" }, isHost = true),
                                ListeningRoomMember("alex", "Alex"),
                                ListeningRoomMember("jamie", "Jamie"),
                            ),
                        currentTrack = demoTrack,
                        isPlaying = true,
                        revision = 1L,
                        connection = ListeningRoomConnection.Connected,
                    )
                emitSnapshot()
            }

            is ListeningRoomCommand.JoinRoom -> {
                emitConnection(ListeningRoomConnection.Connecting)
                roomState =
                    ListeningRoomState(
                        roomCode = command.roomCode.trim().uppercase(),
                        hostId = "host",
                        currentUserId = "you",
                        members =
                            listOf(
                                ListeningRoomMember("host", "Room host", isHost = true),
                                ListeningRoomMember("you", command.displayName.ifBlank { "You" }),
                                ListeningRoomMember("sam", "Sam"),
                            ),
                        currentTrack = demoTrack,
                        isPlaying = true,
                        revision = 1L,
                        connection = ListeningRoomConnection.Connected,
                    )
                emitSnapshot()
            }

            is ListeningRoomCommand.SetRemoteControl -> {
                roomState =
                    roomState.copy(
                        remoteControlEnabled = command.enabled,
                        revision = roomState.revision + 1,
                    )
                emitSnapshot()
            }

            ListeningRoomCommand.LeaveRoom -> {
                roomState = ListeningRoomState(currentUserId = roomState.currentUserId)
                emitSnapshot()
                emitConnection(ListeningRoomConnection.Disconnected)
            }

            is ListeningRoomCommand.Playback -> {
                if (roomState.roomCode == null) return
                roomState =
                    roomState.copy(
                        isPlaying = command.isPlaying,
                        positionMs = command.positionMs,
                        positionUpdatedAtMs = 0L,
                        revision = roomState.revision + 1,
                    )
                emitSnapshot()
            }

            is ListeningRoomCommand.SetTrack -> {
                if (roomState.roomCode == null) return
                roomState =
                    roomState.copy(
                        currentTrack = command.track,
                        positionMs = 0L,
                        positionUpdatedAtMs = 0L,
                        isPlaying = true,
                        revision = roomState.revision + 1,
                    )
                emitSnapshot()
            }

            is ListeningRoomCommand.SetFollowHost -> {
                roomState =
                    roomState.copy(
                        followHost = command.enabled,
                        revision = roomState.revision + 1,
                    )
                emitSnapshot()
            }
        }
    }

    private suspend fun emitConnection(connection: ListeningRoomConnection) {
        _events.emit(ListeningRoomEvent.ConnectionChanged(connection))
    }

    private suspend fun emitSnapshot() {
        _events.emit(ListeningRoomEvent.Snapshot(roomState))
    }

    private companion object {
        val demoTrack =
            ListeningTrack(
                videoId = "museme-demo",
                title = "Museme Radio",
                artist = "Shared listening session",
                durationMs = 214_000L,
            )
    }
}

class ListeningRoomController(
    private val transport: ListeningRoomTransport,
) {
    private val _state = MutableStateFlow(ListeningRoomState())
    val state = _state.asStateFlow()

    private val scope =
        CoroutineScope(SupervisorJob() + Dispatchers.Default).apply {
            launch {
                transport.events.collect { event ->
                    when (event) {
                        is ListeningRoomEvent.Snapshot -> _state.value = event.state.copy(errorMessage = null)
                        is ListeningRoomEvent.ConnectionChanged -> {
                            _state.update {
                                it.copy(
                                    connection = event.connection,
                                    errorMessage = if (event.connection == ListeningRoomConnection.Connected) null else it.errorMessage,
                                )
                            }
                        }
                        is ListeningRoomEvent.Error -> {
                            _state.update { it.copy(errorMessage = event.message) }
                        }
                    }
                }
            }
        }

    fun createRoom(displayName: String) {
        val safeDisplayName = displayName.trim().take(24)
        if (safeDisplayName.isBlank()) {
            _state.update { it.copy(errorMessage = "Enter a display name before creating a room") }
            return
        }
        _state.update { it.copy(connection = ListeningRoomConnection.Connecting, errorMessage = null) }
        scope.launch {
            transport.send(ListeningRoomCommand.CreateRoom(safeDisplayName))
        }
    }

    fun joinRoom(roomCode: String, displayName: String) {
        val safeRoomCode = roomCode.trim().uppercase()
        val safeDisplayName = displayName.trim().take(24)
        if (safeDisplayName.isBlank()) {
            _state.update { it.copy(errorMessage = "Enter a display name before joining a room") }
            return
        }
        if (safeRoomCode.isBlank()) {
            _state.update { it.copy(errorMessage = "Enter a room code before joining") }
            return
        }
        _state.update { it.copy(connection = ListeningRoomConnection.Connecting, errorMessage = null) }
        scope.launch {
            transport.send(ListeningRoomCommand.JoinRoom(safeRoomCode, safeDisplayName))
        }
    }

    fun leaveRoom() {
        scope.launch {
            transport.send(ListeningRoomCommand.LeaveRoom)
        }
    }

    fun setPlayback(isPlaying: Boolean, positionMs: Long = _state.value.positionMs) {
        scope.launch {
            transport.send(
                ListeningRoomCommand.Playback(
                    isPlaying = isPlaying,
                    positionMs = positionMs.coerceAtLeast(0L),
                ),
            )
        }
    }

    fun setPlaying(isPlaying: Boolean) = setPlayback(isPlaying)

    fun setTrack(track: ListeningTrack) {
        scope.launch {
            transport.send(ListeningRoomCommand.SetTrack(track))
        }
    }

    fun setFollowHost(enabled: Boolean) {
        scope.launch {
            transport.send(ListeningRoomCommand.SetFollowHost(enabled))
        }
    }

    fun setRemoteControl(enabled: Boolean) {
        scope.launch {
            transport.send(ListeningRoomCommand.SetRemoteControl(enabled))
        }
    }
}
