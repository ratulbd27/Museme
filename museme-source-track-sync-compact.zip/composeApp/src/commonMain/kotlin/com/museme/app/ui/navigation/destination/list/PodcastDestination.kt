package com.museme.app.ui.navigation.destination.list

import kotlinx.serialization.Serializable

@Serializable
data class PodcastDestination(
    val podcastId: String,
)