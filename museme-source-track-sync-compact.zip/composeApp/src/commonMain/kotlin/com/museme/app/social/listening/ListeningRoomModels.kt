package com.museme.app.social.listening

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ListeningRoomMember(
    val id: String,
    val displayName: String,
    val isHost: Boolean = false,
    val isOnline: Boolean = true,
)

@Serializable
data class ListeningTrack(
    val videoId: String,
    val title: String,
    val artist: String,
    val artworkUrl: String? = null,
    val durationMs: Long = 0L,
)

@Serializable
enum class ListeningRoomConnection {
    Disconnected,
    Connecting,
    Connected,
    Reconnecting,
}

@Serializable
data class ListeningRoomState(
    val roomCode: String? = null,
    val hostId: String? = null,
    val currentUserId: String = "you",
    val members: List<ListeningRoomMember> = emptyList(),
    val currentTrack: ListeningTrack? = null,
    val queue: List<ListeningTrack> = emptyList(),
    val queueIndex: Int = -1,
    val positionMs: Long = 0L,
    val positionUpdatedAtMs: Long = 0L,
    val isPlaying: Boolean = false,
    val followHost: Boolean = true,
    val remoteControlEnabled: Boolean = true,
    val revision: Long = 0L,
    val connection: ListeningRoomConnection = ListeningRoomConnection.Disconnected,
    val errorMessage: String? = null,
)

@Serializable
sealed class ListeningRoomCommand {
    @Serializable
    @SerialName("create_room")
    data class CreateRoom(
        val displayName: String,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("join_room")
    data class JoinRoom(
        val roomCode: String,
        val displayName: String,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("leave_room")
    data object LeaveRoom : ListeningRoomCommand()

    @Serializable
    @SerialName("playback")
    data class Playback(
        val isPlaying: Boolean,
        val positionMs: Long,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("set_track")
    data class SetTrack(
        val track: ListeningTrack,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("enqueue_track")
    data class EnqueueTrack(
        val track: ListeningTrack,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("skip_next")
    data object SkipNext : ListeningRoomCommand()

    @Serializable
    @SerialName("skip_previous")
    data object SkipPrevious : ListeningRoomCommand()

    @Serializable
    @SerialName("advance_queue")
    data class AdvanceQueue(
        val expectedTrackId: String,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("follow_host")
    data class SetFollowHost(
        val enabled: Boolean,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("remote_control")
    data class SetRemoteControl(
        val enabled: Boolean,
    ) : ListeningRoomCommand()
}

@Serializable
sealed class ListeningRoomEvent {
    @Serializable
    @SerialName("snapshot")
    data class Snapshot(
        val state: ListeningRoomState,
    ) : ListeningRoomEvent()

    @Serializable
    @SerialName("connection")
    data class ConnectionChanged(
        val connection: ListeningRoomConnection,
    ) : ListeningRoomEvent()

    @Serializable
    @SerialName("error")
    data class Error(
        val message: String,
    ) : ListeningRoomEvent()

    @Serializable
    @SerialName("social_snapshot")
    data class SocialSnapshot(
        val state: NefySocialState,
    ) : ListeningRoomEvent()

    @Serializable
    @SerialName("social_presence")
    data class SocialPresence(
        val presence: List<NefyPresence> = emptyList(),
    ) : ListeningRoomEvent()
}
