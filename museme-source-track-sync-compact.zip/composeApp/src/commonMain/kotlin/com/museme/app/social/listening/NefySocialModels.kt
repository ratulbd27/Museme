package com.museme.app.social.listening

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class NefyPlaylistTrack(
    val id: String,
    val videoId: String,
    val title: String,
    val artist: String,
    val artworkUrl: String? = null,
    val durationMs: Long = 0L,
    val position: Int = 0,
    val addedBy: String? = null,
)

@Serializable
data class NefySavedPlaylist(
    val id: String,
    val name: String,
    val description: String = "",
    val ownerId: String,
    val coverArtUrl: String? = null,
    val isPublic: Boolean = false,
    val collaborationEnabled: Boolean = true,
    val tracks: List<NefyPlaylistTrack> = emptyList(),
)

@Serializable
data class NefyFriend(
    val userId: String,
    val displayName: String,
    val handle: String? = null,
    val activityVisible: Boolean = true,
)

@Serializable
data class NefyActivityItem(
    val id: String,
    val actorId: String,
    val actorName: String,
    val eventType: String,
    val playlistId: String? = null,
    val playlistName: String? = null,
    val roomCode: String? = null,
    val track: ListeningTrack? = null,
    val createdAt: String,
)

@Serializable
data class NefyPresence(
    val userId: String,
    val displayName: String,
    val roomCode: String? = null,
    val track: ListeningTrack? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val updatedAt: String? = null,
)

@Serializable
data class NefySocialState(
    val profile: NefyFriend? = null,
    val friends: List<NefyFriend> = emptyList(),
    val playlists: List<NefySavedPlaylist> = emptyList(),
    val activities: List<NefyActivityItem> = emptyList(),
    val presence: List<NefyPresence> = emptyList(),
    val activityVisibleToFriends: Boolean = true,
    val lastInviteCode: String? = null,
    val lastInvitePlaylistId: String? = null,
)

@Serializable
sealed class NefySocialCommand {
    @Serializable
    @SerialName("load_social")
    data object LoadSocial : NefySocialCommand()

    @Serializable
    @SerialName("create_playlist")
    data class CreatePlaylist(
        val name: String,
        val description: String = "",
        val isPublic: Boolean = false,
    ) : NefySocialCommand()

    @Serializable
    @SerialName("add_playlist_track")
    data class AddPlaylistTrack(
        val playlistId: String,
        val track: ListeningTrack,
    ) : NefySocialCommand()

    @Serializable
    @SerialName("remove_playlist_track")
    data class RemovePlaylistTrack(
        val playlistId: String,
        val videoId: String,
    ) : NefySocialCommand()

    @Serializable
    @SerialName("create_playlist_invite")
    data class CreatePlaylistInvite(
        val playlistId: String,
        val role: String = "editor",
    ) : NefySocialCommand()

    @Serializable
    @SerialName("join_playlist_invite")
    data class JoinPlaylistInvite(
        val inviteCode: String,
    ) : NefySocialCommand()

    @Serializable
    @SerialName("set_activity_visibility")
    data class SetActivityVisibility(
        val enabled: Boolean,
    ) : NefySocialCommand()

    @Serializable
    @SerialName("update_presence")
    data class UpdatePresence(
        val track: ListeningTrack? = null,
        val isPlaying: Boolean = false,
        val positionMs: Long = 0L,
    ) : NefySocialCommand()
}
