package com.museme.app.ui.navigation.destination.player

import kotlinx.serialization.Serializable

@Serializable
data object FullscreenDestination