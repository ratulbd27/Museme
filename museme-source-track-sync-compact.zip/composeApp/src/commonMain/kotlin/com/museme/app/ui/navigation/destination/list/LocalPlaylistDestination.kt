package com.museme.app.ui.navigation.destination.list

import kotlinx.serialization.Serializable

@Serializable
data class LocalPlaylistDestination(
    val id: Long,
)