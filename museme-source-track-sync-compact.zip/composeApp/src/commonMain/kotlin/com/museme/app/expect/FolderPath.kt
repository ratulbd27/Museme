package com.museme.app.expect

expect fun getDownloadFolderPath(): String