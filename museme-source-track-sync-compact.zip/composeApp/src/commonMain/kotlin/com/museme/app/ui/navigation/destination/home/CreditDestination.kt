package com.museme.app.ui.navigation.destination.home

import kotlinx.serialization.Serializable

@Serializable
data object CreditDestination