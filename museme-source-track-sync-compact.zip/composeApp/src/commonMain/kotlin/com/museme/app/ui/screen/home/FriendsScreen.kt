package com.museme.app.ui.screen.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.museme.app.expect.shareUrl
import com.museme.app.social.listening.ListeningRoomConnection
import com.museme.app.social.listening.ListeningRoomController
import com.museme.app.social.listening.ListeningRoomState
import com.museme.app.social.listening.ListeningTrack
import com.museme.app.social.listening.NefyActivityItem
import com.museme.app.social.listening.NefyIdentity
import com.museme.app.social.listening.NefySavedPlaylist
import com.museme.app.social.listening.NefySocialState
import com.museme.app.ui.component.RippleIconButton
import com.museme.app.ui.icon.ArrowBackIosNew
import com.museme.app.ui.icon.Pause
import com.museme.app.ui.icon.PeopleAlt
import com.museme.app.ui.icon.PlayArrow
import com.museme.app.ui.icon.Share
import com.museme.app.ui.icon.SkipNext
import com.museme.app.ui.icon.SkipPrevious
import com.museme.app.ui.icon.SimpIcons
import com.museme.app.ui.theme.typo
import com.maxrave.domain.mediaservice.handler.NowPlayingTrackState
import com.museme.app.viewModel.SharedViewModel
import com.museme.app.viewModel.UIEvent
import museme.composeapp.generated.resources.Res
import museme.composeapp.generated.resources.create_listening_room
import museme.composeapp.generated.resources.currently_listening
import museme.composeapp.generated.resources.follow_host
import museme.composeapp.generated.resources.friend_listening
import museme.composeapp.generated.resources.invite_friends
import museme.composeapp.generated.resources.join_room
import museme.composeapp.generated.resources.join_room_description
import museme.composeapp.generated.resources.leave_room
import museme.composeapp.generated.resources.listening_room
import museme.composeapp.generated.resources.listening_room_code
import museme.composeapp.generated.resources.members
import museme.composeapp.generated.resources.no_room_yet
import museme.composeapp.generated.resources.room_code_hint
import museme.composeapp.generated.resources.share_room
import museme.composeapp.generated.resources.start_listening_together
import museme.composeapp.generated.resources.you_are_host
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FriendsScreen(
    navController: NavController,
    initialRoomCode: String? = null,
    roomController: ListeningRoomController = koinInject(),
    sharedViewModel: SharedViewModel = koinInject(),
) {
    val roomState by roomController.state.collectAsStateWithLifecycle()
    val socialState by roomController.socialState.collectAsStateWithLifecycle()
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    val identity: NefyIdentity = koinInject()
    var roomCode by rememberSaveable { mutableStateOf(initialRoomCode.orEmpty()) }
    var displayName by rememberSaveable { mutableStateOf(identity.displayName) }
    var selectedSection by rememberSaveable { mutableStateOf("room") }

    LaunchedEffect(Unit) {
        roomController.loadSocial()
    }

    LaunchedEffect(
        roomState.revision,
        roomState.currentTrack?.videoId,
        roomState.isPlaying,
        roomState.positionMs,
        roomState.positionUpdatedAtMs,
        nowPlayingState?.songEntity?.videoId,
    ) {
        val sharedTrack = roomState.currentTrack
        if (sharedTrack != null && sharedTrack.videoId.isNotBlank() && sharedTrack.videoId != "museme-demo") {
            if (nowPlayingState?.songEntity?.videoId != sharedTrack.videoId) {
                sharedViewModel.loadSharedMediaItem(sharedTrack.videoId)
                delay(900)
            }
            val syncedPosition =
                if (roomState.isPlaying && roomState.positionUpdatedAtMs > 0L) {
                    roomState.positionMs + (System.currentTimeMillis() - roomState.positionUpdatedAtMs).coerceAtLeast(0L)
                } else {
                    roomState.positionMs
                }
            sharedViewModel.applyListeningPlayback(roomState.isPlaying, syncedPosition)
        }
    }

    val canControlRoom = roomState.hostId == roomState.currentUserId || roomState.remoteControlEnabled
    val latestRoomState by rememberUpdatedState(roomState)
    val latestCanControlRoom by rememberUpdatedState(canControlRoom)
    LaunchedEffect(roomState.roomCode) {
        sharedViewModel.playbackEnded.collect { endedTrackId ->
            val activeState = latestRoomState
            if (
                activeState.roomCode != null &&
                latestCanControlRoom &&
                activeState.isPlaying &&
                activeState.currentTrack?.videoId == endedTrackId
            ) {
                roomController.advanceQueue(endedTrackId)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(Res.string.friend_listening),
                        style = typo().titleMedium,
                    )
                },
                navigationIcon = {
                    RippleIconButton(
                        imageVector = SimpIcons.ArrowBackIosNew,
                        tint = MaterialTheme.colorScheme.onSurface,
                        onClick = { navController.navigateUp() },
                    )
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(innerPadding)
                    .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf("room" to "Room", "playlists" to "Playlists", "activity" to "Activity").forEach { (key, label) ->
                    if (selectedSection == key) {
                        Button(onClick = { selectedSection = key }, modifier = Modifier.weight(1f)) { Text(label) }
                    } else {
                        TextButton(onClick = { selectedSection = key }, modifier = Modifier.weight(1f)) { Text(label) }
                    }
                }
            }

            when (selectedSection) {
                "playlists" -> PlaylistsContent(
                    state = socialState,
                    currentTrack = toListeningTrack(nowPlayingState, sharedViewModel) ?: roomState.currentTrack,
                    onCreatePlaylist = { name, description -> roomController.createPlaylist(name, description) },
                    onAddTrack = roomController::addPlaylistTrack,
                    onRemoveTrack = roomController::removePlaylistTrack,
                    onCreateInvite = { playlistId -> roomController.createPlaylistInvite(playlistId) },
                    onJoinInvite = roomController::joinPlaylistInvite,
                )
                "activity" -> ActivityContent(
                    state = socialState,
                    onVisibilityChange = roomController::setActivityVisibility,
                )
                else -> if (roomState.roomCode == null) {
                EmptyRoomContent(
                    displayName = displayName,
                    roomCode = roomCode,
                    onDisplayNameChange = {
                        displayName = it.take(24)
                        identity.setDisplayName(displayName)
                    },
                    onRoomCodeChange = { roomCode = it.uppercase().take(8) },
                    connection = roomState.connection,
                    errorMessage = roomState.errorMessage,
                    onCreateRoom = { roomController.createRoom(displayName) },
                    onJoinRoom = { roomController.joinRoom(roomCode, displayName) },
                )
            } else {
                ActiveRoomContent(
                    state = roomState,
                    onPlayingChange = { isPlaying ->
                        val position = timelineState.current.coerceAtLeast(0L)
                        roomController.setPlayback(isPlaying = isPlaying, positionMs = position)
                        sharedViewModel.applyListeningPlayback(isPlaying, position)
                    },
                    onSeek = { positionMs ->
                        roomController.setPlayback(
                            isPlaying = roomState.isPlaying,
                            positionMs = positionMs,
                        )
                        sharedViewModel.applyListeningPlayback(roomState.isPlaying, positionMs)
                    },
                    onShareTrack = {
                        toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::setTrack)
                    },
                    onEnqueueTrack = {
                        toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::enqueueTrack)
                    },
                    onPlayTrack = roomController::setTrack,
                    onSkipNext = roomController::skipNext,
                    onSkipPrevious = roomController::skipPrevious,
                    onFollowHostChange = roomController::setFollowHost,
                    onRemoteControlChange = roomController::setRemoteControl,
                    onLeaveRoom = roomController::leaveRoom,
                )
            }
        }
    }
}

private fun toListeningTrack(
    current: NowPlayingTrackState?,
    sharedViewModel: SharedViewModel,
): ListeningTrack? {
    val song = current?.songEntity ?: return null
    if (song.videoId.isBlank()) return null
    return ListeningTrack(
        videoId = song.videoId,
        title = song.title,
        artist = song.artistName?.joinToString(", ").orEmpty().ifBlank { "Unknown artist" },
        artworkUrl = current.mediaItem.metadata.artworkUri ?: song.thumbnails,
        durationMs = sharedViewModel.timeline.value.total.takeIf { it > 0L }
            ?: song.durationSeconds.toLong() * 1000L,
    )
}

@Composable
private fun PlaylistsContent(
    state: NefySocialState,
    currentTrack: ListeningTrack?,
    onCreatePlaylist: (String, String) -> Unit,
    onAddTrack: (String, ListeningTrack) -> Unit,
    onRemoveTrack: (String, String) -> Unit,
    onCreateInvite: (String) -> Unit,
    onJoinInvite: (String) -> Unit,
) {
    var playlistName by rememberSaveable { mutableStateOf("") }
    var playlistDescription by rememberSaveable { mutableStateOf("") }
    var inviteCode by rememberSaveable { mutableStateOf("") }
    var expandedPlaylistId by rememberSaveable { mutableStateOf<String?>(null) }

    Text("Saved playlists", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
    Text(
        "Keep a shared collection for your next listening session. Playlists stay private until you share an invite.",
        style = typo().bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Create a playlist", style = typo().titleMedium)
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = playlistName,
                onValueChange = { playlistName = it.take(96) },
                label = { Text("Playlist name") },
                singleLine = true,
            )
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = playlistDescription,
                onValueChange = { playlistDescription = it.take(240) },
                label = { Text("Description (optional)") },
                singleLine = true,
            )
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = playlistName.trim().isNotBlank(),
                onClick = {
                    onCreatePlaylist(playlistName.trim(), playlistDescription.trim())
                    playlistName = ""
                    playlistDescription = ""
                },
            ) {
                Text("Create playlist")
            }
        }
    }

    if (state.playlists.isEmpty()) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                "No saved playlists yet. Create one above, then add the song currently playing.",
                modifier = Modifier.padding(16.dp),
                style = typo().bodyMedium,
            )
        }
    }

    state.playlists.forEach { playlist ->
        PlaylistCard(
            playlist = playlist,
            expanded = expandedPlaylistId == playlist.id,
            currentTrack = currentTrack,
            inviteCode = state.lastInviteCode,
            onExpand = { expandedPlaylistId = if (expandedPlaylistId == playlist.id) null else playlist.id },
            onAddTrack = { track -> onAddTrack(playlist.id, track) },
            onRemoveTrack = { videoId -> onRemoveTrack(playlist.id, videoId) },
            onCreateInvite = { onCreateInvite(playlist.id) },
        )
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Join a shared playlist", style = typo().titleMedium)
            Text(
                "Paste an invite code from a friend to add the playlist to your account.",
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = inviteCode,
                onValueChange = { inviteCode = it.uppercase().take(16) },
                label = { Text("Invite code") },
                singleLine = true,
            )
            FilledTonalButton(
                modifier = Modifier.fillMaxWidth(),
                enabled = inviteCode.trim().isNotBlank(),
                onClick = {
                    onJoinInvite(inviteCode)
                    inviteCode = ""
                },
            ) {
                Text("Join playlist")
            }
        }
    }
}

@Composable
private fun PlaylistCard(
    playlist: NefySavedPlaylist,
    expanded: Boolean,
    currentTrack: ListeningTrack?,
    inviteCode: String?,
    onExpand: () -> Unit,
    onAddTrack: (ListeningTrack) -> Unit,
    onRemoveTrack: (String) -> Unit,
    onCreateInvite: () -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(playlist.name, style = typo().titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        playlist.description.ifBlank { "Collaborative playlist" },
                        style = typo().bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                TextButton(onClick = onExpand) {
                    Text(if (expanded) "Hide" else "Open")
                }
            }
            Text(
                "${playlist.tracks.size} track${if (playlist.tracks.size == 1) "" else "s"} · ${if (playlist.collaborationEnabled) "Shared" else "Private"}",
                style = typo().labelMedium,
                color = MaterialTheme.colorScheme.primary,
            )
            if (expanded) {
                if (playlist.tracks.isEmpty()) {
                    Text("This playlist is empty.", style = typo().bodySmall)
                } else {
                    playlist.tracks.forEach { track ->
                        TextButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { onRemoveTrack(track.videoId) },
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(track.title, style = typo().bodyMedium)
                                Text(track.artist, style = typo().bodySmall)
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(
                        enabled = currentTrack != null,
                        onClick = { currentTrack?.let(onAddTrack) },
                    ) {
                        Text("Add current song")
                    }
                    TextButton(onClick = onCreateInvite) {
                        Icon(imageVector = SimpIcons.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Share")
                    }
                }
                inviteCode?.let { code ->
                    Text(
                        "Invite code: $code",
                        style = typo().labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    TextButton(
                        onClick = {
                            shareUrl(
                                title = "Join my Nefy playlist",
                                url = "nefy://playlist/$code",
                            )
                        },
                    ) {
                        Text("Share invite link")
                    }
                }
                Text(
                    "Tap a track to remove it from this collaborative playlist.",
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ActivityContent(
    state: NefySocialState,
    onVisibilityChange: (Boolean) -> Unit,
) {
    Text("Friend activity", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
    Text(
        "See recent shared listening and playlist changes from people who have access to your social circle.",
        style = typo().bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Activity visibility", style = typo().titleMedium)
                Text(
                    if (state.activityVisibleToFriends) "Friends can see your recent listening" else "Your listening activity is hidden",
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = state.activityVisibleToFriends,
                onCheckedChange = onVisibilityChange,
            )
        }
    }

    if (state.activities.isEmpty()) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                if (state.friends.isEmpty()) {
                    "No activity yet. Share a playlist invite with your girlfriend or a friend to start listening together."
                } else {
                    "Your friends have no recent activity."
                },
                modifier = Modifier.padding(16.dp),
                style = typo().bodyMedium,
            )
        }
    } else {
        state.activities.take(30).forEach { activity ->
            ActivityCard(activity)
        }
    }
}

@Composable
private fun ActivityCard(activity: NefyActivityItem) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(activity.actorName, style = typo().titleMedium, fontWeight = FontWeight.SemiBold)
            Text(activityDescription(activity), style = typo().bodyMedium)
            activity.track?.let { track ->
                Text(
                    "${track.title} · ${track.artist}",
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Text(
                activity.createdAt.replace("T", " ").take(19),
                style = typo().labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private fun activityDescription(activity: NefyActivityItem): String = when (activity.eventType) {
    "playlist_created" -> "created a playlist"
    "track_added" -> "added a song to a playlist"
    "playlist_shared" -> "shared a playlist"
    "now_listening" -> "is listening now"
    else -> activity.eventType.replace('_', ' ')
}

@Composable
private fun EmptyRoomContent(
    displayName: String,
    roomCode: String,
    connection: ListeningRoomConnection,
    errorMessage: String?,
    onDisplayNameChange: (String) -> Unit,
    onRoomCodeChange: (String) -> Unit,
    onCreateRoom: () -> Unit,
    onJoinRoom: () -> Unit,
) {
    val isCreatingRoom = connection == ListeningRoomConnection.Connecting
    val canCreateRoom = displayName.trim().isNotBlank() && !isCreatingRoom
    val canJoinRoom = roomCode.isNotBlank() && displayName.trim().isNotBlank() && !isCreatingRoom

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = SimpIcons.PeopleAlt,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(32.dp),
                )
                Text(
                    text = stringResource(Res.string.start_listening_together),
                    style = typo().headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Text(
                    text = stringResource(Res.string.join_room_description),
                    style = typo().bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
        }

        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = displayName,
            onValueChange = onDisplayNameChange,
            label = { Text("Display name") },
            singleLine = true,
        )
        Button(
            modifier = Modifier.fillMaxWidth(),
            enabled = canCreateRoom,
            onClick = onCreateRoom,
        ) {
            Icon(imageVector = SimpIcons.PeopleAlt, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isCreatingRoom) {
                    "Creating room…"
                } else {
                    stringResource(Res.string.create_listening_room)
                },
            )
        }
        if (connection == ListeningRoomConnection.Reconnecting) {
            Text(
                text = "Connecting to the room server…",
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        errorMessage?.let { message ->
            Text(
                text = message,
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = stringResource(Res.string.no_room_yet),
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.weight(1f))
        }

        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = roomCode,
            onValueChange = onRoomCodeChange,
            label = { Text(stringResource(Res.string.listening_room_code)) },
            placeholder = { Text(stringResource(Res.string.room_code_hint)) },
            singleLine = true,
        )
        FilledTonalButton(
            modifier = Modifier.fillMaxWidth(),
            enabled = canJoinRoom,
            onClick = onJoinRoom,
        ) {
            Text(text = stringResource(Res.string.join_room))
        }
    }
}

@Composable
private fun ActiveRoomContent(
    state: ListeningRoomState,
    onPlayingChange: (Boolean) -> Unit,
    onSeek: (Long) -> Unit,
    onShareTrack: () -> Unit,
    onEnqueueTrack: () -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onFollowHostChange: (Boolean) -> Unit,
    onRemoteControlChange: (Boolean) -> Unit,
    onLeaveRoom: () -> Unit,
) {
    val track = state.currentTrack
    val isHost = state.hostId == state.currentUserId
    val canControl = isHost || state.remoteControlEnabled
    var roomClockMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(state.isPlaying, state.positionUpdatedAtMs, track?.videoId) {
        while (state.isPlaying) {
            roomClockMs = System.currentTimeMillis()
            delay(500L)
        }
    }
    val currentPosition =
        if (state.isPlaying && state.positionUpdatedAtMs > 0L) {
            state.positionMs + (roomClockMs - state.positionUpdatedAtMs).coerceAtLeast(0L)
        } else {
            state.positionMs
        }
    val duration = track?.durationMs?.takeIf { it > 0L }
    var isSeeking by remember { mutableStateOf(false) }
    var pendingSeekMs by remember(track?.videoId) { mutableStateOf(currentPosition) }
    LaunchedEffect(currentPosition, track?.videoId, isSeeking) {
        if (!isSeeking) pendingSeekMs = currentPosition
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = stringResource(Res.string.listening_room), style = typo().headlineSmall)
                Text(
                    text = state.roomCode.orEmpty(),
                    style = typo().titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = when (state.connection) {
                        ListeningRoomConnection.Connected -> "Connected · revision ${state.revision}"
                        ListeningRoomConnection.Connecting -> "Connecting…"
                        ListeningRoomConnection.Reconnecting -> "Reconnecting…"
                        ListeningRoomConnection.Disconnected -> "Disconnected"
                    },
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(
                onClick = {
                    shareUrl(
                        title = "Join my Nefy listening room",
                        url = "nefy://room/${state.roomCode}",
                    )
                },
            ) {
                Icon(imageVector = SimpIcons.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = stringResource(Res.string.share_room))
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(text = stringResource(Res.string.currently_listening), style = typo().labelLarge)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BoxAvatar(label = track?.title?.firstOrNull()?.uppercase() ?: "M")
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = track?.title ?: "Nefy Radio", style = typo().titleMedium)
                        Text(text = track?.artist ?: "Shared listening session", style = typo().bodySmall)
                    }
                    if (canControl) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RippleIconButton(
                                imageVector = SimpIcons.SkipPrevious,
                                tint = MaterialTheme.colorScheme.onSurface,
                                onClick = onSkipPrevious,
                            )
                            RippleIconButton(
                                imageVector = if (state.isPlaying) SimpIcons.Pause else SimpIcons.PlayArrow,
                                tint = MaterialTheme.colorScheme.onSurface,
                                onClick = { onPlayingChange(!state.isPlaying) },
                            )
                            RippleIconButton(
                                imageVector = SimpIcons.SkipNext,
                                tint = MaterialTheme.colorScheme.onSurface,
                                onClick = onSkipNext,
                            )
                        }
                    } else {
                        Text(
                            text = "Host control",
                            style = typo().bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                duration?.let { totalDuration ->
                    Slider(
                        value = pendingSeekMs.coerceIn(0L, totalDuration).toFloat(),
                        onValueChange = { value ->
                            isSeeking = true
                            pendingSeekMs = value.toLong()
                        },
                        onValueChangeFinished = {
                            isSeeking = false
                            if (canControl) onSeek(pendingSeekMs.coerceIn(0L, totalDuration))
                        },
                        valueRange = 0f..totalDuration.toFloat(),
                        enabled = canControl,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = formatRoomTime(pendingSeekMs),
                            style = typo().labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = formatRoomTime(totalDuration),
                            style = typo().labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                if (canControl) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = onShareTrack) {
                            Text("Play for everyone")
                        }
                        TextButton(onClick = onEnqueueTrack) {
                            Text("Add to shared queue")
                        }
                    }
                }
            }
        }

        if (state.queue.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(text = "Shared queue", style = typo().titleMedium)
                    state.queue.take(8).forEachIndexed { index, queuedTrack ->
                        TextButton(
                            onClick = { if (canControl) onPlayTrack(queuedTrack) },
                            enabled = canControl,
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = if (index == state.queueIndex) "Now playing · ${queuedTrack.title}" else queuedTrack.title,
                                    style = typo().bodyMedium,
                                )
                                Text(text = queuedTrack.artist, style = typo().bodySmall)
                            }
                        }
                    }
                }
            }
        }

        Text(text = stringResource(Res.string.members), style = typo().titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            state.members.take(4).forEach { member ->
                BoxAvatar(label = member.displayName.firstOrNull()?.uppercase() ?: "?")
            }
            Text(
                text = if (isHost) stringResource(Res.string.you_are_host) else "Following the host",
                style = typo().bodySmall,
                modifier = Modifier.align(Alignment.CenterVertically),
            )
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = stringResource(Res.string.follow_host), style = typo().titleMedium)
                    Text(
                        text = stringResource(Res.string.invite_friends),
                        style = typo().bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = state.followHost, onCheckedChange = onFollowHostChange)
            }
        }

        if (isHost) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Remote control", style = typo().titleMedium)
                        Text(
                            text = "Allow everyone in this room to play, pause, and choose songs",
                            style = typo().bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = state.remoteControlEnabled,
                        onCheckedChange = onRemoteControlChange,
                    )
                }
            }
        } else {
            Text(
                text = if (state.remoteControlEnabled) {
                    "Remote control is enabled — you can control playback"
                } else {
                    "The host controls playback"
                },
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        TextButton(
            modifier = Modifier.align(Alignment.CenterHorizontally),
            onClick = onLeaveRoom,
        ) {
            Text(text = stringResource(Res.string.leave_room))
        }
    }
}

@Composable
private fun formatRoomTime(milliseconds: Long): String {
    val seconds = (milliseconds.coerceAtLeast(0L) / 1_000L).toInt()
    val minutes = seconds / 60
    val remainder = (seconds % 60).toString().padStart(2, '0')
    return "$minutes:$remainder"
}

@Composable
private fun BoxAvatar(label: String) {
    Surface(
        modifier = Modifier.size(42.dp).clip(CircleShape),
        color = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text = label, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        }
    }
}
