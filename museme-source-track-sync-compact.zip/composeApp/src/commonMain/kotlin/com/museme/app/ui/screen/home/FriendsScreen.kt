package com.museme.app.ui.screen.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import androidx.navigation.NavController
import com.museme.app.expect.shareUrl
import com.museme.app.social.listening.ListeningRoomConnection
import com.museme.app.social.listening.ListeningRoomController
import com.museme.app.social.listening.ListeningRoomState
import com.museme.app.social.listening.ListeningTrack
import com.museme.app.social.listening.NefyActivityItem
import com.museme.app.social.listening.NefyPresence
import com.museme.app.social.listening.NefyFriendRequest
import com.museme.app.social.listening.NefyIdentity
import com.museme.app.social.listening.NefySavedPlaylist
import com.museme.app.social.listening.NefySocialState
import com.museme.app.ui.component.RippleIconButton
import com.museme.app.ui.icon.ArrowBackIosNew
import com.museme.app.ui.icon.Pause
import com.museme.app.ui.icon.PeopleAlt
import com.museme.app.ui.icon.PlayArrow
import com.museme.app.ui.icon.Share
import com.museme.app.ui.icon.SkipNext
import com.museme.app.ui.icon.SkipPrevious
import com.museme.app.ui.icon.SimpIcons
import com.museme.app.ui.navigation.destination.home.FriendsDestination
import com.museme.app.ui.theme.typo
import com.maxrave.domain.data.entities.SongEntity
import com.maxrave.domain.repository.LocalPlaylistRepository
import com.maxrave.domain.mediaservice.handler.NowPlayingTrackState
import com.museme.app.viewModel.NowPlayingBottomSheetViewModel
import com.museme.app.viewModel.SearchScreenUIState
import com.museme.app.viewModel.SearchViewModel
import com.museme.app.viewModel.SharedViewModel
import com.museme.app.viewModel.UIEvent
import museme.composeapp.generated.resources.Res
import museme.composeapp.generated.resources.create_listening_room
import museme.composeapp.generated.resources.currently_listening
import museme.composeapp.generated.resources.follow_host
import museme.composeapp.generated.resources.friend_listening
import museme.composeapp.generated.resources.invite_friends
import museme.composeapp.generated.resources.join_room
import museme.composeapp.generated.resources.join_room_description
import museme.composeapp.generated.resources.leave_room
import museme.composeapp.generated.resources.listening_room
import museme.composeapp.generated.resources.listening_room_code
import museme.composeapp.generated.resources.members
import museme.composeapp.generated.resources.no_room_yet
import museme.composeapp.generated.resources.room_code_hint
import museme.composeapp.generated.resources.share_room
import museme.composeapp.generated.resources.start_listening_together
import museme.composeapp.generated.resources.you_are_host
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FriendsScreen(
    navController: NavController,
    initialRoomCode: String? = null,
    roomController: ListeningRoomController = koinInject(),
    sharedViewModel: SharedViewModel = koinInject(),
) {
    NefyFriendsFoundation(
        navController = navController,
        initialRoomCode = initialRoomCode,
        roomController = roomController,
        sharedViewModel = sharedViewModel,
    )
    return

    val roomState by roomController.state.collectAsStateWithLifecycle()
    val socialState by roomController.socialState.collectAsStateWithLifecycle()
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    val identity: NefyIdentity = koinInject()
    var roomCode by rememberSaveable { mutableStateOf(initialRoomCode.orEmpty()) }
    var displayName by rememberSaveable { mutableStateOf(identity.displayName) }
    var selectedSection by rememberSaveable { mutableStateOf("room") }

    LaunchedEffect(Unit) {
        roomController.loadSocial()
    }

    LaunchedEffect(
        roomState.revision,
        roomState.currentTrack?.videoId,
        roomState.isPlaying,
        roomState.positionMs,
        roomState.positionUpdatedAtMs,
        nowPlayingState?.songEntity?.videoId,
    ) {
        val sharedTrack = roomState.currentTrack
        if (sharedTrack != null && sharedTrack.videoId.isNotBlank() && sharedTrack.videoId != "museme-demo") {
            if (nowPlayingState?.songEntity?.videoId != sharedTrack.videoId) {
                sharedViewModel.loadSharedMediaItem(sharedTrack.videoId)
                delay(900)
            }
            val syncedPosition =
                if (roomState.isPlaying && roomState.positionUpdatedAtMs > 0L) {
                    roomState.positionMs + (System.currentTimeMillis() - roomState.positionUpdatedAtMs).coerceAtLeast(0L)
                } else {
                    roomState.positionMs
                }
            sharedViewModel.applyListeningPlayback(roomState.isPlaying, syncedPosition)
        }
    }

    val canControlRoom = roomState.hostId == roomState.currentUserId || roomState.remoteControlEnabled
    val latestRoomState by rememberUpdatedState(roomState)
    val latestCanControlRoom by rememberUpdatedState(canControlRoom)
    var lastAdvanceRequestTrackId by remember(roomState.roomCode) { mutableStateOf<String?>(null) }
    LaunchedEffect(roomState.currentTrack?.videoId) {
        if (roomState.currentTrack?.videoId != lastAdvanceRequestTrackId) {
            lastAdvanceRequestTrackId = null
        }
    }
    LaunchedEffect(roomState.roomCode) {
        sharedViewModel.playbackEnded.collect { endedTrackId ->
            val activeState = latestRoomState
            if (
                activeState.roomCode != null &&
                latestCanControlRoom &&
                activeState.isPlaying &&
                activeState.currentTrack?.videoId == endedTrackId &&
                lastAdvanceRequestTrackId != endedTrackId
            ) {
                lastAdvanceRequestTrackId = endedTrackId
                roomController.advanceQueue(endedTrackId)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(Res.string.friend_listening),
                        style = typo().titleMedium,
                    )
                },
                navigationIcon = {
                    RippleIconButton(
                        imageVector = SimpIcons.ArrowBackIosNew,
                        tint = MaterialTheme.colorScheme.onSurface,
                        onClick = { navController.navigateUp() },
                    )
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(innerPadding)
                    .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf("room" to "Room", "playlists" to "Playlists", "activity" to "Activity").forEach { (key, label) ->
                    if (selectedSection == key) {
                        Button(onClick = { selectedSection = key }, modifier = Modifier.weight(1f)) { Text(label) }
                    } else {
                        TextButton(onClick = { selectedSection = key }, modifier = Modifier.weight(1f)) { Text(label) }
                    }
                }
            }

            when (selectedSection) {
                "playlists" -> PlaylistsContent(
                    state = socialState,
                    currentTrack = toListeningTrack(nowPlayingState, sharedViewModel) ?: roomState.currentTrack,
                    onCreatePlaylist = { name, description -> roomController.createPlaylist(name, description) },
                    onAddTrack = roomController::addPlaylistTrack,
                    onPlayTrack = { track ->
                        sharedViewModel.loadSharedMediaItem(track.videoId)
                        if (roomState.roomCode != null) roomController.setTrack(track)
                    },
                    onRemoveTrack = roomController::removePlaylistTrack,
                    onCreateInvite = { playlistId -> roomController.createPlaylistInvite(playlistId) },
                    onJoinInvite = roomController::joinPlaylistInvite,
                )
                "activity" -> ActivityContent(
                    state = socialState,
                    onVisibilityChange = roomController::setActivityVisibility,
                )
                else -> if (roomState.roomCode == null) {
                EmptyRoomContent(
                    displayName = displayName,
                    roomCode = roomCode,
                    onDisplayNameChange = {
                        displayName = it.take(24)
                        identity.setDisplayName(displayName)
                    },
                    onRoomCodeChange = { roomCode = it.uppercase().take(8) },
                    connection = roomState.connection,
                    errorMessage = roomState.errorMessage,
                    onCreateRoom = { roomController.createRoom(displayName) },
                    onJoinRoom = { roomController.joinRoom(roomCode, displayName) },
                )
            } else {
                ActiveRoomContent(
                    state = roomState,
                    onPlayingChange = { isPlaying ->
                        val position = timelineState.current.coerceAtLeast(0L)
                        roomController.setPlayback(isPlaying = isPlaying, positionMs = position)
                        sharedViewModel.applyListeningPlayback(isPlaying, position)
                    },
                    onSeek = { positionMs ->
                        roomController.setPlayback(
                            isPlaying = roomState.isPlaying,
                            positionMs = positionMs,
                        )
                        sharedViewModel.applyListeningPlayback(roomState.isPlaying, positionMs)
                    },
                    onShareTrack = {
                        toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::setTrack)
                    },
                    onEnqueueTrack = {
                        toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::enqueueTrack)
                    },
                    onPlayTrack = roomController::setTrack,
                    onSkipNext = roomController::skipNext,
                    onSkipPrevious = roomController::skipPrevious,
                    onFollowHostChange = roomController::setFollowHost,
                    onRemoteControlChange = roomController::setRemoteControl,
                    onAddSong = {},
                    onInviteFriends = {},
                    onLeaveRoom = roomController::leaveRoom,
                )
            }
        }
    }
}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NefyFriendsFoundation(
    navController: NavController,
    initialRoomCode: String?,
    roomController: ListeningRoomController,
    sharedViewModel: SharedViewModel,
) {
    val socialState by roomController.socialState.collectAsStateWithLifecycle()
    val roomState by roomController.state.collectAsStateWithLifecycle()
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    var selectedTab by rememberSaveable { mutableStateOf(if (initialRoomCode.isNullOrBlank()) "friends" else "listen") }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var selectedPresence by remember { mutableStateOf<NefyPresence?>(null) }
    var selectedPlaylistTrack by remember { mutableStateOf<ListeningTrack?>(null) }
    var showRoomSongPicker by rememberSaveable { mutableStateOf(false) }
    var showRoomInviteSheet by rememberSaveable { mutableStateOf(false) }
    val latestRoomState by rememberUpdatedState(roomState)
    val latestCanControlRoom by rememberUpdatedState(roomState.hostId == roomState.currentUserId || roomState.remoteControlEnabled)
    var lastAdvanceRequestTrackId by remember(roomState.roomCode) { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { roomController.loadSocial() }
    LaunchedEffect(roomState.currentTrack?.videoId) {
        if (roomState.currentTrack?.videoId != lastAdvanceRequestTrackId) lastAdvanceRequestTrackId = null
    }
    LaunchedEffect(roomState.roomCode) {
        sharedViewModel.playbackEnded.collect { endedTrackId ->
            val active = latestRoomState
            if (active.roomCode != null && latestCanControlRoom && active.isPlaying && active.currentTrack?.videoId == endedTrackId && lastAdvanceRequestTrackId != endedTrackId) {
                lastAdvanceRequestTrackId = endedTrackId
                roomController.advanceQueue(endedTrackId)
            }
        }
    }
    LaunchedEffect(roomState.revision, roomState.currentTrack?.videoId, roomState.isPlaying, roomState.positionMs, roomState.positionUpdatedAtMs) {
        val sharedTrack = roomState.currentTrack
        if (sharedTrack != null && sharedTrack.videoId.isNotBlank()) {
            if (nowPlayingState?.songEntity?.videoId != sharedTrack.videoId) {
                sharedViewModel.loadSharedMediaItem(sharedTrack.videoId)
                delay(800L)
            }
            val syncedPosition = if (roomState.isPlaying && roomState.positionUpdatedAtMs > 0L) {
                roomState.positionMs + (System.currentTimeMillis() - roomState.positionUpdatedAtMs).coerceAtLeast(0L)
            } else roomState.positionMs
            sharedViewModel.applyListeningPlayback(roomState.isPlaying, syncedPosition)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Friends", style = typo().titleMedium) },
                navigationIcon = {
                    RippleIconButton(
                        imageVector = SimpIcons.ArrowBackIosNew,
                        tint = MaterialTheme.colorScheme.onSurface,
                        onClick = { navController.navigateUp() },
                    )
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                listOf("friends" to "Friends", "requests" to "Requests", "find" to "Find", "activity" to "Activity", "listen" to "Listen").forEach { (key, label) ->
                    if (selectedTab == key) {
                        Button(onClick = { selectedTab = key }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 5.dp)) { Text(label, maxLines = 1) }
                    } else {
                        TextButton(onClick = { selectedTab = key }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 5.dp)) { Text(label, maxLines = 1) }
                    }
                }
            }

            when (selectedTab) {
                "friends" -> {
                    Text("Listening now", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
                    Text("See what accepted friends are playing, paused on, or doing in Nefy.", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val presenceById = socialState.presence.associateBy { it.userId }
                    if (socialState.friends.isEmpty()) {
                        SocialEmptyCard("No friends yet", "Use Find to search by username or friend code.")
                    } else {
                        socialState.friends.forEach { friend ->
                            LiveFriendCard(
                                displayName = friend.displayName,
                                handle = friend.handle,
                                presence = presenceById[friend.userId],
                                onTrackClick = { selectedPresence = presenceById[friend.userId] },
                            )
                        }
                    }
                }
                "requests" -> {
                    Text("Friend requests", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
                    val incoming = socialState.pendingRequests.filter { it.direction == "incoming" }
                    val outgoing = socialState.pendingRequests.filter { it.direction == "outgoing" }
                    if (incoming.isEmpty() && outgoing.isEmpty()) SocialEmptyCard("No pending requests", "Requests will appear here when someone connects with you.")
                    incoming.forEach { request ->
                        FriendRequestCard(
                            request = request,
                            onAccept = { roomController.respondFriendRequest(request.id, true) },
                            onDecline = { roomController.respondFriendRequest(request.id, false) },
                        )
                    }
                    if (outgoing.isNotEmpty()) {
                        Text("Sent", style = typo().titleMedium)
                        outgoing.forEach { request -> FriendRequestCard(request = request, onAccept = null, onDecline = null) }
                    }
                }
                "find" -> {
                    Text("Find friends", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
                    Text("Search a Nefy username, handle, or friend code.", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            modifier = Modifier.weight(1f),
                            value = searchQuery,
                            onValueChange = { searchQuery = it.take(64) },
                            label = { Text("Username or code") },
                            singleLine = true,
                        )
                        Button(onClick = { roomController.searchProfiles(searchQuery) }, enabled = searchQuery.isNotBlank()) { Text("Search") }
                    }
                    if (socialState.searchResults.isEmpty()) {
                        SocialEmptyCard("Search Nefy profiles", "Results will appear here with an Add button.")
                    } else {
                        socialState.searchResults.forEach { result ->
                            SearchResultCard(result.displayName, result.handle, result.friendCode) {
                                roomController.sendFriendRequest(result.userId)
                            }
                        }
                    }
                }
                "activity" -> {
                    Text("Recent activity", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Listening activity", style = typo().titleMedium)
                            Text("Share current or last-played tracks with accepted friends and collaborators.", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = socialState.activityVisibleToFriends, onCheckedChange = roomController::setActivityVisibility)
                    }
                    if (socialState.activities.isEmpty()) SocialEmptyCard("No recent activity", "Songs and shared-playlist events will appear here.")
                    socialState.activities.take(30).forEach { ActivityCard(it) }
                }
                else -> {
                    Text("Listen Together", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
                    Text("The existing synchronized room remains available here. Its redesign is deferred until the profile and friends foundation is approved.", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (roomState.roomCode == null) {
                        TextButton(onClick = { navController.navigate(FriendsDestination(initialRoomCode)) }) { Text("Open room controls") }
                    } else {
                        ActiveRoomContent(
                            state = roomState,
                            onPlayingChange = { isPlaying ->
                                val position = timelineState.current.coerceAtLeast(0L)
                                roomController.setPlayback(isPlaying, position)
                                sharedViewModel.applyListeningPlayback(isPlaying, position)
                            },
                            onSeek = { positionMs -> roomController.setPlayback(roomState.isPlaying, positionMs); sharedViewModel.applyListeningPlayback(roomState.isPlaying, positionMs) },
                            onShareTrack = { toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::setTrack) },
                            onEnqueueTrack = { toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::enqueueTrack) },
                            onPlayTrack = roomController::setTrack,
                            onSkipNext = roomController::skipNext,
                            onSkipPrevious = roomController::skipPrevious,
                            onFollowHostChange = roomController::setFollowHost,
                            onRemoteControlChange = roomController::setRemoteControl,
                            onAddSong = { showRoomSongPicker = true },
                            onInviteFriends = { showRoomInviteSheet = true },
                            onLeaveRoom = roomController::leaveRoom,
                        )
                    }
                }
            }
        }
    }

    selectedPresence?.let { presence ->
        presence.track?.let { track ->
            FriendTrackActionSheet(
                presence = presence,
                onDismiss = { selectedPresence = null },
                onPlay = {
                    sharedViewModel.loadSharedMediaItem(track.videoId)
                    selectedPresence = null
                },
                onAddToPlaylist = { selectedPlaylistTrack = track; selectedPresence = null },
                onListenTogether = {
                    selectedPresence = null
                    selectedTab = "listen"
                },
            )
        }
    }

    if (showRoomSongPicker && roomState.roomCode != null) {
        RoomSongPickerSheet(
            onDismiss = { showRoomSongPicker = false },
            onAddTrack = { track ->
                if (roomState.currentTrack == null) roomController.setTrack(track) else roomController.enqueueTrack(track)
            },
        )
    }

    if (showRoomInviteSheet && roomState.roomCode != null) {
        RoomInviteSheet(
            friends = socialState.friends,
            roomCode = roomState.roomCode.orEmpty(),
            onDismiss = { showRoomInviteSheet = false },
        )
    }

    selectedPlaylistTrack?.let { track ->
        ModalBottomSheet(onDismissRequest = { selectedPlaylistTrack = null }) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Add to a shared Nefy playlist", style = typo().headlineSmall)
                if (socialState.playlists.isEmpty()) {
                    Text("Create or join a collaborative Library playlist first.", style = typo().bodyMedium)
                } else {
                    socialState.playlists.forEach { playlist ->
                        TextButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                roomController.addPlaylistTrack(playlist.id, track)
                                selectedPlaylistTrack = null
                            },
                        ) { Text(playlist.name, modifier = Modifier.fillMaxWidth()) }
                    }
                }
                TextButton(onClick = { selectedPlaylistTrack = null }) { Text("Cancel") }
            }
        }
    }
}

@Composable
private fun LiveFriendCard(
    displayName: String,
    handle: String?,
    presence: NefyPresence?,
    onTrackClick: () -> Unit,
) {
    val track = presence?.track
    val status = when {
        presence?.isPlaying == true -> "Listening now"
        track != null -> "Paused"
        presence != null -> "Online"
        else -> "Offline"
    }
    Card(
        modifier = Modifier.fillMaxWidth().clickable(enabled = track != null, onClick = onTrackClick),
        colors = CardDefaults.cardColors(
            containerColor = when {
                presence?.isPlaying == true -> MaterialTheme.colorScheme.primaryContainer
                track != null -> MaterialTheme.colorScheme.surfaceVariant
                else -> MaterialTheme.colorScheme.surface
            },
        ),
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BoxAvatar(label = displayName.take(1).uppercase())
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(displayName, style = typo().titleMedium, fontWeight = FontWeight.SemiBold)
                Text(handle?.let { "@$it" } ?: status, style = typo().labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (track != null) {
                    Text(track.title, style = typo().bodyMedium, maxLines = 1)
                    Text(track.artist, style = typo().bodySmall, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Text(if (presence == null) "Last seen unavailable" else status, style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text(status, style = typo().labelSmall, color = if (presence?.isPlaying == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FriendTrackActionSheet(
    presence: NefyPresence,
    onDismiss: () -> Unit,
    onPlay: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onListenTogether: () -> Unit,
) {
    val track = presence.track ?: return
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(presence.displayName, style = typo().titleLarge, fontWeight = FontWeight.Bold)
            Text("Go to profile", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    BoxAvatar(label = track.title.take(1).uppercase())
                    Column {
                        Text(track.title, style = typo().titleMedium)
                        Text(track.artist, style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(if (presence.isPlaying) "Listening now" else "Paused", style = typo().labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            Button(onClick = onPlay, modifier = Modifier.fillMaxWidth()) { Text("Play") }
            FilledTonalButton(onClick = onAddToPlaylist, modifier = Modifier.fillMaxWidth()) { Text("Add to playlist") }
            TextButton(onClick = onListenTogether, modifier = Modifier.fillMaxWidth()) { Text("Listen together") }
            TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Close") }
        }
    }
}

@Composable
private fun FriendRequestCard(
    request: NefyFriendRequest,
    onAccept: (() -> Unit)?,
    onDecline: (() -> Unit)?,
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BoxAvatar(label = request.displayName.take(1).uppercase())
            Column(modifier = Modifier.weight(1f)) {
                Text(request.displayName, style = typo().titleMedium)
                Text(request.handle?.let { "@$it" } ?: "Friend code · ${request.friendCode.orEmpty()}", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(if (request.direction == "incoming") "Wants to connect" else "Request sent", style = typo().labelSmall)
            }
            if (onAccept != null && onDecline != null) {
                Column {
                    Button(onClick = onAccept, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Accept") }
                    TextButton(onClick = onDecline, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Decline") }
                }
            }
        }
    }
}

@Composable
private fun SearchResultCard(
    displayName: String,
    handle: String?,
    friendCode: String?,
    onAdd: () -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            BoxAvatar(label = displayName.take(1).uppercase())
            Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                Text(displayName, style = typo().titleMedium)
                Text(handle?.let { "@$it" } ?: "Friend code · ${friendCode.orEmpty()}", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            FilledTonalButton(onClick = onAdd) { Text("Add") }
        }
    }
}

@Composable
private fun SocialEmptyCard(title: String, subtitle: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = typo().titleMedium, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = typo().bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun toListeningTrack(
    current: NowPlayingTrackState?,
    sharedViewModel: SharedViewModel,
): ListeningTrack? {
    val song = current?.songEntity ?: return null
    if (song.videoId.isBlank()) return null
    return ListeningTrack(
        videoId = song.videoId,
        title = song.title,
        artist = song.artistName?.joinToString(", ").orEmpty().ifBlank { "Unknown artist" },
        artworkUrl = current.mediaItem.metadata.artworkUri ?: song.thumbnails,
        durationMs = sharedViewModel.timeline.value.total.takeIf { it > 0L }
            ?: song.durationSeconds.toLong() * 1000L,
    )
}

@Composable
private fun PlaylistsContent(
    state: NefySocialState,
    currentTrack: ListeningTrack?,
    onCreatePlaylist: (String, String) -> Unit,
    onAddTrack: (String, ListeningTrack) -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onRemoveTrack: (String, String) -> Unit,
    onCreateInvite: (String) -> Unit,
    onJoinInvite: (String) -> Unit,
) {
    var playlistName by rememberSaveable { mutableStateOf("") }
    var playlistDescription by rememberSaveable { mutableStateOf("") }
    var inviteCode by rememberSaveable { mutableStateOf("") }
    var expandedPlaylistId by rememberSaveable { mutableStateOf<String?>(null) }

    Text("Saved playlists", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
    Text(
        "Keep a shared collection for your next listening session. Playlists stay private until you share an invite.",
        style = typo().bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Create a playlist", style = typo().titleMedium)
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = playlistName,
                onValueChange = { playlistName = it.take(96) },
                label = { Text("Playlist name") },
                singleLine = true,
            )
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = playlistDescription,
                onValueChange = { playlistDescription = it.take(240) },
                label = { Text("Description (optional)") },
                singleLine = true,
            )
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = playlistName.trim().isNotBlank(),
                onClick = {
                    onCreatePlaylist(playlistName.trim(), playlistDescription.trim())
                    playlistName = ""
                    playlistDescription = ""
                },
            ) {
                Text("Create playlist")
            }
        }
    }

    if (state.playlists.isEmpty()) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                "No saved playlists yet. Create one above, then add the song currently playing.",
                modifier = Modifier.padding(16.dp),
                style = typo().bodyMedium,
            )
        }
    }

    state.playlists.forEach { playlist ->
        PlaylistCard(
            playlist = playlist,
            expanded = expandedPlaylistId == playlist.id,
            currentTrack = currentTrack,
            inviteCode = if (state.lastInvitePlaylistId == playlist.id) state.lastInviteCode else null,
            onExpand = { expandedPlaylistId = if (expandedPlaylistId == playlist.id) null else playlist.id },
            onAddTrack = { track -> onAddTrack(playlist.id, track) },
            onPlayTrack = onPlayTrack,
            onRemoveTrack = { videoId -> onRemoveTrack(playlist.id, videoId) },
            onCreateInvite = { onCreateInvite(playlist.id) },
        )
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Join a shared playlist", style = typo().titleMedium)
            Text(
                "Paste an invite code from a friend to add the playlist to your account.",
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = inviteCode,
                onValueChange = { inviteCode = it.uppercase().take(16) },
                label = { Text("Invite code") },
                singleLine = true,
            )
            FilledTonalButton(
                modifier = Modifier.fillMaxWidth(),
                enabled = inviteCode.trim().isNotBlank(),
                onClick = {
                    onJoinInvite(inviteCode)
                    inviteCode = ""
                },
            ) {
                Text("Join playlist")
            }
        }
    }
}

@Composable
private fun PlaylistCard(
    playlist: NefySavedPlaylist,
    expanded: Boolean,
    currentTrack: ListeningTrack?,
    inviteCode: String?,
    onExpand: () -> Unit,
    onAddTrack: (ListeningTrack) -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onRemoveTrack: (String) -> Unit,
    onCreateInvite: () -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Surface(
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)),
                    color = MaterialTheme.colorScheme.primaryContainer,
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            playlist.name.take(2).uppercase(),
                            style = typo().titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(playlist.name, style = typo().titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        playlist.description.ifBlank { "Collaborative playlist" },
                        style = typo().bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        "${playlist.tracks.size} songs · ${if (playlist.collaborationEnabled) "Shared" else "Private"}",
                        style = typo().labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                TextButton(onClick = onExpand) {
                    Text(if (expanded) "Hide" else "Open")
                }
            }
            if (expanded) {
                if (playlist.tracks.isEmpty()) {
                    Text("This playlist is empty.", style = typo().bodySmall)
                } else {
                    playlist.tracks.forEach { track ->
                        val playableTrack = ListeningTrack(
                            videoId = track.videoId,
                            title = track.title,
                            artist = track.artist,
                            artworkUrl = track.artworkUrl,
                            durationMs = track.durationMs,
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            TextButton(
                                modifier = Modifier.weight(1f),
                                onClick = { onPlayTrack(playableTrack) },
                            ) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Text(track.title, style = typo().bodyMedium)
                                    Text(track.artist, style = typo().bodySmall)
                                }
                            }
                            TextButton(onClick = { onRemoveTrack(track.videoId) }) {
                                Text("Remove")
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(
                        enabled = currentTrack != null,
                        onClick = { currentTrack?.let(onAddTrack) },
                    ) {
                        Text("Add current song")
                    }
                    TextButton(onClick = onCreateInvite) {
                        Icon(imageVector = SimpIcons.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Share")
                    }
                }
                inviteCode?.let { code ->
                    Text(
                        "Invite code: $code",
                        style = typo().labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    TextButton(
                        onClick = {
                            shareUrl(
                                title = "Join my Nefy playlist",
                                url = "nefy://playlist/$code",
                            )
                        },
                    ) {
                        Text("Share invite link")
                    }
                }
                Text(
                    "Tap a track to remove it from this collaborative playlist.",
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ActivityContent(
    state: NefySocialState,
    onVisibilityChange: (Boolean) -> Unit,
) {
    Text("Friend activity", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
    Text(
        "See who is listening now, whether they are playing or paused, and what your shared circle changed recently.",
        style = typo().bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    Text("Listening now", style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
    val currentUserId = state.profile?.userId
    val liveFriends = state.presence.filter { it.userId != currentUserId && it.track != null }
    if (liveFriends.isEmpty()) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                if (state.friends.isEmpty()) {
                    "Invite someone to a shared playlist or listening room to see their live status here."
                } else {
                    "No friends are listening right now. Their current song will appear here as soon as they start or pause playback."
                },
                modifier = Modifier.padding(16.dp),
                style = typo().bodyMedium,
            )
        }
    } else {
        liveFriends.forEach { presence ->
            LivePresenceCard(presence)
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Activity visibility", style = typo().titleMedium)
                Text(
                    if (state.activityVisibleToFriends) "Friends and shared-playlist collaborators can see your live status" else "Your listening activity is hidden",
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = state.activityVisibleToFriends,
                onCheckedChange = onVisibilityChange,
            )
        }
    }

    Text("Recent activity", style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
    if (state.activities.isEmpty()) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                "Playlist edits and room listening events will appear here.",
                modifier = Modifier.padding(16.dp),
                style = typo().bodyMedium,
            )
        }
    } else {
        state.activities.take(30).forEach { activity ->
            ActivityCard(activity)
        }
    }
}

@Composable
private fun LivePresenceCard(presence: NefyPresence) {
    val track = presence.track ?: return
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (presence.isPlaying) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            },
        ),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            BoxAvatar(label = presence.displayName.firstOrNull()?.uppercase() ?: "?")
            Column(modifier = Modifier.weight(1f)) {
                Text(presence.displayName, style = typo().titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    if (presence.isPlaying) "Listening now" else "Paused",
                    style = typo().labelMedium,
                    color = if (presence.isPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(track.title, style = typo().bodyMedium, maxLines = 1)
                Text(track.artist, style = typo().bodySmall, maxLines = 1)
            }
            Text(
                if (presence.isPlaying) "PLAYING" else "PAUSED",
                style = typo().labelSmall,
                color = if (presence.isPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ActivityCard(activity: NefyActivityItem) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(activity.actorName, style = typo().titleMedium, fontWeight = FontWeight.SemiBold)
            Text(activityDescription(activity), style = typo().bodyMedium)
            activity.track?.let { track ->
                Text(
                    "${track.title} · ${track.artist}",
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Text(
                activity.createdAt.replace("T", " ").take(19),
                style = typo().labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private fun activityDescription(activity: NefyActivityItem): String = when (activity.eventType) {
    "playlist_created" -> "created a playlist"
    "track_added" -> "added a song to a playlist"
    "playlist_shared" -> "shared a playlist"
    "now_listening" -> "is listening now"
    else -> activity.eventType.replace('_', ' ')
}

@Composable
private fun EmptyRoomContent(
    displayName: String,
    roomCode: String,
    connection: ListeningRoomConnection,
    errorMessage: String?,
    onDisplayNameChange: (String) -> Unit,
    onRoomCodeChange: (String) -> Unit,
    onCreateRoom: () -> Unit,
    onJoinRoom: () -> Unit,
) {
    val isCreatingRoom = connection == ListeningRoomConnection.Connecting
    val canCreateRoom = displayName.trim().isNotBlank() && !isCreatingRoom
    val canJoinRoom = roomCode.isNotBlank() && displayName.trim().isNotBlank() && !isCreatingRoom

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = SimpIcons.PeopleAlt,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(32.dp),
                )
                Text(
                    text = stringResource(Res.string.start_listening_together),
                    style = typo().headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Text(
                    text = stringResource(Res.string.join_room_description),
                    style = typo().bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
        }

        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = displayName,
            onValueChange = onDisplayNameChange,
            label = { Text("Display name") },
            singleLine = true,
        )
        Button(
            modifier = Modifier.fillMaxWidth(),
            enabled = canCreateRoom,
            onClick = onCreateRoom,
        ) {
            Icon(imageVector = SimpIcons.PeopleAlt, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isCreatingRoom) {
                    "Creating room…"
                } else {
                    stringResource(Res.string.create_listening_room)
                },
            )
        }
        if (connection == ListeningRoomConnection.Reconnecting) {
            Text(
                text = "Connecting to the room server…",
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        errorMessage?.let { message ->
            Text(
                text = message,
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = stringResource(Res.string.no_room_yet),
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.weight(1f))
        }

        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = roomCode,
            onValueChange = onRoomCodeChange,
            label = { Text(stringResource(Res.string.listening_room_code)) },
            placeholder = { Text(stringResource(Res.string.room_code_hint)) },
            singleLine = true,
        )
        FilledTonalButton(
            modifier = Modifier.fillMaxWidth(),
            enabled = canJoinRoom,
            onClick = onJoinRoom,
        ) {
            Text(text = stringResource(Res.string.join_room))
        }
    }
}

@Composable
private fun ActiveRoomContent(
    state: ListeningRoomState,
    onPlayingChange: (Boolean) -> Unit,
    onSeek: (Long) -> Unit,
    onShareTrack: () -> Unit,
    onEnqueueTrack: () -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onFollowHostChange: (Boolean) -> Unit,
    onRemoteControlChange: (Boolean) -> Unit,
    onAddSong: () -> Unit,
    onInviteFriends: () -> Unit,
    onLeaveRoom: () -> Unit,
) {
    val track = state.currentTrack
    val isHost = state.hostId == state.currentUserId
    val canControl = isHost || state.remoteControlEnabled
    var roomClockMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(state.isPlaying, state.positionUpdatedAtMs, track?.videoId) {
        while (state.isPlaying) {
            roomClockMs = System.currentTimeMillis()
            delay(500L)
        }
    }
    val currentPosition =
        if (state.isPlaying && state.positionUpdatedAtMs > 0L) {
            state.positionMs + (roomClockMs - state.positionUpdatedAtMs).coerceAtLeast(0L)
        } else {
            state.positionMs
        }
    val duration = track?.durationMs?.takeIf { it > 0L }
    var isSeeking by remember { mutableStateOf(false) }
    var pendingSeekMs by remember(track?.videoId) { mutableStateOf(currentPosition) }
    LaunchedEffect(currentPosition, track?.videoId, isSeeking) {
        if (!isSeeking) pendingSeekMs = currentPosition
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = stringResource(Res.string.listening_room), style = typo().headlineSmall)
                Text(
                    text = state.roomCode.orEmpty(),
                    style = typo().titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = when (state.connection) {
                        ListeningRoomConnection.Connected -> "Connected · revision ${state.revision}"
                        ListeningRoomConnection.Connecting -> "Connecting…"
                        ListeningRoomConnection.Reconnecting -> "Reconnecting…"
                        ListeningRoomConnection.Disconnected -> "Disconnected"
                    },
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = onInviteFriends) {
                    Icon(imageVector = SimpIcons.PeopleAlt, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Invite")
                }
                TextButton(
                    onClick = {
                        shareUrl(
                            title = "Join my Nefy listening room",
                            url = "nefy://room/${state.roomCode}",
                        )
                    },
                ) {
                    Icon(imageVector = SimpIcons.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share")
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(text = stringResource(Res.string.currently_listening), style = typo().labelLarge)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(
                        model = track?.artworkUrl,
                        contentDescription = track?.title,
                        modifier = Modifier.size(88.dp).clip(RoundedCornerShape(18.dp)),
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(text = track?.title ?: "Waiting for a song", style = typo().titleMedium, maxLines = 2)
                        Text(text = track?.artist ?: "Add a song from Nefy Search or Library", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                    }
                    if (canControl) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RippleIconButton(
                                imageVector = SimpIcons.SkipPrevious,
                                tint = MaterialTheme.colorScheme.onSurface,
                                onClick = onSkipPrevious,
                            )
                            RippleIconButton(
                                imageVector = if (state.isPlaying) SimpIcons.Pause else SimpIcons.PlayArrow,
                                tint = MaterialTheme.colorScheme.onSurface,
                                onClick = { onPlayingChange(!state.isPlaying) },
                            )
                            RippleIconButton(
                                imageVector = SimpIcons.SkipNext,
                                tint = MaterialTheme.colorScheme.onSurface,
                                onClick = onSkipNext,
                            )
                        }
                    } else {
                        Text(
                            text = "Host control",
                            style = typo().bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                duration?.let { totalDuration ->
                    Slider(
                        value = pendingSeekMs.coerceIn(0L, totalDuration).toFloat(),
                        onValueChange = { value ->
                            isSeeking = true
                            pendingSeekMs = value.toLong()
                        },
                        onValueChangeFinished = {
                            isSeeking = false
                            if (canControl) onSeek(pendingSeekMs.coerceIn(0L, totalDuration))
                        },
                        valueRange = 0f..totalDuration.toFloat(),
                        enabled = canControl,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = formatRoomTime(pendingSeekMs),
                            style = typo().labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = formatRoomTime(totalDuration),
                            style = typo().labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onAddSong) {
                        Icon(imageVector = SimpIcons.PeopleAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add song")
                    }
                    if (track != null && canControl) {
                        TextButton(onClick = onEnqueueTrack) { Text("Queue current") }
                    }
                }
            }
        }

        if (state.queue.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(text = "Shared queue", style = typo().titleMedium)
                    state.queue.take(8).forEachIndexed { index, queuedTrack ->
                        TextButton(
                            onClick = { if (canControl) onPlayTrack(queuedTrack) },
                            enabled = canControl,
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = if (index == state.queueIndex) "Now playing · ${queuedTrack.title}" else queuedTrack.title,
                                    style = typo().bodyMedium,
                                )
                                Text(text = queuedTrack.artist, style = typo().bodySmall)
                            }
                        }
                    }
                }
            }
        }

        Text(text = stringResource(Res.string.members), style = typo().titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            state.members.take(4).forEach { member ->
                BoxAvatar(label = member.displayName.firstOrNull()?.uppercase() ?: "?")
            }
            Text(
                text = if (isHost) stringResource(Res.string.you_are_host) else "Following the host",
                style = typo().bodySmall,
                modifier = Modifier.align(Alignment.CenterVertically),
            )
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = stringResource(Res.string.follow_host), style = typo().titleMedium)
                    Text(
                        text = stringResource(Res.string.invite_friends),
                        style = typo().bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = state.followHost, onCheckedChange = onFollowHostChange)
            }
        }

        if (isHost) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Remote control", style = typo().titleMedium)
                        Text(
                            text = "Allow everyone in this room to play, pause, and choose songs",
                            style = typo().bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = state.remoteControlEnabled,
                        onCheckedChange = onRemoteControlChange,
                    )
                }
            }
        } else {
            Text(
                text = if (state.remoteControlEnabled) {
                    "Remote control is enabled — you can control playback"
                } else {
                    "The host controls playback"
                },
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        TextButton(
            modifier = Modifier.align(Alignment.CenterHorizontally),
            onClick = onLeaveRoom,
        ) {
            Text(text = stringResource(Res.string.leave_room))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoomSongPickerSheet(
    onDismiss: () -> Unit,
    onAddTrack: (ListeningTrack) -> Unit,
    searchViewModel: SearchViewModel = koinInject(),
    libraryViewModel: NowPlayingBottomSheetViewModel = koinInject(),
    localPlaylistRepository: LocalPlaylistRepository = koinInject(),
) {
    val searchState by searchViewModel.searchScreenState.collectAsStateWithLifecycle()
    val searchUiState by searchViewModel.searchScreenUIState.collectAsStateWithLifecycle()
    val libraryState by libraryViewModel.uiState.collectAsStateWithLifecycle()
    var source by rememberSaveable { mutableStateOf("search") }
    var query by rememberSaveable { mutableStateOf("") }
    var selectedPlaylistId by rememberSaveable { mutableStateOf<Long?>(null) }
    var selectedPlaylistTitle by rememberSaveable { mutableStateOf("") }
    var libraryTracks by remember { mutableStateOf<List<SongEntity>>(emptyList()) }

    LaunchedEffect(selectedPlaylistId) {
        libraryTracks = selectedPlaylistId?.let { localPlaylistRepository.getFullPlaylistTracks(it) }.orEmpty()
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier.fillMaxWidth().heightIn(max = 640.dp).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Add to shared queue", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
            Text("Choose music already available in Nefy.", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (source == "search") Button(onClick = { source = "search" }, modifier = Modifier.weight(1f)) { Text("Search Nefy") }
                else TextButton(onClick = { source = "search" }, modifier = Modifier.weight(1f)) { Text("Search Nefy") }
                if (source == "library") Button(onClick = { source = "library" }, modifier = Modifier.weight(1f)) { Text("Library") }
                else TextButton(onClick = { source = "library" }, modifier = Modifier.weight(1f)) { Text("Library") }
            }

            if (source == "search") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it.take(80) },
                        modifier = Modifier.weight(1f),
                        label = { Text("Song or artist") },
                        singleLine = true,
                    )
                    Button(onClick = { searchViewModel.searchSongs(query) }, enabled = query.trim().isNotBlank()) { Text("Search") }
                }
                when (searchUiState) {
                    SearchScreenUIState.Loading -> Text("Searching Nefy…", style = typo().bodySmall)
                    SearchScreenUIState.Error -> Text("Nefy search failed. Try again.", style = typo().bodySmall, color = MaterialTheme.colorScheme.error)
                    else -> Unit
                }
                if (searchState.searchSongsResult.isEmpty() && searchUiState != SearchScreenUIState.Loading) {
                    SocialEmptyCard("Search for a song", "Results from Nefy will appear here.")
                } else {
                    searchState.searchSongsResult.take(30).forEach { result ->
                        val track = ListeningTrack(
                            videoId = result.videoId,
                            title = result.title.orEmpty().ifBlank { "Untitled" },
                            artist = result.artists?.joinToString(", ") { it.name }.orEmpty().ifBlank { "Unknown artist" },
                            artworkUrl = result.thumbnails?.maxByOrNull { it.width }?.url,
                            durationMs = result.durationSeconds?.toLong()?.times(1000L) ?: 0L,
                        )
                        RoomPickerTrackRow(track = track, actionLabel = "Add", onAction = { onAddTrack(track) })
                    }
                }
            } else if (selectedPlaylistId == null) {
                Text("Your Library", style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
                if (libraryState.listLocalPlaylist.isEmpty()) {
                    SocialEmptyCard("No local playlists yet", "Create a playlist in Nefy Library first.")
                } else {
                    libraryState.listLocalPlaylist.forEach { playlist ->
                        Card(modifier = Modifier.fillMaxWidth().clickable {
                            selectedPlaylistId = playlist.id
                            selectedPlaylistTitle = playlist.title
                        }) {
                            Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                BoxAvatar(label = playlist.title.take(1).uppercase())
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(playlist.title, style = typo().titleMedium, fontWeight = FontWeight.SemiBold)
                                    Text("${playlist.tracks?.size ?: 0} songs", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("Open", style = typo().labelMedium, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { selectedPlaylistId = null; libraryTracks = emptyList() }) { Text("Back") }
                    Text(selectedPlaylistTitle, style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
                }
                if (libraryTracks.isEmpty()) {
                    SocialEmptyCard("Playlist is empty", "Add songs to this Library playlist first.")
                } else {
                    libraryTracks.forEach { song ->
                        val track = ListeningTrack(
                            videoId = song.videoId,
                            title = song.title,
                            artist = song.artistName?.joinToString(", ").orEmpty().ifBlank { "Unknown artist" },
                            artworkUrl = song.thumbnails,
                            durationMs = song.durationSeconds.toLong() * 1000L,
                        )
                        RoomPickerTrackRow(track = track, actionLabel = "Add", onAction = { onAddTrack(track) })
                    }
                }
            }
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Done") }
        }
    }
}

@Composable
private fun RoomPickerTrackRow(track: ListeningTrack, actionLabel: String, onAction: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AsyncImage(model = track.artworkUrl, contentDescription = track.title, modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)))
            Column(modifier = Modifier.weight(1f)) {
                Text(track.title, style = typo().bodyMedium, maxLines = 2)
                Text(track.artist, style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
            TextButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoomInviteSheet(
    friends: List<com.museme.app.social.listening.NefyFriend>,
    roomCode: String,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Invite friends", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
            Text("Share this room with someone from your Nefy friends list.", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (friends.isEmpty()) {
                SocialEmptyCard("No accepted friends yet", "Add friends from the Friends tab, or share the room link below.")
            } else {
                friends.forEach { friend ->
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        BoxAvatar(label = friend.displayName.take(1).uppercase())
                        Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(friend.displayName, style = typo().titleMedium)
                            Text(friend.handle?.let { "@$it" } ?: "Nefy friend", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton(onClick = {
                            shareUrl(title = "Join my Nefy listening room", url = "nefy://room/$roomCode")
                        }) { Text("Invite") }
                    }
                }
            }
            FilledTonalButton(onClick = { shareUrl(title = "Join my Nefy listening room", url = "nefy://room/$roomCode") }, modifier = Modifier.fillMaxWidth()) {
                Icon(imageVector = SimpIcons.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Share room link")
            }
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Close") }
        }
    }
}

@Composable
private fun formatRoomTime(milliseconds: Long): String {
    val seconds = (milliseconds.coerceAtLeast(0L) / 1_000L).toInt()
    val minutes = seconds / 60
    val remainder = (seconds % 60).toString().padStart(2, '0')
    return "$minutes:$remainder"
}

@Composable
private fun BoxAvatar(label: String) {
    Surface(
        modifier = Modifier.size(42.dp).clip(CircleShape),
        color = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text = label, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        }
    }
}
