package com.museme.app.ui.screen.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.museme.app.expect.shareUrl
import com.museme.app.social.listening.ListeningRoomConnection
import com.museme.app.social.listening.ListeningRoomController
import com.museme.app.social.listening.ListeningRoomState
import com.museme.app.social.listening.ListeningTrack
import com.museme.app.ui.component.RippleIconButton
import com.museme.app.ui.icon.ArrowBackIosNew
import com.museme.app.ui.icon.Pause
import com.museme.app.ui.icon.PeopleAlt
import com.museme.app.ui.icon.PlayArrow
import com.museme.app.ui.icon.Share
import com.museme.app.ui.icon.SimpIcons
import com.museme.app.ui.theme.typo
import com.museme.app.viewModel.SharedViewModel
import com.museme.app.viewModel.UIEvent
import museme.composeapp.generated.resources.Res
import museme.composeapp.generated.resources.create_listening_room
import museme.composeapp.generated.resources.currently_listening
import museme.composeapp.generated.resources.follow_host
import museme.composeapp.generated.resources.friend_listening
import museme.composeapp.generated.resources.invite_friends
import museme.composeapp.generated.resources.join_room
import museme.composeapp.generated.resources.join_room_description
import museme.composeapp.generated.resources.leave_room
import museme.composeapp.generated.resources.listening_room
import museme.composeapp.generated.resources.listening_room_code
import museme.composeapp.generated.resources.members
import museme.composeapp.generated.resources.no_room_yet
import museme.composeapp.generated.resources.room_code_hint
import museme.composeapp.generated.resources.share_room
import museme.composeapp.generated.resources.start_listening_together
import museme.composeapp.generated.resources.you_are_host
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FriendsScreen(
    navController: NavController,
    initialRoomCode: String? = null,
    roomController: ListeningRoomController = koinInject(),
    sharedViewModel: SharedViewModel = koinInject(),
) {
    val roomState by roomController.state.collectAsStateWithLifecycle()
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    var roomCode by rememberSaveable { mutableStateOf(initialRoomCode.orEmpty()) }
    var displayName by rememberSaveable { mutableStateOf("You") }

    LaunchedEffect(roomState.roomCode, roomState.currentTrack?.videoId, roomState.currentUserId) {
        val sharedTrack = roomState.currentTrack
        if (sharedTrack != null && sharedTrack.videoId.isNotBlank() && sharedTrack.videoId != "museme-demo") {
            sharedViewModel.loadSharedMediaItem(sharedTrack.videoId)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(Res.string.friend_listening),
                        style = typo().titleMedium,
                    )
                },
                navigationIcon = {
                    RippleIconButton(
                        imageVector = SimpIcons.ArrowBackIosNew,
                        tint = MaterialTheme.colorScheme.onSurface,
                        onClick = { navController.navigateUp() },
                    )
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(innerPadding)
                    .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (roomState.roomCode == null) {
                EmptyRoomContent(
                    displayName = displayName,
                    roomCode = roomCode,
                    onDisplayNameChange = { displayName = it.take(24) },
                    onRoomCodeChange = { roomCode = it.uppercase().take(8) },
                    onCreateRoom = { roomController.createRoom(displayName) },
                    onJoinRoom = { roomController.joinRoom(roomCode, displayName) },
                )
            } else {
                ActiveRoomContent(
                    state = roomState,
                    onPlayingChange = { isPlaying ->
                        roomController.setPlaying(isPlaying)
                        sharedViewModel.onUIEvent(UIEvent.PlayPause)
                    },
                    onShareTrack = {
                        val current = nowPlayingState
                        val song = current?.songEntity
                        if (song != null && song.videoId.isNotBlank()) {
                            roomController.setTrack(
                                ListeningTrack(
                                    videoId = song.videoId,
                                    title = song.title,
                                    artist = song.artistName?.joinToString(", ").orEmpty().ifBlank { "Unknown artist" },
                                    artworkUrl = current.mediaItem.metadata.artworkUri ?: song.thumbnails,
                                    durationMs = sharedViewModel.timeline.value.total.takeIf { it > 0L }
                                        ?: song.durationSeconds.toLong() * 1000L,
                                ),
                            )
                        }
                    },
                    onFollowHostChange = roomController::setFollowHost,
                    onLeaveRoom = roomController::leaveRoom,
                )
            }
        }
    }
}

@Composable
private fun EmptyRoomContent(
    displayName: String,
    roomCode: String,
    onDisplayNameChange: (String) -> Unit,
    onRoomCodeChange: (String) -> Unit,
    onCreateRoom: () -> Unit,
    onJoinRoom: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = SimpIcons.PeopleAlt,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(32.dp),
                )
                Text(
                    text = stringResource(Res.string.start_listening_together),
                    style = typo().headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Text(
                    text = stringResource(Res.string.join_room_description),
                    style = typo().bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
        }

        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = displayName,
            onValueChange = onDisplayNameChange,
            label = { Text("Display name") },
            singleLine = true,
        )
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = onCreateRoom,
        ) {
            Icon(imageVector = SimpIcons.PeopleAlt, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = stringResource(Res.string.create_listening_room))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = stringResource(Res.string.no_room_yet),
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.weight(1f))
        }

        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = roomCode,
            onValueChange = onRoomCodeChange,
            label = { Text(stringResource(Res.string.listening_room_code)) },
            placeholder = { Text(stringResource(Res.string.room_code_hint)) },
            singleLine = true,
        )
        FilledTonalButton(
            modifier = Modifier.fillMaxWidth(),
            enabled = roomCode.isNotBlank(),
            onClick = onJoinRoom,
        ) {
            Text(text = stringResource(Res.string.join_room))
        }
    }
}

@Composable
private fun ActiveRoomContent(
    state: ListeningRoomState,
    onPlayingChange: (Boolean) -> Unit,
    onShareTrack: () -> Unit,
    onFollowHostChange: (Boolean) -> Unit,
    onLeaveRoom: () -> Unit,
) {
    val track = state.currentTrack
    val isHost = state.hostId == state.currentUserId
    val progress =
        track?.durationMs?.takeIf { it > 0L }?.let { duration ->
            (state.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
        }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = stringResource(Res.string.listening_room), style = typo().headlineSmall)
                Text(
                    text = state.roomCode.orEmpty(),
                    style = typo().titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = when (state.connection) {
                        ListeningRoomConnection.Connected -> "Connected · revision ${state.revision}"
                        ListeningRoomConnection.Connecting -> "Connecting…"
                        ListeningRoomConnection.Reconnecting -> "Reconnecting…"
                        ListeningRoomConnection.Disconnected -> "Disconnected"
                    },
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(
                onClick = {
                    shareUrl(
                        title = "Join my Museme listening room",
                        url = "museme://room/${state.roomCode}",
                    )
                },
            ) {
                Icon(imageVector = SimpIcons.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = stringResource(Res.string.share_room))
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(text = stringResource(Res.string.currently_listening), style = typo().labelLarge)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BoxAvatar(label = track?.title?.firstOrNull()?.uppercase() ?: "M")
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = track?.title ?: "Museme Radio", style = typo().titleMedium)
                        Text(text = track?.artist ?: "Shared listening session", style = typo().bodySmall)
                    }
                    if (isHost) {
                        RippleIconButton(
                            imageVector = if (state.isPlaying) SimpIcons.Pause else SimpIcons.PlayArrow,
                            tint = MaterialTheme.colorScheme.onSurface,
                            onClick = { onPlayingChange(!state.isPlaying) },
                        )
                    }
                }
                progress?.let {
                    LinearProgressIndicator(
                        progress = { it },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (isHost) {
                    TextButton(onClick = onShareTrack) {
                        Text("Share current song with the room")
                    }
                }
            }
        }

        Text(text = stringResource(Res.string.members), style = typo().titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            state.members.take(4).forEach { member ->
                BoxAvatar(label = member.displayName.firstOrNull()?.uppercase() ?: "?")
            }
            Text(
                text = if (isHost) stringResource(Res.string.you_are_host) else "Following the host",
                style = typo().bodySmall,
                modifier = Modifier.align(Alignment.CenterVertically),
            )
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = stringResource(Res.string.follow_host), style = typo().titleMedium)
                    Text(
                        text = stringResource(Res.string.invite_friends),
                        style = typo().bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = state.followHost, onCheckedChange = onFollowHostChange)
            }
        }

        TextButton(
            modifier = Modifier.align(Alignment.CenterHorizontally),
            onClick = onLeaveRoom,
        ) {
            Text(text = stringResource(Res.string.leave_room))
        }
    }
}

@Composable
private fun BoxAvatar(label: String) {
    Surface(
        modifier = Modifier.size(42.dp).clip(CircleShape),
        color = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text = label, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        }
    }
}
