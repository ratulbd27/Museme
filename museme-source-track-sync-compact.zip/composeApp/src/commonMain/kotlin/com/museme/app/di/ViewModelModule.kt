package com.museme.app.di

import com.museme.app.BuildKonfig
import com.museme.app.social.listening.KtorListeningRoomTransport
import com.museme.app.social.listening.ListeningRoomController
import com.museme.app.social.listening.ListeningRoomTransport
import com.museme.app.social.listening.LocalListeningRoomTransport
import com.museme.app.social.listening.NefyIdentity
import com.museme.app.viewModel.AlbumViewModel
import com.museme.app.viewModel.AnalyticsViewModel
import com.museme.app.viewModel.ArtistViewModel
import com.museme.app.viewModel.HomeViewModel
import com.museme.app.viewModel.ImportViewModel
import com.museme.app.viewModel.LibraryDynamicPlaylistViewModel
import com.museme.app.viewModel.LibraryViewModel
import com.museme.app.viewModel.LocalPlaylistViewModel
import com.museme.app.viewModel.LogInViewModel
import com.museme.app.viewModel.MoodViewModel
import com.museme.app.viewModel.MoreAlbumsViewModel
import com.museme.app.viewModel.NotificationViewModel
import com.museme.app.viewModel.NowPlayingBottomSheetViewModel
import com.museme.app.viewModel.PlaylistViewModel
import com.museme.app.viewModel.PodcastViewModel
import com.museme.app.viewModel.RecentlySongsViewModel
import com.museme.app.viewModel.SearchViewModel
import com.museme.app.viewModel.SettingsViewModel
import com.museme.app.viewModel.SharedViewModel
import org.koin.core.module.dsl.viewModel
import org.koin.dsl.module

val viewModelModule =
    module {
        single { NefyIdentity(get()) }
        single<ListeningRoomTransport> {
            val identity = get<NefyIdentity>()
            BuildKonfig.roomServerUrl.trim().takeIf { it.isNotEmpty() }?.let { endpoint ->
                KtorListeningRoomTransport(
                    endpoint = endpoint,
                    userId = identity.userId,
                    displayName = identity.displayName,
                    authToken = BuildKonfig.roomAuthToken.trim().takeIf { it.isNotEmpty() },
                )
            } ?: LocalListeningRoomTransport()
        }
        single {
            ListeningRoomController(get())
        }
        single {
            SharedViewModel(
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
            )
        }
        single {
            SearchViewModel(
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            NowPlayingBottomSheetViewModel(
                get(),
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            LibraryViewModel(
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            LibraryDynamicPlaylistViewModel(
                get(),
                get(),
            )
        }
        viewModel {
            ImportViewModel(
                get(),
            )
        }
        viewModel {
            AlbumViewModel(
                get(),
                get(),
            )
        }
        viewModel {
            HomeViewModel(
                get(),
                get(),
            )
        }
        viewModel {
            SettingsViewModel(
                get(),
                get(),
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            ArtistViewModel(
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            PlaylistViewModel(
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            LogInViewModel(
                get(),
            )
        }
        viewModel {
            PodcastViewModel(
                get(),
            )
        }
        viewModel {
            MoreAlbumsViewModel(
                get(),
            )
        }
        viewModel {
            RecentlySongsViewModel(
                get(),
            )
        }
        viewModel {
            LocalPlaylistViewModel(
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            NotificationViewModel(
                get(),
            )
        }
        viewModel {
            MoodViewModel(
                get(),
                get(),
            )
        }
        viewModel {
            AnalyticsViewModel(
                get(),
                get(),
                get(),
                get(),
                get(),
            )
        }
    }