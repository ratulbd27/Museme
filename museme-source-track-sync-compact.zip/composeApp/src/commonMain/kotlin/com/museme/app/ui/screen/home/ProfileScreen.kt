package com.museme.app.ui.screen.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.maxrave.domain.utils.LocalResource
import com.museme.app.social.listening.ListeningRoomController
import com.museme.app.social.listening.NefyFriendRequest
import com.museme.app.social.listening.NefyIdentity
import com.museme.app.ui.component.RippleIconButton
import com.museme.app.ui.icon.ArrowBackIosNew
import com.museme.app.ui.icon.Close
import com.museme.app.ui.icon.PeopleAlt
import com.museme.app.ui.icon.PlaylistAdd
import com.museme.app.ui.icon.SimpIcons
import com.museme.app.ui.navigation.destination.home.FriendsDestination
import com.museme.app.ui.navigation.destination.login.LoginDestination
import com.museme.app.ui.theme.typo
import com.museme.app.viewModel.SettingsViewModel
import museme.composeapp.generated.resources.Res
import museme.composeapp.generated.resources.add_an_account
import museme.composeapp.generated.resources.cancel
import museme.composeapp.generated.resources.guest
import museme.composeapp.generated.resources.log_out
import museme.composeapp.generated.resources.no_account
import museme.composeapp.generated.resources.signed_in
import museme.composeapp.generated.resources.youtube_account
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import org.koin.compose.viewmodel.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    navController: NavController,
    innerPadding: PaddingValues,
    roomController: ListeningRoomController = koinInject(),
    settingsViewModel: SettingsViewModel = koinViewModel(),
) {
    val socialState by roomController.socialState.collectAsStateWithLifecycle()
    val googleAccounts by settingsViewModel.googleAccounts.collectAsStateWithLifecycle(minActiveState = Lifecycle.State.RESUMED)
    var showLogoutDialog by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        roomController.loadSocial()
        settingsViewModel.getAllGoogleAccount()
    }

    val profile = socialState.profile
    val usedAccount = googleAccounts.data?.firstOrNull { it.isUsed }
    val displayName = profile?.displayName?.ifBlank { null } ?: usedAccount?.name ?: "Nefy listener"
    val friendCode = profile?.friendCode ?: profile?.userId?.takeLast(8)?.uppercase().orEmpty()

    Scaffold(
        contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = { Text("Profile", style = typo().titleMedium) },
                navigationIcon = {
                    RippleIconButton(
                        imageVector = SimpIcons.ArrowBackIosNew,
                        tint = MaterialTheme.colorScheme.onSurface,
                        onClick = { navController.navigateUp() },
                    )
                },
            )
        },
    ) { scaffoldPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                ProfileHero(
                    displayName = displayName,
                    handle = profile?.handle,
                    friendCode = friendCode,
                    avatarUrl = usedAccount?.thumbnailUrl,
                )
            }
            item {
                ProfileActionRow(
                    title = "Friends",
                    subtitle = "${socialState.friends.size} connected · ${socialState.pendingRequests.count { it.direction == "incoming" }} requests",
                    onClick = { navController.navigate(FriendsDestination()) },
                )
            }
            item {
                Text("Connected YouTube accounts", style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
                Text(
                    "Choose which YouTube account Nefy uses for playback and personalization.",
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (googleAccounts is LocalResource.Success) {
                val accounts = googleAccounts.data.orEmpty()
                if (accounts.isEmpty()) {
                    item {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(Res.string.no_account), modifier = Modifier.padding(16.dp))
                        }
                    }
                } else {
                    items(accounts, key = { it.email }) { account ->
                        YouTubeAccountRow(
                            name = account.name,
                            email = account.email,
                            thumbnailUrl = account.thumbnailUrl,
                            isUsed = account.isUsed,
                            onClick = { settingsViewModel.setUsedAccount(account) },
                        )
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    FilledTonalButton(onClick = { settingsViewModel.setUsedAccount(null) }, modifier = Modifier.weight(1f)) {
                        Text(stringResource(Res.string.guest))
                    }
                    OutlinedButton(onClick = { navController.navigate(LoginDestination) }, modifier = Modifier.weight(1f)) {
                        Text(stringResource(Res.string.add_an_account))
                    }
                }
            }
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Activity sharing", style = typo().titleMedium)
                            Text(
                                if (socialState.activityVisibleToFriends) "Friends and shared-playlist collaborators can see your current or last-played activity" else "Your listening activity is hidden",
                                style = typo().bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Switch(
                            checked = socialState.activityVisibleToFriends,
                            onCheckedChange = roomController::setActivityVisibility,
                        )
                    }
                }
            }
            item {
                Text("Shared Library playlists", style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
                if (socialState.playlists.isEmpty()) {
                    Text("Shared playlists will appear here when you invite a friend.", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    socialState.playlists.take(6).forEach { playlist ->
                        ProfileActionRow(
                            title = playlist.name,
                            subtitle = "${playlist.tracks.size} songs · ${if (playlist.collaborationEnabled) "Collaborative" else "Private"}",
                            onClick = { navController.navigate(FriendsDestination()) },
                        )
                    }
                }
            }
            item {
                TextButton(onClick = { showLogoutDialog = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(Res.string.log_out), color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("Disconnect YouTube accounts?") },
            text = { Text("This signs out all YouTube accounts saved in Nefy. Your Nefy friend profile remains available.") },
            confirmButton = {
                TextButton(onClick = {
                    settingsViewModel.logOutAllYouTube()
                    showLogoutDialog = false
                }) { Text(stringResource(Res.string.log_out)) }
            },
            dismissButton = { TextButton(onClick = { showLogoutDialog = false }) { Text(stringResource(Res.string.cancel)) } },
        )
    }
}

@Composable
private fun ProfileHero(
    displayName: String,
    handle: String?,
    friendCode: String,
    avatarUrl: String?,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            ProfileAvatar(avatarUrl = avatarUrl, label = displayName.take(1))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(displayName, style = typo().headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(handle?.takeIf { it.isNotBlank() }?.let { "@$it" } ?: "Nefy profile", style = typo().bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text("Friend code · $friendCode", style = typo().labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
    }
}

@Composable
private fun ProfileAvatar(avatarUrl: String?, label: String) {
    Box(
        modifier = Modifier.size(76.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center,
    ) {
        if (!avatarUrl.isNullOrBlank()) {
            AsyncImage(
                model = ImageRequest.Builder(LocalPlatformContext.current).data(avatarUrl).crossfade(true).build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Text(label.uppercase(), style = typo().headlineLarge, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun YouTubeAccountRow(
    name: String,
    email: String,
    thumbnailUrl: String,
    isUsed: Boolean,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = if (isUsed) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AsyncImage(
                model = ImageRequest.Builder(LocalPlatformContext.current).data(thumbnailUrl).crossfade(true).build(),
                contentDescription = name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(48.dp).clip(CircleShape),
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(name, style = typo().titleMedium)
                Text(email, style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (isUsed) Text(stringResource(Res.string.signed_in), style = typo().labelMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun ProfileActionRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = typo().titleMedium)
                Text(subtitle, style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("›", style = typo().headlineSmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}
