package com.museme.app.social.listening

import com.maxrave.domain.manager.DataStoreManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlin.random.Random

/** Stable device-local identity used by Nefy rooms and private social data. */
class NefyIdentity(
    private val dataStoreManager: DataStoreManager,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val userId: String
    var displayName: String
        private set

    init {
        val storedUserId = runBlocking {
            dataStoreManager.getString(USER_ID_KEY).first().orEmpty()
        }
        userId = storedUserId.ifBlank {
            "guest-${Random.nextInt(100_000, 999_999)}".also { generated ->
                runBlocking { dataStoreManager.putString(USER_ID_KEY, generated) }
            }
        }

        displayName = runBlocking {
            dataStoreManager.getString(DISPLAY_NAME_KEY).first().orEmpty()
        }.ifBlank { DEFAULT_DISPLAY_NAME }
    }

    fun setDisplayName(value: String) {
        val safeValue = value.trim().take(MAX_DISPLAY_NAME_LENGTH)
        if (safeValue.isBlank() || safeValue == displayName) return
        displayName = safeValue
        scope.launch {
            dataStoreManager.putString(DISPLAY_NAME_KEY, safeValue)
        }
    }

    private companion object {
        const val USER_ID_KEY = "nefy_social_user_id"
        const val DISPLAY_NAME_KEY = "nefy_social_display_name"
        const val DEFAULT_DISPLAY_NAME = "Nefy listener"
        const val MAX_DISPLAY_NAME_LENGTH = 24
    }
}
