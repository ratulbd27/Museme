package com.nefy.app.ui.screen.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.maxrave.domain.utils.LocalResource
import com.nefy.app.social.listening.ListeningRoomController
import com.nefy.app.social.listening.NefyIdentity
import com.nefy.app.expect.copyToClipboard
import com.nefy.app.expect.shareUrl
import com.nefy.app.ui.component.RippleIconButton
import com.nefy.app.ui.icon.ArrowBackIosNew
import com.nefy.app.ui.icon.Edit
import com.nefy.app.ui.icon.PeopleAlt
import com.nefy.app.ui.icon.Share
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.navigation.destination.home.FriendsDestination
import com.nefy.app.ui.navigation.destination.login.LoginDestination
import com.nefy.app.ui.theme.NefySocialPalette
import com.nefy.app.ui.theme.nefySocialPalette
import com.nefy.app.ui.theme.typo
import com.nefy.app.viewModel.SettingsViewModel
import nefy.composeapp.generated.resources.Res
import nefy.composeapp.generated.resources.add_an_account
import nefy.composeapp.generated.resources.cancel
import nefy.composeapp.generated.resources.guest
import nefy.composeapp.generated.resources.log_out
import nefy.composeapp.generated.resources.no_account
import nefy.composeapp.generated.resources.signed_in
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import org.koin.compose.viewmodel.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    navController: NavController,
    innerPadding: PaddingValues,
    roomController: ListeningRoomController = koinInject(),
    settingsViewModel: SettingsViewModel = koinViewModel(),
) {
    val socialState by roomController.socialState.collectAsStateWithLifecycle()
    val socialPalette = nefySocialPalette()
    val googleAccounts by settingsViewModel.googleAccounts.collectAsStateWithLifecycle(minActiveState = Lifecycle.State.RESUMED)
    val identity: NefyIdentity = koinInject()
    var showLogoutDialog by rememberSaveable { mutableStateOf(false) }
    var showEditProfileDialog by rememberSaveable { mutableStateOf(false) }
    var editableDisplayName by rememberSaveable { mutableStateOf("") }
    var editableHandle by rememberSaveable { mutableStateOf("") }
    var editableBio by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(Unit) {
        roomController.loadSocial()
        settingsViewModel.getAllGoogleAccount()
    }

    val profile = socialState.profile
    val usedAccount = googleAccounts.data?.firstOrNull { it.isUsed }
    val displayName = profile?.displayName?.ifBlank { null } ?: identity.displayName.ifBlank { usedAccount?.name ?: "Nefy listener" }
    val profileHandle = profile?.handle?.ifBlank { null } ?: identity.handle
    val friendCode = profile?.friendCode ?: profile?.userId?.takeLast(8)?.uppercase() ?: identity.userId.takeLast(8).uppercase()

    Scaffold(
        containerColor = socialPalette.pageBackground,
        contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = socialPalette.pageBackground),
                title = { Text("Profile", style = typo().titleMedium) },
                navigationIcon = {
                    RippleIconButton(
                        imageVector = SimpIcons.ArrowBackIosNew,
                        tint = MaterialTheme.colorScheme.onSurface,
                        onClick = { navController.navigateUp() },
                    )
                },
            )
        },
    ) { scaffoldPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(scaffoldPadding).padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                ProfileHero(
                    displayName = displayName,
                    handle = profileHandle,
                    friendCode = friendCode,
                    avatarUrl = usedAccount?.thumbnailUrl,
                    palette = socialPalette,
                    onCopyFriendCode = { copyToClipboard("Nefy friend code", friendCode) },
                )
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    ProfileActionButton(
                        icon = SimpIcons.Edit,
                        label = "Edit profile",
                        palette = socialPalette,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            editableDisplayName = displayName
                            editableHandle = profileHandle
                            editableBio = identity.bio
                            showEditProfileDialog = true
                        },
                    )
                    ProfileActionButton(
                        icon = SimpIcons.Share,
                        label = "Share profile",
                        palette = socialPalette,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            shareUrl(
                                title = "Connect with me on Nefy",
                                url = "nefy://profile/${profile?.userId ?: identity.userId}",
                            )
                        },
                    )
                    ProfileActionButton(
                        icon = SimpIcons.PeopleAlt,
                        label = "Friends",
                        palette = socialPalette,
                        onClick = { navController.navigate(FriendsDestination()) },
                    )
                }
            }
            item {
                ProfileActionRow(
                    title = "Friends and requests",
                    subtitle = "${socialState.friends.size} connected · ${socialState.pendingRequests.count { it.direction == "incoming" }} requests",
                    palette = socialPalette,
                    onClick = { navController.navigate(FriendsDestination()) },
                )
            }
            item {
                Text("Shared playlists", style = typo().titleLarge, fontWeight = FontWeight.SemiBold, color = socialPalette.primaryText)
                if (socialState.playlists.isEmpty()) {
                    Text("Share any Library playlist with friends to see it here.", style = typo().bodySmall, color = socialPalette.secondaryText)
                } else {
                    socialState.playlists.take(6).forEach { playlist ->
                        ProfileActionRow(
                            title = playlist.name,
                            subtitle = "${playlist.tracks.size} songs · ${if (playlist.collaborationEnabled) "Collaborative" else "Private"}",
                            palette = socialPalette,
                            onClick = { navController.navigate(FriendsDestination()) },
                        )
                    }
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = socialPalette.card),
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Listening activity", style = typo().titleMedium, color = socialPalette.primaryText)
                            Text(
                                if (socialState.activityVisibleToFriends) "Friends and shared-playlist collaborators can see your current or last-played activity" else "Your listening activity is hidden",
                                style = typo().bodySmall,
                                color = socialPalette.secondaryText,
                            )
                        }
                        Switch(
                            checked = socialState.activityVisibleToFriends,
                            onCheckedChange = roomController::setActivityVisibility,
                        )
                    }
                }
            }
            item {
                Text("Privacy", style = typo().titleLarge, fontWeight = FontWeight.SemiBold, color = socialPalette.primaryText)
                Text("Your friend code only connects you with people you invite. Listening activity follows the switch above.", style = typo().bodySmall, color = socialPalette.secondaryText)
            }
            item {
                Text("Connected YouTube accounts", style = typo().titleLarge, fontWeight = FontWeight.SemiBold, color = socialPalette.primaryText)
                Text(
                    "Choose which YouTube account Nefy uses for playback and personalization.",
                    style = typo().bodySmall,
                    color = socialPalette.secondaryText,
                )
            }
            if (googleAccounts is LocalResource.Success) {
                val accounts = googleAccounts.data.orEmpty()
                if (accounts.isEmpty()) {
                    item {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(Res.string.no_account), modifier = Modifier.padding(16.dp))
                        }
                    }
                } else {
                    items(accounts, key = { it.email }) { account ->
                        YouTubeAccountRow(
                            name = account.name,
                            email = account.email,
                            thumbnailUrl = account.thumbnailUrl,
                            isUsed = account.isUsed,
                            onClick = { settingsViewModel.setUsedAccount(account) },
                        )
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    FilledTonalButton(onClick = { settingsViewModel.setUsedAccount(null) }, modifier = Modifier.weight(1f)) {
                        Text(stringResource(Res.string.guest))
                    }
                    OutlinedButton(onClick = { navController.navigate(LoginDestination) }, modifier = Modifier.weight(1f)) {
                        Text(stringResource(Res.string.add_an_account))
                    }
                }
            }
            item {
                TextButton(onClick = { showLogoutDialog = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(Res.string.log_out), color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }

    if (showEditProfileDialog) {
        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Edit profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editableDisplayName,
                        onValueChange = { editableDisplayName = it.take(32) },
                        label = { Text("Display name") },
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = editableHandle,
                        onValueChange = { editableHandle = it.take(25) },
                        label = { Text("Handle") },
                        prefix = { Text("@") },
                        supportingText = { Text("Your handle is how friends find you") },
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = editableBio,
                        onValueChange = { editableBio = it.take(120) },
                        label = { Text("Bio") },
                        minLines = 2,
                        maxLines = 3,
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    identity.setProfile(editableDisplayName, editableHandle, editableBio)
                    roomController.updateProfile(editableDisplayName, editableHandle)
                    showEditProfileDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showEditProfileDialog = false }) { Text(stringResource(Res.string.cancel)) } },
        )
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("Disconnect YouTube accounts?") },
            text = { Text("This signs out all YouTube accounts saved in Nefy. Your Nefy friend profile remains available.") },
            confirmButton = {
                TextButton(onClick = {
                    settingsViewModel.logOutAllYouTube()
                    showLogoutDialog = false
                }) { Text(stringResource(Res.string.log_out)) }
            },
            dismissButton = { TextButton(onClick = { showLogoutDialog = false }) { Text(stringResource(Res.string.cancel)) } },
        )
    }
}

@Composable
private fun ProfileHero(
    displayName: String,
    handle: String?,
    friendCode: String,
    avatarUrl: String?,
    palette: NefySocialPalette,
    onCopyFriendCode: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .drawBehind {
                drawCircle(
                    color = Color.White.copy(alpha = 0.16f),
                    radius = size.width * 0.34f,
                    center = Offset(size.width * 0.92f, size.height * 0.10f),
                )
                drawCircle(
                    color = palette.heroWave.copy(alpha = 0.58f),
                    radius = size.width * 0.52f,
                    center = Offset(size.width * 0.10f, size.height * 1.08f),
                )
                drawCircle(
                    color = palette.heroWave.copy(alpha = 0.40f),
                    radius = size.width * 0.44f,
                    center = Offset(size.width * 0.64f, size.height * 1.06f),
                )
            },
        shape = RoundedCornerShape(30.dp),
        color = palette.hero,
        tonalElevation = 2.dp,
        shadowElevation = 2.dp,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            ProfileAvatar(
                avatarUrl = avatarUrl,
                label = displayName.take(1),
                size = 128.dp,
                backgroundColor = Color.White.copy(alpha = 0.30f),
                textColor = palette.primaryText,
                borderColor = Color.White,
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(
                    displayName,
                    style = typo().headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = palette.primaryText,
                )
                Text(
                    handle?.takeIf { it.isNotBlank() }?.let { "@$it" } ?: "@nefy-listener",
                    style = typo().titleMedium,
                    color = palette.primaryText,
                )
                OutlinedButton(
                    onClick = onCopyFriendCode,
                    border = BorderStroke(1.5.dp, palette.accent),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.primaryText),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                ) {
                    Text("Friend code · $friendCode", maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun ProfileAvatar(
    avatarUrl: String?,
    label: String,
    size: androidx.compose.ui.unit.Dp = 76.dp,
    backgroundColor: Color = MaterialTheme.colorScheme.surface,
    textColor: Color = MaterialTheme.colorScheme.primary,
    borderColor: Color? = null,
) {
    val avatarModifier = Modifier
        .size(size)
        .clip(CircleShape)
        .background(backgroundColor)
        .then(borderColor?.let { Modifier.border(5.dp, it, CircleShape) } ?: Modifier)
    Box(
        modifier = avatarModifier,
        contentAlignment = Alignment.Center,
    ) {
        if (!avatarUrl.isNullOrBlank()) {
            AsyncImage(
                model = ImageRequest.Builder(LocalPlatformContext.current).data(avatarUrl).crossfade(true).build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Text(label.uppercase(), style = typo().headlineLarge, color = textColor)
        }
    }
}

@Composable
private fun YouTubeAccountRow(
    name: String,
    email: String,
    thumbnailUrl: String,
    isUsed: Boolean,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = if (isUsed) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AsyncImage(
                model = ImageRequest.Builder(LocalPlatformContext.current).data(thumbnailUrl).crossfade(true).build(),
                contentDescription = name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(48.dp).clip(CircleShape),
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(name, style = typo().titleMedium)
                Text(email, style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (isUsed) Text(stringResource(Res.string.signed_in), style = typo().labelMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun ProfileActionButton(
    icon: ImageVector,
    label: String,
    palette: NefySocialPalette,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        color = palette.cardElevated,
        tonalElevation = 1.dp,
        shadowElevation = 1.dp,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = palette.accent, modifier = Modifier.size(20.dp))
            Text(
                text = label,
                modifier = Modifier.padding(start = 5.dp),
                style = typo().labelMedium,
                color = palette.primaryText,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun ProfileActionRow(
    title: String,
    subtitle: String,
    palette: NefySocialPalette,
    onClick: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        color = palette.card,
        tonalElevation = 1.dp,
        shadowElevation = 1.dp,
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = typo().titleMedium, color = palette.primaryText)
                Text(subtitle, style = typo().bodySmall, color = palette.secondaryText)
            }
            Text("›", style = typo().headlineSmall, color = palette.accent)
        }
    }
}
