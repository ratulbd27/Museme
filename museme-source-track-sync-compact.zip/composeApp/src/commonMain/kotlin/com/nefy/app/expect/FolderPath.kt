package com.nefy.app.expect

expect fun getDownloadFolderPath(): String