package com.nefy.app.ui.navigation.graph

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.toRoute
import com.nefy.app.ui.navigation.destination.home.HomeDestination
import com.nefy.app.ui.theme.ForceDarkContent
import com.nefy.app.ui.navigation.destination.library.LibraryDestination
import com.nefy.app.ui.navigation.destination.player.FullscreenDestination
import com.nefy.app.ui.navigation.destination.search.SearchDestination
import com.nefy.app.ui.navigation.destination.search.SharedPlaylistSearchDestination
import com.nefy.app.ui.screen.home.HomeScreen
import com.nefy.app.ui.screen.library.LibraryScreen
import com.nefy.app.ui.screen.other.SearchScreen
import com.nefy.app.ui.screen.player.FullscreenPlayer

private val NefyEmphasizedEasing = CubicBezierEasing(0.2f, 0f, 0f, 1f)
private const val NefyTransitionDuration = 340

@Composable
@ExperimentalMaterial3Api
@ExperimentalFoundationApi
fun AppNavigationGraph(
    innerPadding: PaddingValues,
    navController: NavHostController,
    startDestination: Any = HomeDestination,
    hideNavBar: () -> Unit = { },
    showNavBar: (shouldShowNowPlayingSheet: Boolean) -> Unit = { },
    showNowPlayingSheet: () -> Unit = {},
    onScrolling: (onTop: Boolean) -> Unit = {},
) {
    NavHost(
        navController,
        startDestination = startDestination,
        enterTransition = {
            slideInHorizontally(
                animationSpec = tween(NefyTransitionDuration, easing = NefyEmphasizedEasing),
                initialOffsetX = { it / 3 },
            ) + scaleIn(
                animationSpec = tween(NefyTransitionDuration, easing = NefyEmphasizedEasing),
                initialScale = 0.97f,
            ) + fadeIn(
                animationSpec = tween(NefyTransitionDuration / 2, easing = NefyEmphasizedEasing),
            )
        },
        exitTransition = {
            slideOutHorizontally(
                animationSpec = tween(NefyTransitionDuration, easing = NefyEmphasizedEasing),
                targetOffsetX = { -it / 8 },
            ) + fadeOut(
                animationSpec = tween(NefyTransitionDuration / 2, easing = NefyEmphasizedEasing),
            )
        },
        popEnterTransition = {
            slideInHorizontally(
                animationSpec = tween(NefyTransitionDuration, easing = NefyEmphasizedEasing),
                initialOffsetX = { -it / 8 },
            ) + scaleIn(
                animationSpec = tween(NefyTransitionDuration, easing = NefyEmphasizedEasing),
                initialScale = 0.985f,
            ) + fadeIn(
                animationSpec = tween(NefyTransitionDuration / 2, easing = NefyEmphasizedEasing),
            )
        },
        popExitTransition = {
            slideOutHorizontally(
                animationSpec = tween(NefyTransitionDuration, easing = NefyEmphasizedEasing),
                targetOffsetX = { it / 3 },
            ) + scaleOut(
                animationSpec = tween(NefyTransitionDuration, easing = NefyEmphasizedEasing),
                targetScale = 0.97f,
            ) + fadeOut(
                animationSpec = tween(NefyTransitionDuration / 2, easing = NefyEmphasizedEasing),
            )
        },
    ) {
        // Bottom bar destinations
        composable<HomeDestination> {
            HomeScreen(
                onScrolling = onScrolling,
                navController = navController,
            )
        }
        composable<SearchDestination> {
            SearchScreen(
                navController = navController,
            )
        }
        composable<SharedPlaylistSearchDestination> { entry ->
            SearchScreen(
                navController = navController,
                sharedPlaylistId = entry.toRoute<SharedPlaylistSearchDestination>().playlistId,
            )
        }
        composable<LibraryDestination> {
            LibraryScreen(
                innerPadding = innerPadding,
                navController = navController,
                onScrolling = onScrolling,
            )
        }
        composable<FullscreenDestination> {
            ForceDarkContent {
                FullscreenPlayer(
                    navController,
                    hideNavBar = hideNavBar,
                    showNavBar = {
                        showNavBar.invoke(true)
                        showNowPlayingSheet.invoke()
                    },
                )
            }
        }
        // Home screen graph
        homeScreenGraph(
            innerPadding = innerPadding,
            navController = navController,
        )
        // Library screen graph
        libraryScreenGraph(
            innerPadding = innerPadding,
            navController = navController,
        )
        // List screen graph
        listScreenGraph(
            innerPadding = innerPadding,
            navController = navController,
        )
        // Login screen graph
        loginScreenGraph(
            innerPadding = innerPadding,
            navController = navController,
            hideBottomBar = hideNavBar,
            showBottomBar = {
                showNavBar(false)
            },
        )
    }
}