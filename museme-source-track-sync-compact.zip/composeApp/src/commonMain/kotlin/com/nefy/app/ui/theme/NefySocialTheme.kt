package com.nefy.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

@Immutable
data class NefySocialPalette(
    val pageBackground: Color,
    val card: Color,
    val cardElevated: Color,
    val hero: Color,
    val heroWave: Color,
    val primaryText: Color,
    val secondaryText: Color,
    val accent: Color,
    val accentContainer: Color,
    val outline: Color,
    val danger: Color,
)

@Composable
fun nefySocialPalette(): NefySocialPalette =
    if (LocalIsDarkTheme.current) {
        NefySocialPalette(
            pageBackground = Color(0xFF080B16),
            card = Color(0xFF111526),
            cardElevated = Color(0xFF171D32),
            hero = Color(0xFF0C3A45),
            heroWave = Color(0xFF1A5B60),
            primaryText = Color(0xFFFFF8F2),
            secondaryText = Color(0xFFB7B3C9),
            accent = Color(0xFF6BE4D9),
            accentContainer = Color(0xFF143F45),
            outline = Color(0xFF303750),
            danger = Color(0xFFFFA6BB),
        )
    } else {
        NefySocialPalette(
            pageBackground = Color(0xFFFFFAF5),
            card = Color(0xFFFFFEFC),
            cardElevated = Color(0xFFF8F3FA),
            hero = Color(0xFFB8EEF0),
            heroWave = Color(0xFFE5FBF8),
            primaryText = Color(0xFF17112F),
            secondaryText = Color(0xFF625C70),
            accent = Color(0xFF159EA9),
            accentContainer = Color(0xFFE4F8F7),
            outline = Color(0xFFE0D9E2),
            danger = Color(0xFFB3265B),
        )
    }
