package com.nefy.app.di

import com.nefy.app.BuildKonfig
import com.nefy.app.social.listening.KtorListeningRoomTransport
import com.nefy.app.social.listening.ListeningRoomController
import com.nefy.app.social.listening.ListeningRoomTransport
import com.nefy.app.social.listening.LocalListeningRoomTransport
import com.nefy.app.social.listening.NefyIdentity
import com.nefy.app.viewModel.AlbumViewModel
import com.nefy.app.viewModel.AnalyticsViewModel
import com.nefy.app.viewModel.ArtistViewModel
import com.nefy.app.viewModel.HomeViewModel
import com.nefy.app.viewModel.ImportViewModel
import com.nefy.app.viewModel.LibraryDynamicPlaylistViewModel
import com.nefy.app.viewModel.LibraryViewModel
import com.nefy.app.viewModel.LocalPlaylistViewModel
import com.nefy.app.viewModel.LogInViewModel
import com.nefy.app.viewModel.MoodViewModel
import com.nefy.app.viewModel.MoreAlbumsViewModel
import com.nefy.app.viewModel.NotificationViewModel
import com.nefy.app.viewModel.NowPlayingBottomSheetViewModel
import com.nefy.app.viewModel.PlaylistViewModel
import com.nefy.app.viewModel.PodcastViewModel
import com.nefy.app.viewModel.RecentlySongsViewModel
import com.nefy.app.viewModel.SearchViewModel
import com.nefy.app.viewModel.SettingsViewModel
import com.nefy.app.viewModel.SharedViewModel
import org.koin.core.module.dsl.viewModel
import org.koin.dsl.module

val viewModelModule =
    module {
        single { NefyIdentity(get()) }
        single<ListeningRoomTransport> {
            val identity = get<NefyIdentity>()
            BuildKonfig.roomServerUrl.trim().takeIf { it.isNotEmpty() }?.let { endpoint ->
                KtorListeningRoomTransport(
                    endpoint = endpoint,
                    identity = identity,
                    authToken = BuildKonfig.roomAuthToken.trim().takeIf { it.isNotEmpty() },
                )
            } ?: LocalListeningRoomTransport()
        }
        single {
            ListeningRoomController(get())
        }
        single {
            SharedViewModel(
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
            )
        }
        single {
            SearchViewModel(
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            NowPlayingBottomSheetViewModel(
                get(),
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            LibraryViewModel(
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            LibraryDynamicPlaylistViewModel(
                get(),
                get(),
            )
        }
        viewModel {
            ImportViewModel(
                get(),
            )
        }
        viewModel {
            AlbumViewModel(
                get(),
                get(),
            )
        }
        viewModel {
            HomeViewModel(
                get(),
                get(),
            )
        }
        viewModel {
            SettingsViewModel(
                get(),
                get(),
                get(),
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            ArtistViewModel(
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            PlaylistViewModel(
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            LogInViewModel(
                get(),
            )
        }
        viewModel {
            PodcastViewModel(
                get(),
            )
        }
        viewModel {
            MoreAlbumsViewModel(
                get(),
            )
        }
        viewModel {
            RecentlySongsViewModel(
                get(),
            )
        }
        viewModel {
            LocalPlaylistViewModel(
                get(),
                get(),
                get(),
            )
        }
        viewModel {
            NotificationViewModel(
                get(),
            )
        }
        viewModel {
            MoodViewModel(
                get(),
                get(),
            )
        }
        viewModel {
            AnalyticsViewModel(
                get(),
                get(),
                get(),
                get(),
                get(),
            )
        }
    }