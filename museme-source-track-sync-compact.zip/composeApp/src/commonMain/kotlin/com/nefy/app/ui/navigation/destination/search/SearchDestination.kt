package com.nefy.app.ui.navigation.destination.search

import kotlinx.serialization.Serializable

@Serializable
data object SearchDestination