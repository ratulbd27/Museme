package com.nefy.app.social.listening

import com.maxrave.domain.data.type.PlaylistType

/**
 * Presentation adapter for rendering a cloud shared playlist in the same
 * Library grid used by local and YouTube playlists.
 */
data class SharedPlaylistLibraryItem(
    val playlistId: String,
    val title: String,
    val artworkUrl: String?,
    val ownerName: String,
) : PlaylistType {
    override fun playlistType(): PlaylistType.Type = PlaylistType.Type.LOCAL
}
