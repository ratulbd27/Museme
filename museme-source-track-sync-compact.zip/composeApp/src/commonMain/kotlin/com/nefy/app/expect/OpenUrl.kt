package com.nefy.app.expect

expect fun openUrl(url: String)

expect fun shareUrl(
    title: String,
    url: String,
)