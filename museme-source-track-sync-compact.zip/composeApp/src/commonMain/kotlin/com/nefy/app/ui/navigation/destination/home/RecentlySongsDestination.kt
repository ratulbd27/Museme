package com.nefy.app.ui.navigation.destination.home

import kotlinx.serialization.Serializable

@Serializable
data object RecentlySongsDestination