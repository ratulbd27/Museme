package com.nefy.app.ui.component

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nefy.app.extension.shimmer
import com.nefy.app.ui.theme.LocalAppColors
import org.jetbrains.compose.resources.painterResource
import nefy.composeapp.generated.resources.Res
import nefy.composeapp.generated.resources.nefy_icon

@Composable
fun HomeItemShimmer() {
    Column {
        Box(
            Modifier
                .width(150.dp)
                .height(36.dp)
                .padding(vertical = 8.dp)
                .background(
                    color = LocalAppColors.current.shimmerBackground,
                ).clip(RoundedCornerShape(10))
                .shimmer(),
        )
        LazyRow(userScrollEnabled = false) {
            items(10) {
                PlaylistShimmer()
            }
        }
    }
}

@Composable
fun PlaylistShimmer() {
    Column(
        Modifier
            .height(270.dp)
            .padding(10.dp),
    ) {
        Box(
            Modifier
                .size(160.dp)
                .clip(
                    RoundedCornerShape(10),
                ).background(
                    color = LocalAppColors.current.shimmerBackground,
                ).shimmer(),
        )
        Spacer(modifier = Modifier.size(10.dp))
        Box(
            Modifier
                .width(130.dp)
                .height(18.dp)
                .clip(
                    RoundedCornerShape(10),
                ).background(
                    color = LocalAppColors.current.shimmerBackground,
                ).shimmer(),
        )
        Spacer(modifier = Modifier.size(10.dp))
        Box(
            Modifier
                .width(130.dp)
                .height(18.dp)
                .clip(
                    RoundedCornerShape(10),
                ).background(
                    color = LocalAppColors.current.shimmerBackground,
                ).shimmer(),
        )
    }
}

@Composable
fun QuickPicksShimmerItem() {
    Row(
        Modifier
            .height(70.dp)
            .padding(10.dp),
    ) {
        Box(
            Modifier
                .size(50.dp)
                .clip(RoundedCornerShape(10))
                .background(LocalAppColors.current.shimmerBackground)
                .shimmer(),
        )
        Column(
            Modifier
                .padding(start = 10.dp)
                .wrapContentHeight(align = Alignment.CenterVertically)
                .align(Alignment.CenterVertically),
        ) {
            Box(
                Modifier
                    .width(300.dp)
                    .height(21.dp)
                    .clip(RoundedCornerShape(10))
                    .background(LocalAppColors.current.shimmerBackground)
                    .shimmer(),
            )
            Spacer(modifier = Modifier.height(3.dp))
            Box(
                Modifier
                    .width(260.dp)
                    .height(21.dp)
                    .clip(RoundedCornerShape(10))
                    .background(LocalAppColors.current.shimmerBackground)
                    .shimmer(),
            )
        }
    }
}

@Composable
fun QuickPicksShimmer() {
    Column {
        Box(
            Modifier
                .width(150.dp)
                .height(36.dp)
                .padding(vertical = 8.dp)
                .background(
                    color = LocalAppColors.current.shimmerBackground,
                ).clip(RoundedCornerShape(10))
                .shimmer(),
        )
        repeat(4) {
            QuickPicksShimmerItem()
        }
    }
}

@Composable
fun HomeShimmer() {
    Column(modifier = Modifier.fillMaxWidth()) {
        SongsAlbumsLoadingShimmer(
            modifier = Modifier.fillMaxWidth(),
            showMoodChips = false,
        )
        NefyMascotLoadingBox(
            modifier = Modifier.fillMaxWidth().height(120.dp),
            size = 72.dp,
        )
    }
}

@Composable
fun NefyMascotLoadingBox(
    modifier: Modifier = Modifier,
    size: Dp = 72.dp,
) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        NefyMascotLoadingIndicator(size = size)
    }
}

@Composable
private fun NefyMascotLoadingIndicator(size: Dp) {
    val transition = rememberInfiniteTransition(label = "Nefy mascot loading")
    val alpha by transition.animateFloat(
        initialValue = 0.68f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "Nefy mascot alpha",
    )
    Image(
        painter = painterResource(Res.drawable.nefy_icon),
        contentDescription = "Loading Nefy",
        modifier = Modifier.size(size).graphicsLayer { this.alpha = alpha },
    )
}

/**
 * Content-shaped loading state used by Home, Search songs/albums, More Albums,
 * and Recently Played. It deliberately mirrors the loaded layout instead of
 * showing the old centered generic loading indicator.
 */
@Composable
fun SongsAlbumsLoadingShimmer(
    modifier: Modifier = Modifier,
    showMoodChips: Boolean = true,
    topPadding: Dp = 0.dp,
    showMascot: Boolean = false,
) {
    Box(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = topPadding, start = 16.dp, end = 16.dp, bottom = 140.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            if (showMoodChips) {
                LoadingMoodChipRow()
            }
            LoadingSectionHeadingShimmer(width = 170.dp)
            LoadingArtworkGrid(rows = 2)
            LoadingSectionHeadingShimmer(width = 128.dp)
            LoadingArtworkGrid(rows = 1)
        }
        if (showMascot) {
            NefyMascotLoadingBox(
                modifier = Modifier.align(Alignment.BottomCenter).height(112.dp),
                size = 72.dp,
            )
        }
    }
}

@Composable
private fun LoadingMoodChipRow() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        listOf(64.dp, 88.dp, 104.dp, 88.dp, 72.dp).forEach { width ->
            Box(
                modifier = Modifier
                    .width(width)
                    .height(42.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(LocalAppColors.current.shimmerBackground)
                    .shimmer(),
            )
        }
    }
}

@Composable
private fun LoadingSectionHeadingShimmer(width: Dp) {
    Box(
        modifier = Modifier
            .width(width)
            .height(28.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(LocalAppColors.current.shimmerLine)
            .shimmer(),
    )
}

@Composable
private fun LoadingArtworkGrid(rows: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(24.dp)) {
        repeat(rows) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                repeat(2) {
                    LoadingArtworkCard(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun LoadingArtworkCard(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(18.dp))
                .background(LocalAppColors.current.shimmerBackground)
                .shimmer(),
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(0.84f)
                .height(17.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(LocalAppColors.current.shimmerLine)
                .shimmer(),
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(0.66f)
                .height(14.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(LocalAppColors.current.shimmerBackground)
                .shimmer(),
        )
    }
}

@Composable
fun SongsListLoadingShimmer(
    modifier: Modifier = Modifier,
    rows: Int = 5,
) {
    Column(modifier = modifier) {
        repeat(rows) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(LocalAppColors.current.shimmerBackground)
                        .shimmer(),
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.78f)
                            .height(16.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(LocalAppColors.current.shimmerLine)
                            .shimmer(),
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.52f)
                            .height(13.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(LocalAppColors.current.shimmerBackground)
                            .shimmer(),
                    )
                }
            }
        }
    }
}

@Composable
fun ShimmerSearchItem() {
    Row(
        modifier = Modifier
            .padding(vertical = 8.dp, horizontal = 16.dp)
            .wrapContentHeight(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Thumbnail shimmer
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(LocalAppColors.current.shimmerBackground)
                .shimmer()
        )

        Spacer(modifier = Modifier.width(12.dp))

        // Text content shimmer
        Column {
            Box(
                modifier = Modifier
                    .width(200.dp)
                    .height(16.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(LocalAppColors.current.shimmerBackground)
                    .shimmer()
            )

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .width(150.dp)
                    .height(14.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(LocalAppColors.current.shimmerBackground)
                    .shimmer()
            )

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .width(80.dp)
                    .height(12.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(LocalAppColors.current.shimmerBackground)
                    .shimmer()
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ShimmerSearchItemPreview() {
    ShimmerSearchItem()
}
