package com.nefy.app.ui.navigation.destination.home

import kotlinx.serialization.Serializable

@Serializable
data class FriendsDestination(
    val roomCode: String? = null,
    val initialPage: String? = null,
    val playlistInvite: String? = null,
    val playlistId: String? = null,
)
