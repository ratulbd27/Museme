package com.nefy.app.ui.screen.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.maxrave.domain.data.entities.SongEntity
import com.maxrave.domain.utils.connectArtists
import com.nefy.app.extension.formatDuration
import com.nefy.app.ui.component.nefyPressScale
import com.nefy.app.ui.component.rememberHolderPainter
import com.nefy.app.ui.icon.Close
import com.nefy.app.ui.icon.PauseCircle
import com.nefy.app.ui.icon.PlayCircle
import com.nefy.app.ui.icon.SkipNext
import com.nefy.app.ui.icon.SkipPrevious
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.theme.libraryFontFamily
import com.nefy.app.ui.theme.typo
import com.nefy.app.viewModel.SharedViewModel
import com.nefy.app.viewModel.UIEvent
import org.koin.compose.koinInject

private const val PixelPlayerMotionMs = 360

@Composable
private fun PixelPlayerTransportButton(
    enabled: Boolean,
    containerColor: Color,
    contentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    Box(
        modifier = modifier
            .size(48.dp)
            .nefyPressScale(interactionSource = interactionSource)
            .clip(CircleShape)
            .background(containerColor)
            .clickable(
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                enabled = enabled,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

@Composable
private fun PixelPlayerPalette(
    content: @Composable (background: Color, foreground: Color, accent: Color) -> Unit,
) {
    val background = MaterialTheme.colorScheme.surfaceContainerHigh
    val foreground = if (background.luminance() > 0.58f) Color.Black else Color.White
    val accent = MaterialTheme.colorScheme.primary
    content(background, foreground, accent)
}

@Composable
fun PixelMusicMiniPlayer(
    modifier: Modifier,
    sharedViewModel: SharedViewModel = koinInject(),
    onClick: () -> Unit,
    onClose: () -> Unit,
) {
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val controllerState by sharedViewModel.controllerState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    val songEntity = nowPlayingState?.songEntity
    val progress =
        if (timelineState.total > 0L) {
            (timelineState.current.toFloat() / timelineState.total.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }

    PixelPlayerPalette { background, foreground, accent ->
        val interactionSource = remember { MutableInteractionSource() }
        Box(
            modifier = modifier
                .nefyPressScale(interactionSource = interactionSource)
                .clip(RoundedCornerShape(24.dp))
                .background(background)
                .clickable(
                    interactionSource = interactionSource,
                    indication = LocalIndication.current,
                    onClick = onClick,
                ),
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AsyncImage(
                    model =
                        ImageRequest
                            .Builder(LocalPlatformContext.current)
                            .data(songEntity?.thumbnails)
                            .crossfade(500)
                            .build(),
                    placeholder = rememberHolderPainter(),
                    error = rememberHolderPainter(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(44.dp).clip(CircleShape),
                )
                Spacer(Modifier.width(10.dp))
                AnimatedContent(
                    targetState = songEntity?.videoId,
                    modifier = Modifier.weight(1f),
                    transitionSpec = {
                        (fadeIn(tween(PixelPlayerMotionMs)) togetherWith fadeOut(tween(PixelPlayerMotionMs)))
                    },
                    label = "pixelMiniSong",
                ) {
                    Column {
                        Text(
                            text = songEntity?.title.orEmpty(),
                            style = typo().titleSmall.copy(fontFamily = libraryFontFamily(), fontWeight = FontWeight.Bold),
                            color = foreground,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = songEntity?.artistName?.connectArtists().orEmpty(),
                            style = typo().bodySmall.copy(fontFamily = libraryFontFamily()),
                            color = foreground.copy(alpha = 0.72f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                PixelPlayerTransportButton(
                    enabled = controllerState.isPreviousAvailable,
                    containerColor = foreground.copy(alpha = 0.14f),
                    contentColor = foreground,
                    onClick = { sharedViewModel.onUIEvent(UIEvent.Previous) },
                ) {
                    Icon(SimpIcons.SkipPrevious, contentDescription = "Previous", tint = foreground, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(6.dp))
                Crossfade(timelineState.loading, label = "pixelMiniPlayback") {
                    if (it) {
                        Box(
                            modifier = Modifier.size(48.dp).clip(CircleShape).background(accent),
                            contentAlignment = Alignment.Center,
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = foreground, strokeWidth = 2.5.dp)
                        }
                    } else {
                        PixelPlayerTransportButton(
                            enabled = true,
                            containerColor = accent,
                            contentColor = if (accent.luminance() > 0.58f) Color.Black else Color.White,
                            onClick = { sharedViewModel.onUIEvent(UIEvent.PlayPause) },
                        ) {
                            Icon(
                                imageVector = if (controllerState.isPlaying) SimpIcons.PauseCircle else SimpIcons.PlayCircle,
                                contentDescription = if (controllerState.isPlaying) "Pause" else "Play",
                                tint = if (accent.luminance() > 0.58f) Color.Black else Color.White,
                                modifier = Modifier.size(24.dp),
                            )
                        }
                    }
                }
                Spacer(Modifier.width(6.dp))
                PixelPlayerTransportButton(
                    enabled = controllerState.isNextAvailable,
                    containerColor = foreground.copy(alpha = 0.14f),
                    contentColor = foreground,
                    onClick = { sharedViewModel.onUIEvent(UIEvent.Next) },
                ) {
                    Icon(SimpIcons.SkipNext, contentDescription = "Next", tint = foreground, modifier = Modifier.size(22.dp))
                }
            }
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(2.dp),
                color = accent,
                trackColor = Color.Transparent,
            )
        }
    }
}

@Composable
fun PixelMusicFullPlayer(
    sharedViewModel: SharedViewModel,
    onDismiss: () -> Unit,
) {
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val controllerState by sharedViewModel.controllerState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    val songEntity = nowPlayingState?.songEntity
    var sliderValue by remember { mutableFloatStateOf(0f) }
    var isSliding by remember { mutableStateOf(false) }
    val progress =
        if (timelineState.total > 0L) {
            (timelineState.current.toFloat() / timelineState.total.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }

    LaunchedEffect(timelineState.current, timelineState.total, isSliding) {
        if (!isSliding) {
            sliderValue = progress
        }
    }

    PixelPlayerPalette { background, foreground, accent ->
        Column(
            modifier = Modifier.fillMaxSize().background(background).padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                PixelPlayerTransportButton(
                    enabled = true,
                    containerColor = foreground.copy(alpha = 0.12f),
                    contentColor = foreground,
                    onClick = onDismiss,
                    modifier = Modifier.size(42.dp),
                ) {
                    Icon(SimpIcons.Close, contentDescription = "Close", tint = foreground, modifier = Modifier.size(22.dp))
                }
                Text(
                    text = "Now playing",
                    style = typo().titleMedium.copy(fontFamily = libraryFontFamily(), fontWeight = FontWeight.Bold),
                    color = foreground,
                    modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
                )
                Spacer(Modifier.size(42.dp))
            }
            Spacer(Modifier.height(24.dp))
            AnimatedContent(
                targetState = songEntity?.videoId,
                transitionSpec = {
                    (fadeIn(tween(PixelPlayerMotionMs)) togetherWith fadeOut(tween(PixelPlayerMotionMs)))
                },
                label = "pixelFullArtwork",
            ) {
                AsyncImage(
                    model =
                        ImageRequest
                            .Builder(LocalPlatformContext.current)
                            .data(songEntity?.thumbnails)
                            .crossfade(650)
                            .build(),
                    placeholder = rememberHolderPainter(),
                    error = rememberHolderPainter(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp)),
                )
            }
            Spacer(Modifier.height(22.dp))
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = songEntity?.title.orEmpty(),
                    style = typo().headlineLarge.copy(fontFamily = libraryFontFamily(), fontWeight = FontWeight.Bold),
                    color = foreground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = songEntity?.artistName?.connectArtists().orEmpty(),
                    style = typo().bodyLarge.copy(fontFamily = libraryFontFamily()),
                    color = foreground.copy(alpha = 0.72f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(16.dp))
            Slider(
                value = sliderValue,
                onValueChange = {
                    isSliding = true
                    sliderValue = it
                },
                onValueChangeFinished = {
                    sharedViewModel.onUIEvent(UIEvent.UpdateProgress(sliderValue))
                    isSliding = false
                },
                colors =
                    SliderDefaults.colors(
                        thumbColor = accent,
                        activeTrackColor = accent,
                        inactiveTrackColor = foreground.copy(alpha = 0.22f),
                    ),
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatDuration(timelineState.current), style = typo().bodySmall.copy(fontFamily = libraryFontFamily()), color = foreground.copy(alpha = 0.7f))
                Text(formatDuration(timelineState.total), style = typo().bodySmall.copy(fontFamily = libraryFontFamily()), color = foreground.copy(alpha = 0.7f))
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                PixelPlayerTransportButton(
                    enabled = controllerState.isPreviousAvailable,
                    containerColor = foreground.copy(alpha = 0.14f),
                    contentColor = foreground,
                    onClick = { sharedViewModel.onUIEvent(UIEvent.Previous) },
                ) {
                    Icon(SimpIcons.SkipPrevious, contentDescription = "Previous", tint = foreground, modifier = Modifier.size(25.dp))
                }
                PixelPlayerTransportButton(
                    enabled = true,
                    containerColor = accent,
                    contentColor = if (accent.luminance() > 0.58f) Color.Black else Color.White,
                    onClick = { sharedViewModel.onUIEvent(UIEvent.PlayPause) },
                    modifier = Modifier.size(64.dp),
                ) {
                    Icon(
                        imageVector = if (controllerState.isPlaying) SimpIcons.PauseCircle else SimpIcons.PlayCircle,
                        contentDescription = if (controllerState.isPlaying) "Pause" else "Play",
                        tint = if (accent.luminance() > 0.58f) Color.Black else Color.White,
                        modifier = Modifier.size(32.dp),
                    )
                }
                PixelPlayerTransportButton(
                    enabled = controllerState.isNextAvailable,
                    containerColor = foreground.copy(alpha = 0.14f),
                    contentColor = foreground,
                    onClick = { sharedViewModel.onUIEvent(UIEvent.Next) },
                ) {
                    Icon(SimpIcons.SkipNext, contentDescription = "Next", tint = foreground, modifier = Modifier.size(25.dp))
                }
            }
            Spacer(Modifier.height(18.dp))
            Text(
                text = "Swipe artwork or use the controls to move through your queue.",
                style = typo().bodySmall.copy(fontFamily = libraryFontFamily()),
                color = foreground.copy(alpha = 0.6f),
            )
        }
    }
}
