package com.nefy.app.ui.screen.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.kmpalette.loader.rememberNetworkLoader
import com.kmpalette.rememberDominantColorState
import com.maxrave.domain.data.model.browse.album.Track
import com.maxrave.domain.mediaservice.handler.MediaPlayerHandler
import com.maxrave.domain.mediaservice.handler.RepeatState
import com.nefy.app.expect.ui.PlatformCastButton
import com.nefy.app.extension.rgbFactor
import com.nefy.app.extension.formatDuration
import com.nefy.app.ui.component.AddToPlaylistModalBottomSheet
import com.nefy.app.ui.component.FullscreenLyricsSheet
import com.nefy.app.ui.component.InfoPlayerBottomSheet
import com.nefy.app.ui.component.QueueBottomSheet
import com.nefy.app.ui.component.nefyPressScale
import com.nefy.app.ui.component.rememberHolderPainter
import com.nefy.app.ui.icon.Close
import com.nefy.app.ui.icon.FavoriteBorder
import com.nefy.app.ui.icon.Info
import com.nefy.app.ui.icon.KeyboardArrowDown
import com.nefy.app.ui.icon.MoreVert
import com.nefy.app.ui.icon.Pause
import com.nefy.app.ui.icon.PlayArrow
import com.nefy.app.ui.icon.PlaylistAdd
import com.nefy.app.ui.icon.QueueMusic
import com.nefy.app.ui.icon.Repeat
import com.nefy.app.ui.icon.RepeatOne
import com.nefy.app.ui.icon.Shuffle
import com.nefy.app.ui.icon.SkipNext
import com.nefy.app.ui.icon.SkipPrevious
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.icon.Subtitles
import com.nefy.app.ui.navigation.destination.list.ArtistDestination
import com.nefy.app.ui.theme.libraryFontFamily
import com.nefy.app.ui.theme.typo
import com.nefy.app.viewModel.NowPlayingBottomSheetUIEvent
import com.nefy.app.viewModel.NowPlayingBottomSheetViewModel
import com.nefy.app.viewModel.SharedViewModel
import com.nefy.app.viewModel.UIEvent
import io.ktor.client.HttpClient
import io.ktor.client.engine.cio.CIO
import io.ktor.http.Url
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlin.math.PI
import kotlin.math.sin
import androidx.navigation.NavController
import org.koin.compose.koinInject
import org.koin.compose.viewmodel.koinViewModel
import nefy.composeapp.generated.resources.Res
import nefy.composeapp.generated.resources.artists
import org.jetbrains.compose.resources.stringResource

private const val PixelPlayerMotionMs = 360
private val PixelPlayerArtworkCorners = RoundedCornerShape(18.dp)
private val PixelPlayerActionCorners = RoundedCornerShape(24.dp)
private val PixelPlayerMetadataOuterCorners = 50.dp
private val PixelPlayerTransportCorners = RoundedCornerShape(26.dp)
private val PixelPlayerToggleCorners = RoundedCornerShape(60.dp)

@Composable
private fun PixelPlayerActionButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier.size(64.dp),
    shape: Shape = RoundedCornerShape(22.dp),
    containerColor: Color,
    contentColor: Color,
    enabled: Boolean = true,
    content: @Composable () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    Box(
        modifier = modifier
            .nefyPressScale(interactionSource = interactionSource)
            .clip(shape)
            .background(containerColor.copy(alpha = if (enabled) 1f else 0.45f))
            .clickable(
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                enabled = enabled,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

@Composable
private fun PixelPlayerPalette(
    artworkUrl: String?,
    content: @Composable (background: Color, foreground: Color, primary: Color, secondary: Color, tertiary: Color) -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val paletteHttpClient = remember { HttpClient(CIO) }
    DisposableEffect(paletteHttpClient) {
        onDispose { paletteHttpClient.close() }
    }
    val networkLoader = rememberNetworkLoader(paletteHttpClient)
    val dominantColorState = rememberDominantColorState(
        defaultColor = scheme.surfaceContainerHigh,
        defaultOnColor = scheme.onSurface,
        loader = networkLoader,
    )
    LaunchedEffect(artworkUrl) {
        artworkUrl?.takeIf { it.isNotBlank() }?.let { url ->
            runCatching { dominantColorState.updateFrom(Url(url)) }
        }
    }
    val rawBackground = dominantColorState.color
    val isLight = scheme.background.luminance() > 0.5f
    val targetBackground = if (isLight) {
        lerp(rawBackground, Color.White, 0.72f)
    } else {
        rawBackground.rgbFactor(0.30f)
    }
    val background by animateColorAsState(
        targetValue = targetBackground,
        animationSpec = tween(500, easing = FastOutSlowInEasing),
        label = "pixelArtworkBackground",
    )
    val foreground = if (background.luminance() > 0.58f) Color(0xFF241820) else Color(0xFFFFF5F7)
    content(background, foreground, scheme.primary, scheme.secondary, scheme.tertiary)
}

@Composable
private fun PixelMusicWaveSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    activeTrackColor: Color,
    inactiveTrackColor: Color,
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val trackEdgePaddingPx = with(density) { 8.dp.toPx() }
    var isPointerSeeking by remember { mutableStateOf(false) }
    val isInteracting = isPointerSeeking
    val waveAmplitude by animateDpAsState(
        targetValue = if (isPlaying && !isInteracting) 4.dp else 0.dp,
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "pixelWaveAmplitude",
    )
    val thumbInteractionFraction by animateFloatAsState(
        targetValue = if (isInteracting) 1f else 0f,
        animationSpec = tween(250, easing = FastOutSlowInEasing),
        label = "pixelWaveThumbInteraction",
    )
    val renderedProgress by animateFloatAsState(
        targetValue = value.coerceIn(0f, 1f),
        animationSpec = if (isInteracting) tween(0) else tween(180, easing = FastOutSlowInEasing),
        label = "pixelWaveRenderedProgress",
    )
    val phaseShift = remember { Animatable(0f) }
    LaunchedEffect(isPlaying, isInteracting) {
        if (isPlaying && !isInteracting) {
            val fullRotation = (2f * PI).toFloat()
            while (true) {
                val start = phaseShift.value % fullRotation
                phaseShift.snapTo(start)
                phaseShift.animateTo(
                    targetValue = start + fullRotation,
                    animationSpec = tween(900, easing = LinearEasing),
                )
            }
        } else {
            phaseShift.animateTo(0f, tween(220, easing = FastOutSlowInEasing))
        }
    }

    Box(
        modifier = modifier
            .height(32.dp)
            .pointerInput(Unit) {
                // PixelMusic isolates vertical drag events inside the waveform area so the
                // parent player-sheet gesture never starts while the user is scrubbing.
                detectVerticalDragGestures(
                    onVerticalDrag = { change, _ -> change.consume() },
                )
            },
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val trackHeightPx = 5.dp.toPx()
            val left = 8.dp.toPx()
            val right = (size.width - 8.dp.toPx()).coerceAtLeast(left)
            val centerY = size.height / 2f
            val trackWidth = (right - left).coerceAtLeast(0f)
            val normalizedValue = renderedProgress.coerceIn(0f, 1f)
            val thumbWidth = lerp(16.dp.toPx(), trackHeightPx * 1.2f, thumbInteractionFraction)
            val thumbHeight = lerp(16.dp.toPx(), 24.dp.toPx(), thumbInteractionFraction)
            val rawThumbCenterX = left + trackWidth * normalizedValue
            val thumbCenterX = rawThumbCenterX.coerceIn(
                left + thumbWidth / 2f,
                right - thumbWidth / 2f,
            )
            val thumbGap = 12.dp.toPx()
            val activeEnd = (thumbCenterX - thumbGap).coerceAtLeast(left)
            val inactiveStart = (thumbCenterX + thumbGap).coerceAtMost(right)
            val waveAmplitudePx = waveAmplitude.toPx()
            val waveLengthPx = 64.dp.toPx().coerceAtLeast(1f)
            val phase = phaseShift.value
            val waveFrequency = (2f * PI).toFloat() / waveLengthPx

            drawLine(
                color = inactiveTrackColor,
                start = Offset(inactiveStart, centerY),
                end = Offset(right, centerY),
                strokeWidth = trackHeightPx,
                cap = StrokeCap.Round,
            )
            if (activeEnd > left) {
                if (waveAmplitudePx > 0.01f) {
                    val wavePath = Path()
                    fun yAt(x: Float): Float = centerY + sin(waveFrequency * (x - left) + phase) * waveAmplitudePx
                    var previousX = left
                    var previousY = yAt(previousX)
                    wavePath.moveTo(previousX, previousY)
                    val waveStep = (waveLengthPx / 20f).coerceAtLeast(1.2f)
                    var x = previousX + waveStep
                    while (x < activeEnd) {
                        val y = yAt(x)
                        val midX = (previousX + x) / 2f
                        val midY = (previousY + y) / 2f
                        wavePath.quadraticTo(previousX, previousY, midX, midY)
                        previousX = x
                        previousY = y
                        x += waveStep
                    }
                    wavePath.quadraticTo(previousX, previousY, activeEnd, yAt(activeEnd))
                    drawPath(
                        path = wavePath,
                        color = activeTrackColor,
                        style = Stroke(width = trackHeightPx, cap = StrokeCap.Round, join = StrokeJoin.Round),
                    )
                } else {
                    drawLine(
                        color = activeTrackColor,
                        start = Offset(left, centerY),
                        end = Offset(activeEnd, centerY),
                        strokeWidth = trackHeightPx,
                        cap = StrokeCap.Round,
                    )
                }
            }

            drawRoundRect(
                color = activeTrackColor,
                topLeft = Offset(thumbCenterX - thumbWidth / 2f, centerY - thumbHeight / 2f),
                size = Size(thumbWidth, thumbHeight),
                cornerRadius = CornerRadius(thumbWidth / 2f),
            )
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(trackEdgePaddingPx) {
                    fun valueForX(rawX: Float): Float {
                        val edgePadding = trackEdgePaddingPx.coerceIn(0f, size.width / 2f)
                        val trackStart = edgePadding
                        val trackEnd = size.width - edgePadding
                        val trackWidth = (trackEnd - trackStart).coerceAtLeast(1f)
                        return ((rawX - trackStart) / trackWidth).coerceIn(0f, 1f)
                    }

                    awaitEachGesture {
                        var latestGestureValue = value.coerceIn(0f, 1f)
                        try {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            isPointerSeeking = true
                            down.consume()
                            latestGestureValue = valueForX(down.position.x)
                            onValueChange(latestGestureValue)

                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.pressed || it.position != it.previousPosition }
                                    ?: break
                                if (!change.pressed) {
                                    change.consume()
                                    break
                                }
                                if (change.position != change.previousPosition) {
                                    change.consume()
                                    latestGestureValue = valueForX(change.position.x)
                                    onValueChange(latestGestureValue)
                                }
                            }
                            onValueChangeFinished()
                        } finally {
                            isPointerSeeking = false
                        }
                    }
                },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PixelMusicArtworkCarousel(
    queue: List<Track>,
    currentOrderIndex: Int,
    pagerState: PagerState,
    modifier: Modifier = Modifier,
) {
    HorizontalPager(
        state = pagerState,
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f),
        beyondViewportPageCount = 1,
    ) { page ->
        val track = queue.getOrNull(page)
        val artworkUrl = track?.thumbnails?.maxByOrNull { it.width }?.url
        AsyncImage(
            model = ImageRequest.Builder(LocalPlatformContext.current)
                .data(artworkUrl)
                .crossfade(500)
                .build(),
            placeholder = rememberHolderPainter(),
            error = rememberHolderPainter(),
            contentDescription = track?.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .clip(PixelPlayerArtworkCorners),
        )
    }
}

@Composable
fun PixelMusicMiniPlayer(
    modifier: Modifier,
    sharedViewModel: SharedViewModel = koinInject(),
    onClick: () -> Unit,
    onClose: () -> Unit,
) {
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val controllerState by sharedViewModel.controllerState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    val songEntity = nowPlayingState?.songEntity
    val progress = if (timelineState.total > 0L) {
        (timelineState.current.toFloat() / timelineState.total.toFloat()).coerceIn(0f, 1f)
    } else 0f

    PixelPlayerPalette(songEntity?.thumbnails) { background, foreground, accent, _, _ ->
        val interactionSource = remember { MutableInteractionSource() }
        Box(
            modifier = modifier
                .nefyPressScale(interactionSource = interactionSource)
                .clip(RoundedCornerShape(24.dp))
                .background(background)
                .clickable(
                    interactionSource = interactionSource,
                    indication = LocalIndication.current,
                    onClick = onClick,
                ),
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalPlatformContext.current).data(songEntity?.thumbnails).crossfade(500).build(),
                    placeholder = rememberHolderPainter(),
                    error = rememberHolderPainter(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(44.dp).clip(CircleShape),
                )
                Spacer(Modifier.width(10.dp))
                AnimatedContent(
                    targetState = songEntity?.videoId,
                    modifier = Modifier.weight(1f),
                    transitionSpec = { fadeIn(tween(PixelPlayerMotionMs)) togetherWith fadeOut(tween(PixelPlayerMotionMs)) },
                    label = "pixelMiniSong",
                ) {
                    Column {
                        Text(
                            text = songEntity?.title.orEmpty(),
                            style = typo().titleSmall.copy(fontFamily = libraryFontFamily(), fontWeight = FontWeight.Bold),
                            color = foreground,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = songEntity?.artistName?.joinToString(", ").orEmpty(),
                            style = typo().bodySmall.copy(fontFamily = libraryFontFamily()),
                            color = foreground.copy(alpha = 0.72f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                PixelPlayerActionButton(
                    enabled = controllerState.isPreviousAvailable,
                    containerColor = foreground.copy(alpha = 0.14f),
                    contentColor = foreground,
                    onClick = { sharedViewModel.onUIEvent(UIEvent.Previous) },
                    modifier = Modifier.size(48.dp),
                    shape = CircleShape,
                ) {
                    Icon(SimpIcons.SkipPrevious, contentDescription = "Previous", tint = foreground, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(6.dp))
                Crossfade(timelineState.loading, label = "pixelMiniPlayback") {
                    if (it) {
                        Box(modifier = Modifier.size(48.dp).clip(CircleShape).background(accent), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = foreground, strokeWidth = 2.5.dp)
                        }
                    } else {
                        PixelPlayerActionButton(
                            enabled = true,
                            containerColor = accent,
                            contentColor = if (accent.luminance() > 0.58f) Color.Black else Color.White,
                            onClick = { sharedViewModel.onUIEvent(UIEvent.PlayPause) },
                            modifier = Modifier.size(48.dp),
                            shape = CircleShape,
                        ) {
                            Icon(
                                imageVector = if (controllerState.isPlaying) SimpIcons.Pause else SimpIcons.PlayArrow,
                                contentDescription = if (controllerState.isPlaying) "Pause" else "Play",
                                tint = if (accent.luminance() > 0.58f) Color.Black else Color.White,
                                modifier = Modifier.size(24.dp),
                            )
                        }
                    }
                }
                Spacer(Modifier.width(6.dp))
                PixelPlayerActionButton(
                    enabled = controllerState.isNextAvailable,
                    containerColor = foreground.copy(alpha = 0.14f),
                    contentColor = foreground,
                    onClick = { sharedViewModel.onUIEvent(UIEvent.Next) },
                    modifier = Modifier.size(48.dp),
                    shape = CircleShape,
                ) {
                    Icon(SimpIcons.SkipNext, contentDescription = "Next", tint = foreground, modifier = Modifier.size(22.dp))
                }
            }
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(2.dp),
                color = accent,
                trackColor = Color.Transparent,
            )
        }
    }
}

private enum class PixelPlaybackButton { Previous, PlayPause, Next }

@Composable
private fun PixelMusicPlaybackControls(
    controllerState: com.maxrave.domain.mediaservice.handler.ControlState,
    foreground: Color,
    primary: Color,
    secondary: Color,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
) {
    var lastClicked by remember { mutableStateOf<PixelPlaybackButton?>(null) }
    var playPauseVisualState by remember { mutableStateOf(controllerState.isPlaying) }
    var pendingPlayPauseState by remember { mutableStateOf<Boolean?>(null) }
    val isPlayPauseLocked = lastClicked == PixelPlaybackButton.Previous || lastClicked == PixelPlaybackButton.Next
    val playPauseCorner by animateDpAsState(
        targetValue = if (!playPauseVisualState) 60.dp else 26.dp,
        animationSpec = tween(220, easing = FastOutSlowInEasing),
        label = "pixelPlayPauseCorner",
    )
    LaunchedEffect(controllerState.isPlaying) {
        if (controllerState.isPlaying) {
            pendingPlayPauseState = true
        } else if (lastClicked != PixelPlaybackButton.PlayPause) {
            kotlinx.coroutines.delay(220)
            if (!controllerState.isPlaying) pendingPlayPauseState = false
        } else {
            pendingPlayPauseState = false
        }
    }
    LaunchedEffect(isPlayPauseLocked, pendingPlayPauseState) {
        if (!isPlayPauseLocked) {
            pendingPlayPauseState?.let {
                playPauseVisualState = it
                pendingPlayPauseState = null
            }
        }
    }
    LaunchedEffect(lastClicked) {
        if (lastClicked != null) {
            kotlinx.coroutines.delay(220)
            lastClicked = null
        }
    }
    Row(
        modifier = Modifier.fillMaxWidth().height(90.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        fun weightFor(button: PixelPlaybackButton): Float = when (lastClicked) {
            button -> 1.12f
            null -> 1f
            else -> 0.65f
        }
        val previousWeight by animateFloatAsState(weightFor(PixelPlaybackButton.Previous), spring(dampingRatio = 0.82f, stiffness = 620f), label = "pixelPreviousWeight")
        val playWeight by animateFloatAsState(weightFor(PixelPlaybackButton.PlayPause), spring(dampingRatio = 0.82f, stiffness = 620f), label = "pixelPlayWeight")
        val nextWeight by animateFloatAsState(weightFor(PixelPlaybackButton.Next), spring(dampingRatio = 0.82f, stiffness = 620f), label = "pixelNextWeight")
        PixelPlayerActionButton(
            onClick = { lastClicked = PixelPlaybackButton.Previous; onPrevious() },
            modifier = Modifier.weight(previousWeight).height(90.dp),
            shape = CircleShape,
            containerColor = secondary,
            contentColor = foreground,
        ) {
            Icon(SimpIcons.SkipPrevious, contentDescription = "Previous", tint = foreground, modifier = Modifier.size(34.dp))
        }
        PixelPlayerActionButton(
            onClick = { lastClicked = PixelPlaybackButton.PlayPause; onPlayPause() },
            modifier = Modifier.weight(playWeight).height(90.dp),
            shape = RoundedCornerShape(playPauseCorner),
            containerColor = primary,
            contentColor = if (primary.luminance() > 0.58f) Color.Black else Color.White,
        ) {
            Crossfade(targetState = playPauseVisualState, animationSpec = tween(220, easing = FastOutSlowInEasing), label = "pixelPlayIcon") { playing ->
                Icon(
                    imageVector = if (playing) SimpIcons.Pause else SimpIcons.PlayArrow,
                    contentDescription = if (playing) "Pause" else "Play",
                    tint = if (primary.luminance() > 0.58f) Color.Black else Color.White,
                    modifier = Modifier.size(38.dp),
                )
            }
        }
        PixelPlayerActionButton(
            onClick = { lastClicked = PixelPlaybackButton.Next; onNext() },
            modifier = Modifier.weight(nextWeight).height(90.dp),
            shape = CircleShape,
            containerColor = secondary,
            contentColor = foreground,
        ) {
            Icon(SimpIcons.SkipNext, contentDescription = "Next", tint = foreground, modifier = Modifier.size(34.dp))
        }
    }
}

@Composable
private fun PixelToggleSegment(
    modifier: Modifier,
    active: Boolean,
    activeColor: Color,
    inactiveColor: Color,
    contentColor: Color,
    onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
) {
    val color by animateColorAsState(
        targetValue = if (active) activeColor else inactiveColor,
        animationSpec = tween(250),
        label = "pixelToggleColor",
    )
    val cornerRadius by animateDpAsState(
        targetValue = if (active) 60.dp else 8.dp,
        animationSpec = androidx.compose.animation.core.spring(stiffness = androidx.compose.animation.core.Spring.StiffnessLow),
        label = "pixelToggleCorner",
    )
    Box(
        modifier = modifier
            .height(58.dp)
            .clip(RoundedCornerShape(cornerRadius))
            .background(color)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = contentDescription,
            tint = if (active) {
                if (activeColor.luminance() > 0.58f) Color.Black else Color.White
            } else {
                contentColor.copy(alpha = 0.82f)
            },
            modifier = Modifier.size(24.dp),
        )
    }
}

@Composable
private fun PixelMusicBottomToggleRow(
    modifier: Modifier = Modifier,
    controllerState: com.maxrave.domain.mediaservice.handler.ControlState,
    foreground: Color,
    primary: Color,
    secondary: Color,
    tertiary: Color,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onFavorite: () -> Unit,
) {
    Box(
        modifier = modifier
            .clip(PixelPlayerToggleCorners)
            .background(foreground.copy(alpha = 0.10f))
            .padding(8.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            PixelToggleSegment(
                modifier = Modifier.weight(1f),
                active = controllerState.isShuffle,
                activeColor = primary,
                inactiveColor = Color.Transparent,
                contentColor = foreground,
                onClick = onShuffle,
                icon = SimpIcons.Shuffle,
                contentDescription = "Shuffle",
            )
            PixelToggleSegment(
                modifier = Modifier.weight(1f),
                active = controllerState.repeatState !is RepeatState.None,
                activeColor = secondary,
                inactiveColor = Color.Transparent,
                contentColor = foreground,
                onClick = onRepeat,
                icon = if (controllerState.repeatState is RepeatState.One) SimpIcons.RepeatOne else SimpIcons.Repeat,
                contentDescription = "Repeat",
            )
            PixelToggleSegment(
                modifier = Modifier.weight(1f),
                active = controllerState.isLiked,
                activeColor = tertiary,
                inactiveColor = Color.Transparent,
                contentColor = foreground,
                onClick = onFavorite,
                icon = SimpIcons.FavoriteBorder,
                contentDescription = "Favorite",
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun PixelMusicFullPlayer(
    sharedViewModel: SharedViewModel,
    onDismiss: () -> Unit,
    navController: NavController? = null,
    mediaPlayerHandler: MediaPlayerHandler = koinInject(),
    expansionFractionProvider: () -> Float = { 1f },
) {
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val controllerState by sharedViewModel.controllerState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    val screenDataState by sharedViewModel.nowPlayingScreenData.collectAsStateWithLifecycle()
    val castState by sharedViewModel.castState.collectAsStateWithLifecycle()
    val queueDataState by sharedViewModel.getQueueDataState().collectAsStateWithLifecycle()
    val artworkQueue = queueDataState?.data?.listTracks ?: emptyList()
    val nowPlayingVideoId = nowPlayingState?.track?.videoId
    val currentOrderIndex = deriveOrderIndex(artworkQueue, nowPlayingVideoId)
    val artworkPagerState = rememberPagerState(
        initialPage = currentOrderIndex.coerceAtLeast(0),
        pageCount = { artworkQueue.size.coerceAtLeast(1) },
    )
    var isAnimatingFromPlayer by remember { mutableStateOf(false) }
    var isUserDraggingActive by remember { mutableStateOf(false) }
    var allowRealtimeUpdates by remember { mutableStateOf(false) }
    val initialContentOffsetPx = with(LocalDensity.current) { 24.dp.toPx() }

    LaunchedEffect(expansionFractionProvider) {
        snapshotFlow {
            val expansion = expansionFractionProvider().coerceIn(0f, 1f)
            val revealAlpha = ((expansion - 0.25f).coerceIn(0f, 0.75f) / 0.75f)
            expansion >= 0.985f && revealAlpha >= 0.95f
        }.distinctUntilChanged()
            .collect { allowRealtimeUpdates = it }
    }
    val songEntity = nowPlayingState?.songEntity
    val queueArtworkUrl = artworkQueue.getOrNull(currentOrderIndex)?.thumbnails?.maxByOrNull { it.width }?.url
    val artistChannelId = songEntity?.artistId?.firstOrNull()?.takeIf { it.isNotEmpty() } ?: screenDataState.songInfoData?.authorId
    val artworkUrl = queueArtworkUrl ?: songEntity?.thumbnails
    var showFullscreenLyrics by rememberSaveable { mutableStateOf(false) }
    var showQueueBottomSheet by rememberSaveable { mutableStateOf(false) }
    var showInfoBottomSheet by rememberSaveable { mutableStateOf(false) }
    var showAddToPlaylist by rememberSaveable { mutableStateOf(false) }
    var sliderValue by remember { mutableFloatStateOf(0f) }
    var isSliding by remember { mutableStateOf(false) }

    LaunchedEffect(artworkPagerState) {
        snapshotFlow { artworkPagerState.isScrollInProgress to isAnimatingFromPlayer }
            .collect { (scrolling, animating) ->
                isUserDraggingActive = scrolling && !animating
            }
    }

    LaunchedEffect(currentOrderIndex, artworkQueue.size) {
        val target = currentOrderIndex
        if (!isUserDraggingActive &&
            artworkQueue.isNotEmpty() &&
            target in artworkQueue.indices &&
            target != artworkPagerState.currentPage
        ) {
            isAnimatingFromPlayer = true
            try {
                artworkPagerState.animateScrollToPage(target)
            } finally {
                isAnimatingFromPlayer = false
            }
        }
    }

    LaunchedEffect(artworkPagerState, currentOrderIndex, artworkQueue.size) {
        snapshotFlow { artworkPagerState.settledPage }
            .distinctUntilChanged()
            .collect { settled ->
                if (isAnimatingFromPlayer || artworkQueue.isEmpty()) return@collect
                if (settled !in artworkQueue.indices || settled == currentOrderIndex) return@collect
                runCatching {
                    when (val action = computeSeekAction(settled, currentOrderIndex)) {
                        ArtworkSeekAction.Next -> sharedViewModel.onUIEvent(UIEvent.Next)
                        ArtworkSeekAction.Previous -> sharedViewModel.onUIEvent(UIEvent.SkipToPrevious)
                        is ArtworkSeekAction.Skip -> mediaPlayerHandler.playMediaItemInMediaSource(action.index)
                        ArtworkSeekAction.NoOp -> Unit
                    }
                }
            }
    }

    LaunchedEffect(artworkQueue.size) {
        if (artworkQueue.isNotEmpty() && artworkPagerState.currentPage >= artworkQueue.size) {
            runCatching { artworkPagerState.scrollToPage(artworkQueue.lastIndex) }
        }
    }

    val progress = if (timelineState.total > 0L) {
        (timelineState.current.toFloat() / timelineState.total.toFloat()).coerceIn(0f, 1f)
    } else 0f
    val displayedProgress = if (allowRealtimeUpdates || isSliding) progress else sliderValue
    val displayedCurrent = if (allowRealtimeUpdates || isSliding) {
        timelineState.current
    } else {
        (displayedProgress * timelineState.total.coerceAtLeast(0L)).toLong()
    }
    LaunchedEffect(timelineState.current, timelineState.total, isSliding, allowRealtimeUpdates) {
        if (!isSliding && allowRealtimeUpdates) sliderValue = progress
    }

    if (showFullscreenLyrics && navController != null) {
        FullscreenLyricsSheet(
            sharedViewModel = sharedViewModel,
            navController = navController,
            color = MaterialTheme.colorScheme.primary,
        ) { showFullscreenLyrics = false }
    }
    if (showQueueBottomSheet) QueueBottomSheet(onDismiss = { showQueueBottomSheet = false })
    if (showInfoBottomSheet) InfoPlayerBottomSheet(onDismiss = { showInfoBottomSheet = false })
    if (showAddToPlaylist) {
        val bottomSheetViewModel: NowPlayingBottomSheetViewModel = koinViewModel()
        val uiState by bottomSheetViewModel.uiState.collectAsStateWithLifecycle()
        LaunchedEffect(Unit) {
            bottomSheetViewModel.resetPlaylists()
            bottomSheetViewModel.setSongEntity(null)
        }
        AddToPlaylistModalBottomSheet(
            isBottomSheetVisible = true,
            listLocalPlaylist = uiState.listLocalPlaylist,
            listYouTubePlaylist = uiState.listYouTubePlaylist,
            onDismiss = { showAddToPlaylist = false },
            onClick = { playlist ->
                bottomSheetViewModel.onUIEvent(NowPlayingBottomSheetUIEvent.AddToPlaylist(playlist.id))
                showAddToPlaylist = false
            },
            onYTPlaylistClick = { playlist ->
                bottomSheetViewModel.onUIEvent(NowPlayingBottomSheetUIEvent.AddToYouTubePlaylist(playlist.browseId))
                showAddToPlaylist = false
            },
            videoId = uiState.songUIState.videoId,
        )
    }

    PixelPlayerPalette(artworkUrl) { background, foreground, primary, secondary, tertiary ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(background)
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
                .graphicsLayer {
                    val expansion = expansionFractionProvider().coerceIn(0f, 1f)
                    val revealAlpha = ((expansion - 0.25f).coerceIn(0f, 0.75f) / 0.75f)
                    alpha = revealAlpha
                    translationY = initialContentOffsetPx * (1f - revealAlpha)
                },
            verticalArrangement = Arrangement.SpaceAround,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().height(56.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PixelPlayerActionButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(42.dp),
                    shape = CircleShape,
                    containerColor = foreground.copy(alpha = 0.70f),
                    contentColor = foreground,
                ) {
                    Icon(SimpIcons.KeyboardArrowDown, contentDescription = "Collapse player", tint = primary, modifier = Modifier.size(26.dp))
                }
                Text(
                    text = "Now Playing",
                    modifier = Modifier.padding(start = 18.dp),
                    style = typo().headlineSmall.copy(fontFamily = libraryFontFamily(), fontWeight = FontWeight.Bold),
                    color = foreground,
                )
                Spacer(Modifier.weight(1f))
                PixelPlayerActionButton(
                    onClick = {},
                    modifier = Modifier.size(height = 42.dp, width = 50.dp),
                    shape = RoundedCornerShape(topStart = 50.dp, topEnd = 6.dp, bottomStart = 50.dp, bottomEnd = 6.dp),
                    containerColor = foreground.copy(alpha = if (castState.isRemote) 0.70f else 0.10f),
                    contentColor = foreground,
                ) {
                    PlatformCastButton(modifier = Modifier.size(24.dp), tint = primary)
                }
                Spacer(Modifier.width(8.dp))
                PixelPlayerActionButton(
                    onClick = { showQueueBottomSheet = true },
                    modifier = Modifier.size(height = 42.dp, width = 50.dp),
                    shape = RoundedCornerShape(topStart = 6.dp, topEnd = 50.dp, bottomStart = 6.dp, bottomEnd = 50.dp),
                    containerColor = foreground.copy(alpha = 0.10f),
                    contentColor = foreground,
                ) {
                    Icon(SimpIcons.QueueMusic, contentDescription = "Queue", tint = primary, modifier = Modifier.size(24.dp))
                }
            }

            if (artworkQueue.isNotEmpty()) {
                PixelMusicArtworkCarousel(
                    queue = artworkQueue,
                    currentOrderIndex = currentOrderIndex,
                    pagerState = artworkPagerState,
                    modifier = Modifier.fillMaxWidth(),
                )
            } else {
                AnimatedContent(
                    targetState = songEntity?.videoId,
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                    transitionSpec = { fadeIn(tween(420)) togetherWith fadeOut(tween(260)) },
                    label = "pixelArtworkTransition",
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalPlatformContext.current).data(songEntity?.thumbnails).crossfade(500).build(),
                        placeholder = rememberHolderPainter(),
                        error = rememberHolderPainter(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().clip(PixelPlayerArtworkCorners),
                    )
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().heightIn(min = 70.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = songEntity?.title.orEmpty(),
                        style = typo().headlineSmall.copy(fontFamily = libraryFontFamily(), fontWeight = FontWeight.Bold),
                        color = foreground,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = songEntity?.artistName?.joinToString(", ").orEmpty(),
                        style = typo().titleMedium.copy(fontFamily = libraryFontFamily()),
                        color = foreground.copy(alpha = 0.76f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.clickable(enabled = navController != null && artistChannelId != null) {
                            val channelId = artistChannelId
                            if (channelId != null && navController != null) {
                                onDismiss()
                                navController.navigate(ArtistDestination(channelId = channelId))
                            }
                        },
                    )
                }
                Spacer(Modifier.width(8.dp))
                PixelPlayerActionButton(
                    onClick = { showFullscreenLyrics = true },
                    enabled = navController != null,
                    modifier = Modifier.size(width = 44.dp, height = 48.dp),
                    shape = RoundedCornerShape(topStart = 50.dp, bottomStart = 50.dp, topEnd = 6.dp, bottomEnd = 6.dp),
                    containerColor = foreground.copy(alpha = 0.10f),
                    contentColor = foreground,
                ) {
                    Icon(SimpIcons.Subtitles, contentDescription = "Lyrics", tint = foreground, modifier = Modifier.size(24.dp))
                }
                PixelPlayerActionButton(
                    onClick = { showInfoBottomSheet = true },
                    modifier = Modifier.size(width = 44.dp, height = 48.dp),
                    shape = RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp, topEnd = 50.dp, bottomEnd = 50.dp),
                    containerColor = foreground.copy(alpha = 0.10f),
                    contentColor = foreground,
                ) {
                    Icon(SimpIcons.MoreVert, contentDescription = "More player actions", tint = foreground, modifier = Modifier.size(24.dp))
                }
                }

                PixelMusicWaveSlider(
                value = displayedProgress,
                onValueChange = {
                    sliderValue = it
                    isSliding = true
                },
                onValueChangeFinished = {
                    sharedViewModel.onUIEvent(UIEvent.UpdateProgress(sliderValue))
                    isSliding = false
                },
                activeTrackColor = foreground,
                inactiveTrackColor = foreground.copy(alpha = 0.28f),
                isPlaying = controllerState.isPlaying && allowRealtimeUpdates,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatDuration(displayedCurrent), style = typo().labelLarge.copy(fontFamily = libraryFontFamily(), fontWeight = FontWeight.SemiBold), color = foreground)
                    Text(formatDuration(timelineState.total), style = typo().labelLarge.copy(fontFamily = libraryFontFamily(), fontWeight = FontWeight.SemiBold), color = foreground)
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                PixelMusicPlaybackControls(
                controllerState = controllerState,
                foreground = foreground,
                primary = primary,
                secondary = secondary,
                onPrevious = { sharedViewModel.onUIEvent(UIEvent.Previous) },
                onPlayPause = { sharedViewModel.onUIEvent(UIEvent.PlayPause) },
                    onNext = { sharedViewModel.onUIEvent(UIEvent.Next) },
                )
                Spacer(Modifier.height(14.dp))
                PixelMusicBottomToggleRow(
                modifier = Modifier.fillMaxWidth().heightIn(min = 66.dp, max = 86.dp).padding(horizontal = 26.dp),
                controllerState = controllerState,
                foreground = foreground,
                primary = primary,
                secondary = secondary,
                tertiary = tertiary,
                onShuffle = { sharedViewModel.onUIEvent(UIEvent.Shuffle) },
                onRepeat = { sharedViewModel.onUIEvent(UIEvent.Repeat) },
                    onFavorite = { sharedViewModel.onUIEvent(UIEvent.ToggleLike) },
                )
            }
        }
    }
}
