package com.nefy.app.ui.screen.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.PI
import kotlin.math.sin
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.maxrave.domain.data.entities.SongEntity
import com.maxrave.domain.utils.connectArtists
import com.nefy.app.extension.formatDuration
import com.nefy.app.ui.component.AddToPlaylistModalBottomSheet
import com.nefy.app.ui.component.FullscreenLyricsSheet
import com.nefy.app.ui.component.InfoPlayerBottomSheet
import com.nefy.app.ui.component.QueueBottomSheet
import com.nefy.app.ui.component.nefyPressScale
import com.nefy.app.ui.component.rememberHolderPainter
import com.nefy.app.ui.icon.Close
import com.nefy.app.ui.icon.FavoriteBorder
import com.nefy.app.ui.icon.Info
import com.nefy.app.ui.icon.PlaylistAdd
import com.nefy.app.ui.icon.QueueMusic
import com.nefy.app.ui.icon.Subtitles
import com.nefy.app.ui.icon.PauseCircle
import com.nefy.app.ui.icon.PlayCircle
import com.nefy.app.ui.icon.SkipNext
import com.nefy.app.ui.icon.SkipPrevious
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.theme.libraryFontFamily
import com.nefy.app.ui.theme.typo
import com.nefy.app.ui.navigation.destination.list.ArtistDestination
import com.nefy.app.viewModel.NowPlayingBottomSheetUIEvent
import com.nefy.app.viewModel.NowPlayingBottomSheetViewModel
import com.nefy.app.viewModel.SharedViewModel
import com.nefy.app.viewModel.UIEvent
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import org.koin.compose.viewmodel.koinViewModel
import nefy.composeapp.generated.resources.Res
import nefy.composeapp.generated.resources.artists
import nefy.composeapp.generated.resources.description
import nefy.composeapp.generated.resources.lyrics

private const val PixelPlayerMotionMs = 360

@Composable
private fun PixelPlayerTransportButton(
    enabled: Boolean,
    containerColor: Color,
    contentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.size(48.dp),
    content: @Composable () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    Box(
        modifier = modifier
            .nefyPressScale(interactionSource = interactionSource)
            .clip(CircleShape)
            .background(containerColor)
            .clickable(
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                enabled = enabled,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

@Composable
private fun PixelPlayerPalette(
    content: @Composable (background: Color, foreground: Color, accent: Color) -> Unit,
) {
    val background = MaterialTheme.colorScheme.surfaceContainerHigh
    val foreground = if (background.luminance() > 0.58f) Color.Black else Color.White
    val accent = MaterialTheme.colorScheme.primary
    content(background, foreground, accent)
}

@Composable
private fun PixelMusicWaveSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    activeTrackColor: Color,
    inactiveTrackColor: Color,
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isDragged by interactionSource.collectIsDraggedAsState()
    val isPressed by interactionSource.collectIsPressedAsState()
    val isInteracting = isDragged || isPressed
    val waveAmplitude by animateDpAsState(
        targetValue = if (isPlaying && !isInteracting) 3.dp else 0.dp,
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "pixelWaveAmplitude",
    )
    val thumbInteractionFraction by animateFloatAsState(
        targetValue = if (isInteracting) 1f else 0f,
        animationSpec = tween(250, easing = FastOutSlowInEasing),
        label = "pixelWaveThumbInteraction",
    )
    val phaseShift = remember { Animatable(0f) }
    LaunchedEffect(isPlaying, isInteracting) {
        if (isPlaying && !isInteracting) {
            val fullRotation = (2f * PI).toFloat()
            while (true) {
                val start = phaseShift.value % fullRotation
                phaseShift.snapTo(start)
                phaseShift.animateTo(
                    targetValue = start + fullRotation,
                    animationSpec = tween(2000, easing = LinearEasing),
                )
            }
        } else {
            phaseShift.animateTo(0f, tween(220, easing = FastOutSlowInEasing))
        }
    }

    Box(modifier = modifier.height(32.dp)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val trackHeightPx = 6.dp.toPx()
            val left = 8.dp.toPx()
            val right = (size.width - 8.dp.toPx()).coerceAtLeast(left)
            val centerY = size.height / 2f
            val trackWidth = (right - left).coerceAtLeast(0f)
            val normalizedValue = value.coerceIn(0f, 1f)
            val thumbCenterX = left + trackWidth * normalizedValue
            val thumbGap = 4.dp.toPx() * thumbInteractionFraction
            val activeEnd = (thumbCenterX - thumbGap).coerceAtLeast(left)
            val waveAmplitudePx = waveAmplitude.toPx()
            val waveLengthPx = 80.dp.toPx().coerceAtLeast(1f)
            val phase = phaseShift.value
            val waveFrequency = (2f * PI).toFloat() / waveLengthPx

            drawLine(
                color = inactiveTrackColor,
                // Keep the interaction gap between the active wave and inactive track,
                // matching PixelMusic’s thumb-to-track separation while scrubbing.
                start = Offset(thumbCenterX, centerY),
                end = Offset(right, centerY),
                strokeWidth = trackHeightPx,
                cap = StrokeCap.Round,
            )

            if (activeEnd > left) {
                if (waveAmplitudePx > 0.01f) {
                    val wavePath = Path()
                    fun yAt(x: Float): Float = centerY + sin(waveFrequency * (x - left) + phase) * waveAmplitudePx
                    var previousX = left
                    var previousY = yAt(previousX)
                    wavePath.moveTo(previousX, previousY)
                    // Twenty samples per wavelength keep the quadratic path smooth without
                    // making the phase animation unnecessarily expensive.
                    val waveStep = (waveLengthPx / 20f).coerceAtLeast(1.2f)
                    var x = previousX + waveStep
                    while (x < activeEnd) {
                        val y = yAt(x)
                        val midX = (previousX + x) / 2f
                        val midY = (previousY + y) / 2f
                        wavePath.quadraticTo(previousX, previousY, midX, midY)
                        previousX = x
                        previousY = y
                        x += waveStep
                    }
                    wavePath.quadraticTo(previousX, previousY, activeEnd, yAt(activeEnd))
                    drawPath(
                        path = wavePath,
                        color = activeTrackColor,
                        style = Stroke(width = trackHeightPx, cap = StrokeCap.Round, join = StrokeJoin.Round),
                    )
                } else {
                    drawLine(
                        color = activeTrackColor,
                        start = Offset(left, centerY),
                        end = Offset(activeEnd, centerY),
                        strokeWidth = trackHeightPx,
                        cap = StrokeCap.Round,
                    )
                }
            }

            // PixelMusic morphs a 16 dp circular thumb into a narrow, 24 dp rounded
            // vertical marker instead of crossfading between unrelated shapes.
            val thumbWidth = lerp(16.dp.toPx(), trackHeightPx * 1.2f, thumbInteractionFraction)
            val thumbHeight = lerp(16.dp.toPx(), 24.dp.toPx(), thumbInteractionFraction)
            drawRoundRect(
                color = activeTrackColor,
                topLeft = Offset(
                    thumbCenterX - thumbWidth / 2f,
                    centerY - thumbHeight / 2f,
                ),
                size = Size(thumbWidth, thumbHeight),
                cornerRadius = CornerRadius(thumbWidth / 2f),
                alpha = 1f,
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            onValueChangeFinished = onValueChangeFinished,
            interactionSource = interactionSource,
            modifier = Modifier.fillMaxSize(),
            colors = SliderDefaults.colors(
                thumbColor = Color.Transparent,
                activeTrackColor = Color.Transparent,
                inactiveTrackColor = Color.Transparent,
                disabledThumbColor = Color.Transparent,
                disabledActiveTrackColor = Color.Transparent,
                disabledInactiveTrackColor = Color.Transparent,
            ),
        )
    }
}

@Composable
fun PixelMusicMiniPlayer(
    modifier: Modifier,
    sharedViewModel: SharedViewModel = koinInject(),
    onClick: () -> Unit,
    onClose: () -> Unit,
) {
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val controllerState by sharedViewModel.controllerState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    val songEntity = nowPlayingState?.songEntity
    val progress =
        if (timelineState.total > 0L) {
            (timelineState.current.toFloat() / timelineState.total.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }

    PixelPlayerPalette { background, foreground, accent ->
        val interactionSource = remember { MutableInteractionSource() }
        Box(
            modifier = modifier
                .nefyPressScale(interactionSource = interactionSource)
                .clip(RoundedCornerShape(24.dp))
                .background(background)
                .clickable(
                    interactionSource = interactionSource,
                    indication = LocalIndication.current,
                    onClick = onClick,
                ),
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AsyncImage(
                    model =
                        ImageRequest
                            .Builder(LocalPlatformContext.current)
                            .data(songEntity?.thumbnails)
                            .crossfade(500)
                            .build(),
                    placeholder = rememberHolderPainter(),
                    error = rememberHolderPainter(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(44.dp).clip(CircleShape),
                )
                Spacer(Modifier.width(10.dp))
                AnimatedContent(
                    targetState = songEntity?.videoId,
                    modifier = Modifier.weight(1f),
                    transitionSpec = {
                        (fadeIn(tween(PixelPlayerMotionMs)) togetherWith fadeOut(tween(PixelPlayerMotionMs)))
                    },
                    label = "pixelMiniSong",
                ) {
                    Column {
                        Text(
                            text = songEntity?.title.orEmpty(),
                            style = typo().titleSmall.copy(fontFamily = libraryFontFamily(), fontWeight = FontWeight.Bold),
                            color = foreground,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = songEntity?.artistName?.connectArtists().orEmpty(),
                            style = typo().bodySmall.copy(fontFamily = libraryFontFamily()),
                            color = foreground.copy(alpha = 0.72f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                PixelPlayerTransportButton(
                    enabled = controllerState.isPreviousAvailable,
                    containerColor = foreground.copy(alpha = 0.14f),
                    contentColor = foreground,
                    onClick = { sharedViewModel.onUIEvent(UIEvent.Previous) },
                ) {
                    Icon(SimpIcons.SkipPrevious, contentDescription = "Previous", tint = foreground, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(6.dp))
                Crossfade(timelineState.loading, label = "pixelMiniPlayback") {
                    if (it) {
                        Box(
                            modifier = Modifier.size(48.dp).clip(CircleShape).background(accent),
                            contentAlignment = Alignment.Center,
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = foreground, strokeWidth = 2.5.dp)
                        }
                    } else {
                        PixelPlayerTransportButton(
                            enabled = true,
                            containerColor = accent,
                            contentColor = if (accent.luminance() > 0.58f) Color.Black else Color.White,
                            onClick = { sharedViewModel.onUIEvent(UIEvent.PlayPause) },
                        ) {
                            Icon(
                                imageVector = if (controllerState.isPlaying) SimpIcons.PauseCircle else SimpIcons.PlayCircle,
                                contentDescription = if (controllerState.isPlaying) "Pause" else "Play",
                                tint = if (accent.luminance() > 0.58f) Color.Black else Color.White,
                                modifier = Modifier.size(24.dp),
                            )
                        }
                    }
                }
                Spacer(Modifier.width(6.dp))
                PixelPlayerTransportButton(
                    enabled = controllerState.isNextAvailable,
                    containerColor = foreground.copy(alpha = 0.14f),
                    contentColor = foreground,
                    onClick = { sharedViewModel.onUIEvent(UIEvent.Next) },
                ) {
                    Icon(SimpIcons.SkipNext, contentDescription = "Next", tint = foreground, modifier = Modifier.size(22.dp))
                }
            }
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(2.dp),
                color = accent,
                trackColor = Color.Transparent,
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun PixelMusicFullPlayer(
    sharedViewModel: SharedViewModel,
    onDismiss: () -> Unit,
    navController: NavController? = null,
) {
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val controllerState by sharedViewModel.controllerState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    val songEntity = nowPlayingState?.songEntity
    val screenDataState by sharedViewModel.nowPlayingScreenData.collectAsStateWithLifecycle()
    val artistChannelId = songEntity?.artistId?.firstOrNull()?.takeIf { it.isNotEmpty() }
        ?: screenDataState.songInfoData?.authorId
    var showFullscreenLyrics by rememberSaveable { mutableStateOf(false) }
    var showQueueBottomSheet by rememberSaveable { mutableStateOf(false) }
    var showInfoBottomSheet by rememberSaveable { mutableStateOf(false) }
    var showAddToPlaylist by rememberSaveable { mutableStateOf(false) }
    var sliderValue by remember { mutableFloatStateOf(0f) }
    var isSliding by remember { mutableStateOf(false) }
    val progress =
        if (timelineState.total > 0L) {
            (timelineState.current.toFloat() / timelineState.total.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }

    LaunchedEffect(timelineState.current, timelineState.total, isSliding) {
        if (!isSliding) {
            sliderValue = progress
        }
    }

    if (showFullscreenLyrics && navController != null) {
        FullscreenLyricsSheet(
            sharedViewModel = sharedViewModel,
            navController = navController,
            color = MaterialTheme.colorScheme.primary,
        ) {
            showFullscreenLyrics = false
        }
    }
    if (showQueueBottomSheet) {
        QueueBottomSheet(onDismiss = { showQueueBottomSheet = false })
    }
    if (showInfoBottomSheet) {
        InfoPlayerBottomSheet(onDismiss = { showInfoBottomSheet = false })
    }
    if (showAddToPlaylist) {
        val bottomSheetViewModel: NowPlayingBottomSheetViewModel = koinViewModel()
        val uiState by bottomSheetViewModel.uiState.collectAsStateWithLifecycle()
        LaunchedEffect(Unit) {
            bottomSheetViewModel.resetPlaylists()
            bottomSheetViewModel.setSongEntity(null)
        }
        AddToPlaylistModalBottomSheet(
            isBottomSheetVisible = true,
            listLocalPlaylist = uiState.listLocalPlaylist,
            listYouTubePlaylist = uiState.listYouTubePlaylist,
            onDismiss = { showAddToPlaylist = false },
            onClick = { playlist ->
                bottomSheetViewModel.onUIEvent(NowPlayingBottomSheetUIEvent.AddToPlaylist(playlist.id))
                showAddToPlaylist = false
            },
            onYTPlaylistClick = { playlist ->
                bottomSheetViewModel.onUIEvent(NowPlayingBottomSheetUIEvent.AddToYouTubePlaylist(playlist.browseId))
                showAddToPlaylist = false
            },
            videoId = uiState.songUIState.videoId,
        )
    }

    PixelPlayerPalette { background, foreground, accent ->
        Column(
            modifier = Modifier.fillMaxSize().background(background).padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                PixelPlayerTransportButton(
                    enabled = true,
                    containerColor = foreground.copy(alpha = 0.12f),
                    contentColor = foreground,
                    onClick = onDismiss,
                    modifier = Modifier.size(42.dp),
                ) {
                    Icon(SimpIcons.Close, contentDescription = "Close", tint = foreground, modifier = Modifier.size(22.dp))
                }
                Text(
                    text = "Now playing",
                    style = typo().titleMedium.copy(fontFamily = libraryFontFamily(), fontWeight = FontWeight.Bold),
                    color = foreground,
                    modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
                )
                Spacer(Modifier.size(42.dp))
            }
            Spacer(Modifier.height(24.dp))
            AnimatedContent(
                targetState = songEntity?.videoId,
                transitionSpec = {
                    (fadeIn(tween(PixelPlayerMotionMs)) togetherWith fadeOut(tween(PixelPlayerMotionMs)))
                },
                label = "pixelFullArtwork",
            ) {
                AsyncImage(
                    model =
                        ImageRequest
                            .Builder(LocalPlatformContext.current)
                            .data(songEntity?.thumbnails)
                            .crossfade(650)
                            .build(),
                    placeholder = rememberHolderPainter(),
                    error = rememberHolderPainter(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp)),
                )
            }
            Spacer(Modifier.height(22.dp))
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = songEntity?.title.orEmpty(),
                    style = typo().headlineLarge.copy(fontFamily = libraryFontFamily(), fontWeight = FontWeight.Bold),
                    color = foreground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = songEntity?.artistName?.connectArtists().orEmpty(),
                    style = typo().bodyLarge.copy(fontFamily = libraryFontFamily()),
                    color = foreground.copy(alpha = 0.72f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PixelPlayerTransportButton(
                    enabled = true,
                    containerColor = foreground.copy(alpha = 0.12f),
                    contentColor = foreground,
                    onClick = { showInfoBottomSheet = true },
                    modifier = Modifier.size(40.dp),
                ) {
                    Icon(SimpIcons.Info, contentDescription = "Track information", tint = foreground, modifier = Modifier.size(20.dp))
                }
                PixelPlayerTransportButton(
                    enabled = navController != null && screenDataState.lyricsData != null,
                    containerColor = foreground.copy(alpha = 0.12f),
                    contentColor = foreground,
                    onClick = { showFullscreenLyrics = true },
                    modifier = Modifier.size(40.dp),
                ) {
                    Icon(SimpIcons.Subtitles, contentDescription = "Lyrics", tint = foreground, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.weight(1f))
                PixelPlayerTransportButton(
                    enabled = true,
                    containerColor = foreground.copy(alpha = 0.12f),
                    contentColor = foreground,
                    onClick = { showAddToPlaylist = true },
                    modifier = Modifier.size(40.dp),
                ) {
                    Icon(SimpIcons.PlaylistAdd, contentDescription = "Add to playlist", tint = foreground, modifier = Modifier.size(20.dp))
                }
                PixelPlayerTransportButton(
                    enabled = true,
                    containerColor = foreground.copy(alpha = 0.12f),
                    contentColor = foreground,
                    onClick = { showQueueBottomSheet = true },
                    modifier = Modifier.size(40.dp),
                ) {
                    Icon(SimpIcons.QueueMusic, contentDescription = "Queue", tint = foreground, modifier = Modifier.size(20.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            AnimatedVisibility(visible = screenDataState.songInfoData != null || artistChannelId != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(foreground.copy(alpha = 0.08f))
                        .clickable(enabled = navController != null && artistChannelId != null) {
                            val channelId = artistChannelId
                            if (channelId != null && navController != null) {
                                onDismiss()
                                navController.navigate(ArtistDestination(channelId = channelId))
                            }
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    val artistThumb = screenDataState.songInfoData?.authorThumbnail
                    AsyncImage(
                        model = ImageRequest.Builder(LocalPlatformContext.current).data(artistThumb).crossfade(450).build(),
                        placeholder = rememberHolderPainter(isVideo = true),
                        error = rememberHolderPainter(isVideo = true),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(54.dp).clip(CircleShape),
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(Res.string.artists),
                            style = typo().labelMedium.copy(fontFamily = libraryFontFamily()),
                            color = accent,
                        )
                        Text(
                            text = screenDataState.songInfoData?.author ?: screenDataState.artistName,
                            style = typo().titleMedium.copy(fontFamily = libraryFontFamily(), fontWeight = FontWeight.Bold),
                            color = foreground,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        screenDataState.songInfoData?.subscribers?.takeIf { it.isNotBlank() }?.let { subscribers ->
                            Text(
                                text = subscribers,
                                style = typo().bodySmall.copy(fontFamily = libraryFontFamily()),
                                color = foreground.copy(alpha = 0.68f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            PixelMusicWaveSlider(
                value = sliderValue,
                onValueChange = {
                    isSliding = true
                    sliderValue = it
                },
                onValueChangeFinished = {
                    sharedViewModel.onUIEvent(UIEvent.UpdateProgress(sliderValue))
                    isSliding = false
                },
                activeTrackColor = accent,
                inactiveTrackColor = foreground.copy(alpha = 0.22f),
                isPlaying = controllerState.isPlaying,
                modifier = Modifier.fillMaxWidth(),
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatDuration(timelineState.current), style = typo().bodySmall.copy(fontFamily = libraryFontFamily()), color = foreground.copy(alpha = 0.7f))
                Text(formatDuration(timelineState.total), style = typo().bodySmall.copy(fontFamily = libraryFontFamily()), color = foreground.copy(alpha = 0.7f))
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                PixelPlayerTransportButton(
                    enabled = controllerState.isPreviousAvailable,
                    containerColor = foreground.copy(alpha = 0.14f),
                    contentColor = foreground,
                    onClick = { sharedViewModel.onUIEvent(UIEvent.Previous) },
                ) {
                    Icon(SimpIcons.SkipPrevious, contentDescription = "Previous", tint = foreground, modifier = Modifier.size(25.dp))
                }
                PixelPlayerTransportButton(
                    enabled = true,
                    containerColor = accent,
                    contentColor = if (accent.luminance() > 0.58f) Color.Black else Color.White,
                    onClick = { sharedViewModel.onUIEvent(UIEvent.PlayPause) },
                    modifier = Modifier.size(84.dp),
                ) {
                    Icon(
                        imageVector = if (controllerState.isPlaying) SimpIcons.PauseCircle else SimpIcons.PlayCircle,
                        contentDescription = if (controllerState.isPlaying) "Pause" else "Play",
                        tint = if (accent.luminance() > 0.58f) Color.Black else Color.White,
                        modifier = Modifier.size(38.dp),
                    )
                }
                PixelPlayerTransportButton(
                    enabled = controllerState.isNextAvailable,
                    containerColor = foreground.copy(alpha = 0.14f),
                    contentColor = foreground,
                    onClick = { sharedViewModel.onUIEvent(UIEvent.Next) },
                ) {
                    Icon(SimpIcons.SkipNext, contentDescription = "Next", tint = foreground, modifier = Modifier.size(25.dp))
                }
            }
            Spacer(Modifier.height(18.dp))
            Text(
                text = "Swipe artwork or use the controls to move through your queue.",
                modifier = Modifier.fillMaxWidth(),
                style = typo().bodySmall.copy(fontFamily = libraryFontFamily()),
                color = foreground.copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
            )
        }
    }
}
