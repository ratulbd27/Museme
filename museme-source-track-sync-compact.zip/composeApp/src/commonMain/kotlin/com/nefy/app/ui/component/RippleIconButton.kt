package com.nefy.app.ui.component

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.nefy.app.ui.icon.Pause
import com.nefy.app.ui.icon.PlayArrow
import com.nefy.app.ui.icon.SimpIcons

@Composable
fun RippleIconButton(
    imageVector: ImageVector,
    modifier: Modifier = Modifier,
    fillMaxSize: Boolean = false,
    tint: Color = Color.White,
    enabled: Boolean = true,
    pressFeedback: Boolean = true,
    onClick: () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    IconButton(
        onClick = onClick,
        enabled = enabled,
        interactionSource = interactionSource,
        modifier = modifier.then(
            if (pressFeedback) Modifier.nefyPressScale(interactionSource = interactionSource) else Modifier,
        ),
    ) {
        Icon(
            imageVector,
            null,
            tint = tint,
            modifier = if (fillMaxSize) Modifier.fillMaxSize().padding(4.dp) else Modifier,
        )
    }
}

@Composable
fun PlayPauseButton(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    pressFeedback: Boolean = true,
    onClick: () -> Unit,
) {
    RippleIconButton(
        if (!isPlaying) {
            SimpIcons.PlayArrow
        } else {
            SimpIcons.Pause
        },
        modifier = modifier,
        tint = tint,
        pressFeedback = pressFeedback,
        onClick = onClick,
    )
}
