package com.nefy.app.ui.component

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nefy.app.ui.theme.nefySocialPalette
import com.nefy.app.ui.theme.typo
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.painterResource

object NefyExpressiveSpacing {
    val page = 16.dp
    val section = 24.dp
    val card = 16.dp
    val compact = 8.dp
    val control = 12.dp
}

object NefyExpressiveCorners {
    val card = 28.dp
    val cardSmall = 20.dp
    val control = 16.dp
    val pill = 50.dp
}

object NefyExpressiveMotion {
    const val short = 150
    const val standard = 240
    const val expressive = 320
    const val playerSheetDuration = 255
    val emphasized = CubicBezierEasing(0.2f, 0f, 0f, 1f)
    val playerSheetEasing = FastOutSlowInEasing
    val playerSheetSpring = spring<Float>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow,
    )
    val softSpring = spring<Float>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessMedium,
    )
}

@Composable
fun NefyExpressiveSurface(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.surfaceContainerLow,
    shape: RoundedCornerShape = RoundedCornerShape(NefyExpressiveCorners.card),
    tonalElevation: Dp = 0.dp,
    content: @Composable () -> Unit,
) {
    Surface(
        modifier = modifier,
        color = color,
        contentColor = MaterialTheme.colorScheme.onSurface,
        shape = shape,
        tonalElevation = tonalElevation,
        content = content,
    )
}

@Composable
fun NefySectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    action: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = typo().titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = typo().bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        action?.invoke()
    }
}

@Composable
fun NefyPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: (@Composable () -> Unit)? = null,
    selected: Boolean = false,
    enabled: Boolean = true,
    containerColor: Color = MaterialTheme.colorScheme.secondaryContainer,
    selectedContainerColor: Color = MaterialTheme.colorScheme.primary,
    contentColor: Color = MaterialTheme.colorScheme.onSecondaryContainer,
    selectedContentColor: Color = MaterialTheme.colorScheme.onPrimary,
) {
    val targetContainer = if (selected) selectedContainerColor else containerColor
    val targetContent = if (selected) selectedContentColor else contentColor
    val interactionSource = rememberNefyInteractionSource()
    val animatedContainer by animateColorAsState(
        targetValue = targetContainer,
        animationSpec = tween(NefyExpressiveMotion.standard, easing = NefyExpressiveMotion.emphasized),
        label = "nefyPillContainer",
    )
    val animatedContent by animateColorAsState(
        targetValue = targetContent,
        animationSpec = tween(NefyExpressiveMotion.short),
        label = "nefyPillContent",
    )
    val elevation by animateDpAsState(
        targetValue = if (selected) 4.dp else 0.dp,
        animationSpec = tween(NefyExpressiveMotion.standard),
        label = "nefyPillElevation",
    )

    Surface(
        modifier = modifier
            .defaultMinSize(minHeight = 44.dp)
            .nefyPressScale(interactionSource = interactionSource)
            .clip(RoundedCornerShape(NefyExpressiveCorners.pill))
            .clickable(
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick,
            )
            .semantics { role = Role.Button },
        color = animatedContainer,
        contentColor = animatedContent,
        shape = RoundedCornerShape(NefyExpressiveCorners.pill),
        tonalElevation = elevation,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            icon?.invoke()
            Text(
                text = text,
                style = typo().labelMedium,
                color = animatedContent,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
fun NefyPillIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable () -> Unit,
    contentDescription: String? = null,
    containerColor: Color = MaterialTheme.colorScheme.secondaryContainer,
    contentColor: Color = MaterialTheme.colorScheme.onSecondaryContainer,
    selected: Boolean = false,
) {
    val interactionSource = rememberNefyInteractionSource()
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.08f else 1f,
        animationSpec = NefyExpressiveMotion.softSpring,
        label = "nefyPillIconScale",
    )
    val animatedContainer by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primaryContainer else containerColor,
        animationSpec = tween(NefyExpressiveMotion.standard),
        label = "nefyPillIconContainer",
    )
    val animatedContent by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else contentColor,
        animationSpec = tween(NefyExpressiveMotion.short),
        label = "nefyPillIconContent",
    )
    Surface(
        modifier = modifier
            .size(48.dp)
            .nefyPressScale(interactionSource = interactionSource)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(CircleShape)
            .clickable(
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                onClick = onClick,
            )
            .semantics {
                if (contentDescription != null) this.contentDescription = contentDescription
                role = Role.Button
            },
        color = animatedContainer,
        contentColor = animatedContent,
        shape = CircleShape,
    ) {
        Box(contentAlignment = Alignment.Center) { icon() }
    }
}

@Composable
fun NefySegmentedControl(
    labels: List<String>,
    selectedIndex: Int,
    onSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    if (labels.isEmpty()) return
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(NefyExpressiveCorners.control))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .padding(4.dp)
            .animateContentSize(animationSpec = tween(NefyExpressiveMotion.standard)),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        labels.forEachIndexed { index, label ->
            val selected = index == selectedIndex
            val interactionSource = rememberNefyInteractionSource()
            val container by animateColorAsState(
                targetValue = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                animationSpec = tween(NefyExpressiveMotion.standard),
                label = "nefySegmentContainer$index",
            )
            val content by animateColorAsState(
                targetValue = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                animationSpec = tween(NefyExpressiveMotion.short),
                label = "nefySegmentContent$index",
            )
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .defaultMinSize(minHeight = 40.dp)
                    .nefyPressScale(interactionSource = interactionSource)
                    .clip(RoundedCornerShape(NefyExpressiveCorners.control))
                    .clickable(
                        interactionSource = interactionSource,
                        indication = LocalIndication.current,
                        role = Role.Tab,
                    ) { onSelected(index) },
                color = container,
                contentColor = content,
                shape = RoundedCornerShape(NefyExpressiveCorners.control),
            ) {
                Box(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = label,
                        style = typo().labelMedium,
                        color = content,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

@Composable
fun RowScope.NefyAnimatedNavigationItem(
    selected: Boolean,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
    selectedIcon: @Composable () -> Unit = icon,
    label: String? = null,
    contentDescription: String? = null,
    modifier: Modifier = Modifier,
) {
    val socialPalette = nefySocialPalette()
    val iconColor by animateColorAsState(
        targetValue = if (selected) socialPalette.accent else socialPalette.secondaryText,
        animationSpec = tween(NefyExpressiveMotion.short),
        label = "nefyNavigationIconColor",
    )
    val textColor by animateColorAsState(
        targetValue = if (selected) socialPalette.accent else socialPalette.secondaryText,
        animationSpec = tween(NefyExpressiveMotion.short),
        label = "nefyNavigationTextColor",
    )
    val iconScale by animateFloatAsState(
        targetValue = if (selected) 1.08f else 1f,
        animationSpec = NefyExpressiveMotion.softSpring,
        label = "nefyNavigationIconScale",
    )
    val showLabel = label != null
    val indicatorColor by animateColorAsState(
        targetValue = if (selected) socialPalette.accentContainer else Color.Transparent,
        animationSpec = tween(NefyExpressiveMotion.standard, easing = NefyExpressiveMotion.emphasized),
        label = "nefyNavigationIndicatorColor",
    )
    val indicatorScale by animateFloatAsState(
        targetValue = if (selected) 1f else 0.92f,
        animationSpec = NefyExpressiveMotion.playerSheetSpring,
        label = "nefyNavigationIndicatorScale",
    )
    val interactionSource = rememberNefyInteractionSource()

    Column(
        modifier = modifier
            .weight(1f)
            .nefyPressScale(interactionSource = interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                role = Role.Tab,
                onClick = onClick,
            )
            .semantics {
                if (contentDescription != null) this.contentDescription = contentDescription
                role = Role.Tab
            }
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .size(width = 64.dp, height = 34.dp)
                .graphicsLayer {
                    scaleX = indicatorScale
                    scaleY = indicatorScale
                }
                .clip(RoundedCornerShape(NefyExpressiveCorners.control))
                .background(indicatorColor),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = Modifier.graphicsLayer {
                    scaleX = iconScale
                    scaleY = iconScale
                },
                contentAlignment = Alignment.Center,
            ) {
                androidx.compose.runtime.CompositionLocalProvider(
                    androidx.compose.material3.LocalContentColor provides iconColor,
                ) {
                    if (selected) selectedIcon() else icon()
                }
            }
        }
        AnimatedVisibility(
            visible = showLabel,
            enter = fadeIn(tween(NefyExpressiveMotion.short)) + scaleIn(initialScale = 0.92f, animationSpec = NefyExpressiveMotion.playerSheetSpring),
            exit = fadeOut(tween(NefyExpressiveMotion.short)) + scaleOut(targetScale = 0.92f, animationSpec = tween(NefyExpressiveMotion.short)),
        ) {
            Text(
                modifier = Modifier.padding(top = 3.dp),
                text = label.orEmpty(),
                style = typo().labelSmall,
                color = textColor,
                fontSize = 13.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
            )
        }
    }
}

@Composable
fun NefyArrowAction(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: DrawableResource,
    contentDescription: String? = null,
) {
    NefyPillIconButton(
        modifier = modifier,
        onClick = onClick,
        contentDescription = contentDescription,
        icon = {
            Icon(
                painter = painterResource(icon),
                contentDescription = null,
            )
        },
    )
}
