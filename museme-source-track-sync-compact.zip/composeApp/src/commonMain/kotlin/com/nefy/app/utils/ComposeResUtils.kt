package com.nefy.app.utils

import org.jetbrains.compose.resources.getString
import nefy.composeapp.generated.resources.Res
import nefy.composeapp.generated.resources.explicit_content_blocked
import nefy.composeapp.generated.resources.new_albums
import nefy.composeapp.generated.resources.new_singles
import nefy.composeapp.generated.resources.this_app_needs_to_access_your_notification
import nefy.composeapp.generated.resources.time_out_check_internet_connection_or_change_piped_instance_in_settings

object ComposeResUtils {
    /**
     * Converts low-level stream failures into a short, actionable message. The raw exception is
     * still available to logging/crash reporting, but it must never be rendered in a toast.
     */
    fun userFacingPlayerError(rawError: String): String {
        val normalized = rawError.lowercase()
        return when {
            "429" in normalized || "captcha" in normalized || "google.com/sorry" in normalized ->
                "YouTube is temporarily limiting playback. Please wait a moment and try again."
            "404" in normalized || "not found" in normalized || "unavailable" in normalized ->
                "This song is unavailable. Please choose another song."
            "403" in normalized || "forbidden" in normalized || "blocked" in normalized ->
                "YouTube blocked this stream. Please choose another song."
            else -> "Playback could not start. Please try again or choose another song."
        }
    }

    suspend fun getResString(
        type: StringType,
        vararg format: String,
    ): String =
        when (type) {
            StringType.EXPLICIT_CONTENT_BLOCKED -> {
                getString(Res.string.explicit_content_blocked)
            }

            StringType.NOTIFICATION_REQUEST -> {
                getString(Res.string.this_app_needs_to_access_your_notification)
            }

            StringType.TIME_OUT_ERROR -> {
                getString(Res.string.time_out_check_internet_connection_or_change_piped_instance_in_settings, *format)
            }

            StringType.NEW_SINGLES -> {
                getString(Res.string.new_singles)
            }

            StringType.NEW_ALBUMS -> {
                getString(Res.string.new_albums)
            }
        }

    enum class StringType {
        EXPLICIT_CONTENT_BLOCKED,
        NOTIFICATION_REQUEST,
        TIME_OUT_ERROR,
        NEW_SINGLES,
        NEW_ALBUMS,
    }
}