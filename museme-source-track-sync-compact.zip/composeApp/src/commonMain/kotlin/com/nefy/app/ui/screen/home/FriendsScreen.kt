package com.nefy.app.ui.screen.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import androidx.navigation.NavController
import com.nefy.app.expect.shareUrl
import com.nefy.app.social.listening.ListeningRoomConnection
import com.nefy.app.social.listening.ListeningRoomController
import com.nefy.app.social.listening.ListeningRoomState
import com.nefy.app.social.listening.ListeningTrack
import com.nefy.app.social.listening.NefyActivityItem
import com.nefy.app.social.listening.NefyPresence
import com.nefy.app.social.listening.NefyFriendRequest
import com.nefy.app.social.listening.NefyIdentity
import com.nefy.app.social.listening.NefySavedPlaylist
import com.nefy.app.social.listening.NefySocialState
import com.nefy.app.ui.component.RippleIconButton
import com.nefy.app.ui.icon.ArrowBackIosNew
import com.nefy.app.ui.icon.Pause
import com.nefy.app.ui.icon.PeopleAlt
import com.nefy.app.ui.icon.PlayArrow
import com.nefy.app.ui.icon.Share
import com.nefy.app.ui.icon.SkipNext
import com.nefy.app.ui.icon.SkipPrevious
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.navigation.destination.home.FriendsDestination
import com.nefy.app.ui.theme.nefySocialPalette
import com.nefy.app.ui.theme.typo
import com.maxrave.domain.data.entities.SongEntity
import com.maxrave.domain.repository.LocalPlaylistRepository
import com.maxrave.domain.mediaservice.handler.NowPlayingTrackState
import com.nefy.app.viewModel.NowPlayingBottomSheetViewModel
import com.nefy.app.viewModel.SearchScreenUIState
import com.nefy.app.viewModel.SearchViewModel
import com.nefy.app.viewModel.SharedViewModel
import com.nefy.app.viewModel.UIEvent
import nefy.composeapp.generated.resources.Res
import nefy.composeapp.generated.resources.create_listening_room
import nefy.composeapp.generated.resources.currently_listening
import nefy.composeapp.generated.resources.follow_host
import nefy.composeapp.generated.resources.friend_listening
import nefy.composeapp.generated.resources.invite_friends
import nefy.composeapp.generated.resources.join_room
import nefy.composeapp.generated.resources.join_room_description
import nefy.composeapp.generated.resources.leave_room
import nefy.composeapp.generated.resources.listening_room
import nefy.composeapp.generated.resources.listening_room_code
import nefy.composeapp.generated.resources.members
import nefy.composeapp.generated.resources.no_room_yet
import nefy.composeapp.generated.resources.room_code_hint
import nefy.composeapp.generated.resources.share_room
import nefy.composeapp.generated.resources.start_listening_together
import nefy.composeapp.generated.resources.you_are_host
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FriendsScreen(
    navController: NavController,
    initialRoomCode: String? = null,
    roomController: ListeningRoomController = koinInject(),
    sharedViewModel: SharedViewModel = koinInject(),
) {
    NefyFriendsFoundation(
        navController = navController,
        initialRoomCode = initialRoomCode,
        roomController = roomController,
        sharedViewModel = sharedViewModel,
    )
    return

    val roomState by roomController.state.collectAsStateWithLifecycle()
    val socialState by roomController.socialState.collectAsStateWithLifecycle()
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    val identity: NefyIdentity = koinInject()
    var roomCode by rememberSaveable { mutableStateOf(initialRoomCode.orEmpty()) }
    var displayName by rememberSaveable { mutableStateOf(identity.displayName) }
    var selectedSection by rememberSaveable { mutableStateOf("room") }

    LaunchedEffect(Unit) {
        roomController.loadSocial()
    }

    LaunchedEffect(
        roomState.revision,
        roomState.currentTrack?.videoId,
        roomState.isPlaying,
        roomState.positionMs,
        roomState.positionUpdatedAtMs,
        nowPlayingState?.songEntity?.videoId,
    ) {
        val sharedTrack = roomState.currentTrack
        if (sharedTrack != null && sharedTrack.videoId.isNotBlank() && sharedTrack.videoId != "museme-demo") {
            if (nowPlayingState?.songEntity?.videoId != sharedTrack.videoId) {
                sharedViewModel.loadSharedMediaItem(sharedTrack.videoId)
                delay(900)
            }
            val syncedPosition =
                if (roomState.isPlaying && roomState.positionUpdatedAtMs > 0L) {
                    roomState.positionMs + (System.currentTimeMillis() - roomState.positionUpdatedAtMs).coerceAtLeast(0L)
                } else {
                    roomState.positionMs
                }
            sharedViewModel.applyListeningPlayback(roomState.isPlaying, syncedPosition)
        }
    }

    val canControlRoom = roomState.hostId == roomState.currentUserId || roomState.remoteControlEnabled
    val latestRoomState by rememberUpdatedState(roomState)
    val latestCanControlRoom by rememberUpdatedState(canControlRoom)
    var lastAdvanceRequestTrackId by remember(roomState.roomCode) { mutableStateOf<String?>(null) }
    LaunchedEffect(roomState.currentTrack?.videoId) {
        if (roomState.currentTrack?.videoId != lastAdvanceRequestTrackId) {
            lastAdvanceRequestTrackId = null
        }
    }
    LaunchedEffect(roomState.roomCode) {
        sharedViewModel.playbackEnded.collect { endedTrackId ->
            val activeState = latestRoomState
            if (
                activeState.roomCode != null &&
                latestCanControlRoom &&
                activeState.isPlaying &&
                activeState.currentTrack?.videoId == endedTrackId &&
                lastAdvanceRequestTrackId != endedTrackId
            ) {
                lastAdvanceRequestTrackId = endedTrackId
                roomController.advanceQueue(endedTrackId)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(Res.string.friend_listening),
                        style = typo().titleMedium,
                    )
                },
                navigationIcon = {
                    RippleIconButton(
                        imageVector = SimpIcons.ArrowBackIosNew,
                        tint = MaterialTheme.colorScheme.onSurface,
                        onClick = { navController.navigateUp() },
                    )
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(innerPadding)
                    .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf("room" to "Room", "playlists" to "Playlists", "activity" to "Activity").forEach { (key, label) ->
                    if (selectedSection == key) {
                        Button(onClick = { selectedSection = key }, modifier = Modifier.weight(1f)) { Text(label) }
                    } else {
                        TextButton(onClick = { selectedSection = key }, modifier = Modifier.weight(1f)) { Text(label) }
                    }
                }
            }

            when (selectedSection) {
                "playlists" -> PlaylistsContent(
                    state = socialState,
                    currentTrack = toListeningTrack(nowPlayingState, sharedViewModel) ?: roomState.currentTrack,
                    onCreatePlaylist = { name, description -> roomController.createPlaylist(name, description) },
                    onAddTrack = roomController::addPlaylistTrack,
                    onPlayTrack = { track ->
                        sharedViewModel.loadSharedMediaItem(track.videoId)
                        if (roomState.roomCode != null) roomController.setTrack(track)
                    },
                    onRemoveTrack = roomController::removePlaylistTrack,
                    onCreateInvite = { playlistId -> roomController.createPlaylistInvite(playlistId) },
                    onJoinInvite = roomController::joinPlaylistInvite,
                )
                "activity" -> ActivityContent(
                    state = socialState,
                    onVisibilityChange = roomController::setActivityVisibility,
                )
                else -> if (roomState.roomCode == null) {
                EmptyRoomContent(
                    displayName = displayName,
                    roomCode = roomCode,
                    onDisplayNameChange = {
                        displayName = it.take(24)
                        identity.setDisplayName(displayName)
                    },
                    onRoomCodeChange = { roomCode = it.uppercase().take(8) },
                    connection = roomState.connection,
                    errorMessage = roomState.errorMessage,
                    onCreateRoom = { roomController.createRoom(displayName) },
                    onJoinRoom = { roomController.joinRoom(roomCode, displayName) },
                )
            } else {
                ActiveRoomContent(
                    state = roomState,
                    onPlayingChange = { isPlaying ->
                        val position = timelineState.current.coerceAtLeast(0L)
                        roomController.setPlayback(isPlaying = isPlaying, positionMs = position)
                        sharedViewModel.applyListeningPlayback(isPlaying, position)
                    },
                    onSeek = { positionMs ->
                        roomController.setPlayback(
                            isPlaying = roomState.isPlaying,
                            positionMs = positionMs,
                        )
                        sharedViewModel.applyListeningPlayback(roomState.isPlaying, positionMs)
                    },
                    onShareTrack = {
                        toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::setTrack)
                    },
                    onEnqueueTrack = {
                        toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::enqueueTrack)
                    },
                    onPlayTrack = roomController::setTrack,
                    onSkipNext = roomController::skipNext,
                    onSkipPrevious = roomController::skipPrevious,
                    onFollowHostChange = roomController::setFollowHost,
                    onRemoteControlChange = roomController::setRemoteControl,
                    onAddSong = {},
                    onInviteFriends = {},
                    onLeaveRoom = roomController::leaveRoom,
                )
            }
        }
    }
}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NefyFriendsFoundation(
    navController: NavController,
    initialRoomCode: String?,
    roomController: ListeningRoomController,
    sharedViewModel: SharedViewModel,
) {
    val socialState by roomController.socialState.collectAsStateWithLifecycle()
    val socialPalette = nefySocialPalette()
    val roomState by roomController.state.collectAsStateWithLifecycle()
    val invitations by roomController.invitations.collectAsStateWithLifecycle()
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    val identity: NefyIdentity = koinInject()
    var socialPage by rememberSaveable { mutableStateOf(if (initialRoomCode.isNullOrBlank()) "feed" else "listen") }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var roomCode by rememberSaveable { mutableStateOf(initialRoomCode.orEmpty()) }
    var displayName by rememberSaveable { mutableStateOf(identity.displayName) }
    var selectedPresence by remember { mutableStateOf<NefyPresence?>(null) }
    var selectedFriend by remember { mutableStateOf<com.nefy.app.social.listening.NefyFriend?>(null) }
    var selectedPlaylistTrack by remember { mutableStateOf<ListeningTrack?>(null) }
    var showRoomSongPicker by rememberSaveable { mutableStateOf(false) }
    var showRoomInviteSheet by rememberSaveable { mutableStateOf(false) }
    var showRoomChat by rememberSaveable { mutableStateOf(false) }
    val latestRoomState by rememberUpdatedState(roomState)
    val latestCanControlRoom by rememberUpdatedState(roomState.hostId == roomState.currentUserId || roomState.remoteControlEnabled)
    var lastAdvanceRequestTrackId by remember(roomState.roomCode) { mutableStateOf<String?>(null) }
    val incomingRequests = socialState.pendingRequests.filter { it.direction == "incoming" }

    LaunchedEffect(Unit) { roomController.loadSocial() }
    LaunchedEffect(roomState.currentTrack?.videoId) {
        if (roomState.currentTrack?.videoId != lastAdvanceRequestTrackId) lastAdvanceRequestTrackId = null
    }
    LaunchedEffect(roomState.roomCode) {
        sharedViewModel.playbackEnded.collect { endedTrackId ->
            val active = latestRoomState
            if (active.roomCode != null && latestCanControlRoom && active.isPlaying && active.currentTrack?.videoId == endedTrackId && lastAdvanceRequestTrackId != endedTrackId) {
                lastAdvanceRequestTrackId = endedTrackId
                roomController.advanceQueue(endedTrackId)
            }
        }
    }
    LaunchedEffect(roomState.revision, roomState.currentTrack?.videoId, roomState.isPlaying, roomState.positionMs, roomState.positionUpdatedAtMs) {
        val sharedTrack = roomState.currentTrack
        if (sharedTrack != null && sharedTrack.videoId.isNotBlank()) {
            if (nowPlayingState?.songEntity?.videoId != sharedTrack.videoId) {
                sharedViewModel.loadSharedMediaItem(sharedTrack.videoId)
                delay(800L)
            }
            val syncedPosition = if (roomState.isPlaying && roomState.positionUpdatedAtMs > 0L) {
                roomState.positionMs + (System.currentTimeMillis() - roomState.positionUpdatedAtMs).coerceAtLeast(0L)
            } else roomState.positionMs
            sharedViewModel.applyListeningPlayback(roomState.isPlaying, syncedPosition)
        }
    }

    Scaffold(
        containerColor = socialPalette.pageBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = socialPalette.pageBackground),
                title = { Text(if (socialPage == "feed") "Friends" else socialPage.replaceFirstChar { it.uppercase() }, style = typo().titleMedium, color = socialPalette.primaryText) },
                navigationIcon = {
                    RippleIconButton(
                        imageVector = SimpIcons.ArrowBackIosNew,
                        tint = socialPalette.primaryText,
                        onClick = {
                            if (socialPage == "feed") navController.navigateUp() else socialPage = "feed"
                        },
                    )
                },
                actions = {
                    if (socialPage == "feed") {
                        TextButton(onClick = { socialPage = "listen" }) { Text("Listen") }
                        TextButton(onClick = { socialPage = "requests" }) {
                            Text(if (incomingRequests.isEmpty()) "Requests" else "Requests ${incomingRequests.size}")
                        }
                        TextButton(onClick = { socialPage = "find" }) { Text("Add") }
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(padding).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            invitations.firstOrNull()?.let { invitation ->
                RoomInvitationBanner(
                    invitation = invitation,
                    pendingCount = invitations.size,
                    onAccept = {
                        roomCode = invitation.roomCode
                        roomController.acceptInvitation(invitation, displayName)
                        socialPage = "listen"
                    },
                    onDecline = { roomController.declineInvitation(invitation.id) },
                    palette = socialPalette,
                )
            }
            if (socialPage == "feed" || socialPage == "friends") {
                SocialSegmentedTabs(
                    selected = socialPage,
                    onSelect = { socialPage = it },
                    palette = socialPalette,
                )
            }
            when (socialPage) {
                "feed" -> {
                    Text("Listening activity", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold, color = socialPalette.primaryText)
                    Text("Live updates from your circle, ordered by who is playing, paused, online, and offline.", style = typo().bodySmall, color = socialPalette.secondaryText)

                    ListenTogetherEntryCard(
                        activeRoomCode = roomState.roomCode,
                        onOpen = { socialPage = "listen" },
                    )

                    if (socialState.playlists.isNotEmpty()) {
                        SharedPlaylistSummary(
                            playlistCount = socialState.playlists.size,
                            onOpen = { socialPage = "playlists" },
                        )
                    }

                    val presenceById = socialState.presence.associateBy { it.userId }
                    val orderedFriends = socialState.friends.sortedWith(
                        compareByDescending<com.nefy.app.social.listening.NefyFriend> { presenceById[it.userId]?.isPlaying == true }
                            .thenByDescending { presenceById[it.userId]?.track != null }
                            .thenByDescending { presenceById.containsKey(it.userId) }
                            .thenBy { it.displayName.lowercase() },
                    )
                    if (orderedFriends.isEmpty()) {
                        SocialEmptyCard("No friends yet", "Use Add to search by username or friend code, then watch their listening activity here.")
                    } else {
                        orderedFriends.forEach { friend ->
                            val presence = presenceById[friend.userId]
                            LiveFriendCard(
                                displayName = friend.displayName,
                                handle = friend.handle,
                                presence = presence,
                                onProfileClick = { selectedFriend = friend },
                                onTrackClick = { selectedPresence = presence },
                            )
                        }
                    }
                }
                "friends" -> {
                    Text("Your friends", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold, color = socialPalette.primaryText)
                    Text("Open a friend card to see their profile and listening status.", style = typo().bodySmall, color = socialPalette.secondaryText)
                    val presenceById = socialState.presence.associateBy { it.userId }
                    val orderedFriends = socialState.friends.sortedBy { it.displayName.lowercase() }
                    if (orderedFriends.isEmpty()) {
                        SocialEmptyCard("No friends yet", "Use Add to search by username or friend code.")
                    } else {
                        orderedFriends.forEach { friend ->
                            LiveFriendCard(
                                displayName = friend.displayName,
                                handle = friend.handle,
                                presence = presenceById[friend.userId],
                                onProfileClick = { selectedFriend = friend },
                                onTrackClick = { selectedPresence = presenceById[friend.userId] },
                            )
                        }
                    }
                }
                "requests" -> {
                    Text("Friend requests", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold, color = socialPalette.primaryText)
                    val outgoing = socialState.pendingRequests.filter { it.direction == "outgoing" }
                    if (incomingRequests.isEmpty() && outgoing.isEmpty()) SocialEmptyCard("No pending requests", "Requests will appear here when someone connects with you.")
                    incomingRequests.forEach { request ->
                        FriendRequestCard(
                            request = request,
                            onAccept = { roomController.respondFriendRequest(request.id, true) },
                            onDecline = { roomController.respondFriendRequest(request.id, false) },
                        )
                    }
                    if (outgoing.isNotEmpty()) {
                        Text("Sent", style = typo().titleMedium, color = socialPalette.primaryText)
                        outgoing.forEach { request -> FriendRequestCard(request = request, onAccept = null, onDecline = null) }
                    }
                }
                "find" -> {
                    Text("Find friends", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold, color = socialPalette.primaryText)
                    Text("Search a Nefy username, handle, or friend code.", style = typo().bodySmall, color = socialPalette.secondaryText)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            modifier = Modifier.weight(1f),
                            value = searchQuery,
                            onValueChange = { searchQuery = it.take(64) },
                            label = { Text("Username or code") },
                            singleLine = true,
                        )
                        Button(onClick = { roomController.searchProfiles(searchQuery) }, enabled = searchQuery.isNotBlank()) { Text("Search") }
                    }
                    if (socialState.searchResults.isEmpty()) {
                        SocialEmptyCard("Search Nefy profiles", "Results will appear here with an Add button.")
                    } else {
                        socialState.searchResults.forEach { result ->
                            SearchResultCard(result.displayName, result.handle, result.friendCode) {
                                roomController.sendFriendRequest(result.userId)
                            }
                        }
                    }
                }
                "activity" -> ActivityContent(
                    state = socialState,
                    onVisibilityChange = roomController::setActivityVisibility,
                )
                "playlists" -> PlaylistsContent(
                    state = socialState,
                    currentTrack = toListeningTrack(nowPlayingState, sharedViewModel) ?: roomState.currentTrack,
                    onCreatePlaylist = { name, description -> roomController.createPlaylist(name, description) },
                    onAddTrack = roomController::addPlaylistTrack,
                    onPlayTrack = { track -> sharedViewModel.loadSharedMediaItem(track.videoId) },
                    onRemoveTrack = roomController::removePlaylistTrack,
                    onCreateInvite = roomController::createPlaylistInvite,
                    onJoinInvite = roomController::joinPlaylistInvite,
                )
                "listen" -> {
                    if (roomState.roomCode == null) {
                        EmptyRoomContent(
                            displayName = displayName,
                            roomCode = roomCode,
                            onDisplayNameChange = {
                                displayName = it.take(24)
                                identity.setDisplayName(displayName)
                            },
                            onRoomCodeChange = { roomCode = it.uppercase().take(8) },
                            connection = roomState.connection,
                            errorMessage = roomState.errorMessage,
                            onCreateRoom = { roomController.createRoom(displayName) },
                            onJoinRoom = { roomController.joinRoom(roomCode, displayName) },
                        )
                    } else {
                        ActiveRoomContent(
                            state = roomState,
                            onPlayingChange = { isPlaying ->
                                val position = timelineState.current.coerceAtLeast(0L)
                                roomController.setPlayback(isPlaying, position)
                                sharedViewModel.applyListeningPlayback(isPlaying, position)
                            },
                            onSeek = { positionMs ->
                                roomController.setPlayback(roomState.isPlaying, positionMs)
                                sharedViewModel.applyListeningPlayback(roomState.isPlaying, positionMs)
                            },
                            onShareTrack = { toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::setTrack) },
                            onEnqueueTrack = { toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::enqueueTrack) },
                            onPlayTrack = roomController::setTrack,
                            onSkipNext = roomController::skipNext,
                            onSkipPrevious = roomController::skipPrevious,
                            onFollowHostChange = roomController::setFollowHost,
                            onRemoteControlChange = roomController::setRemoteControl,
                            onAddSong = { showRoomSongPicker = true },
                            onInviteFriends = { showRoomInviteSheet = true },
                            onOpenChat = { showRoomChat = true },
                            onRemoveQueueTrack = roomController::removeQueueTrack,
                            onLeaveRoom = roomController::leaveRoom,
                        )
                    }
                }
            }
        }
    }

    selectedFriend?.let { friend ->
        val friendPresence = socialState.presence.firstOrNull { it.userId == friend.userId }
        FriendProfileSheet(
            friend = friend,
            presence = friendPresence,
            onDismiss = { selectedFriend = null },
            onPlayTrack = {
                friendPresence?.track?.let { track -> sharedViewModel.loadSharedMediaItem(track.videoId) }
                selectedFriend = null
            },
            onAddToPlaylist = {
                friendPresence?.track?.let { selectedPlaylistTrack = it }
                selectedFriend = null
            },
            onListenTogether = { selectedFriend = null; socialPage = "listen" },
            onShareProfile = {
                shareUrl(title = "Connect with ${friend.displayName} on Nefy", url = "nefy://profile/${friend.userId}")
            },
            onRemoveFriend = { roomController.removeFriend(friend.userId); selectedFriend = null },
        )
    }

    selectedPresence?.let { presence ->
        presence.track?.let { track ->
            FriendTrackActionSheet(
                presence = presence,
                onDismiss = { selectedPresence = null },
                onPlay = { sharedViewModel.loadSharedMediaItem(track.videoId); selectedPresence = null },
                onAddToPlaylist = { selectedPlaylistTrack = track; selectedPresence = null },
                onListenTogether = { selectedPresence = null; socialPage = "listen" },
            )
        }
    }

    if (showRoomSongPicker && roomState.roomCode != null) {
        RoomSongPickerSheet(
            onDismiss = { showRoomSongPicker = false },
            onAddTrack = { track ->
                if (roomState.currentTrack == null) roomController.setTrack(track) else roomController.enqueueTrack(track)
            },
        )
    }

    if (showRoomInviteSheet && roomState.roomCode != null) {
        RoomInviteSheet(
            friends = socialState.friends,
            roomCode = roomState.roomCode.orEmpty(),
            onInviteFriend = roomController::inviteFriend,
            onDismiss = { showRoomInviteSheet = false },
        )
    }

    if (showRoomChat && roomState.roomCode != null) {
        RoomChatSheet(
            state = roomState,
            onSendChat = roomController::sendChat,
            onSendReaction = roomController::sendReaction,
            onDismiss = { showRoomChat = false },
        )
    }

    selectedPlaylistTrack?.let { track ->
        ModalBottomSheet(onDismissRequest = { selectedPlaylistTrack = null }) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Add to a shared Nefy playlist", style = typo().headlineSmall)
                if (socialState.playlists.isEmpty()) {
                    Text("Share a Library playlist first, then add this song to it.", style = typo().bodyMedium)
                } else {
                    socialState.playlists.forEach { playlist ->
                        TextButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                roomController.addPlaylistTrack(playlist.id, track)
                                selectedPlaylistTrack = null
                            },
                        ) { Text(playlist.name, modifier = Modifier.fillMaxWidth()) }
                    }
                }
                TextButton(onClick = { selectedPlaylistTrack = null }) { Text("Cancel") }
            }
        }
    }
}

@Composable
private fun RoomInvitationBanner(
    invitation: RoomInvitation,
    pendingCount: Int,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    palette: com.nefy.app.ui.theme.NefySocialPalette,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = palette.cardElevated),
        border = BorderStroke(1.dp, palette.accent.copy(alpha = 0.45f)),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Listening room invitation", style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
            Text("${invitation.inviterDisplayName} invited you to room ${invitation.roomCode}.", style = typo().bodyMedium, color = palette.secondaryText)
            if (pendingCount > 1) Text("$pendingCount invitations waiting", style = typo().labelSmall, color = palette.accent)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onDecline, modifier = Modifier.weight(1f)) { Text("Decline", color = palette.secondaryText) }
                Button(onClick = onAccept, modifier = Modifier.weight(1f)) { Text("Accept") }
            }
        }
    }
}

@Composable
private fun SocialSegmentedTabs(
    selected: String,
    onSelect: (String) -> Unit,
    palette: com.nefy.app.ui.theme.NefySocialPalette,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = palette.card,
        tonalElevation = 1.dp,
    ) {
        Row(modifier = Modifier.padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("feed" to "Activity", "friends" to "Friends").forEach { (key, label) ->
                Surface(
                    modifier = Modifier.weight(1f).clickable { onSelect(key) },
                    shape = RoundedCornerShape(20.dp),
                    color = if (selected == key) palette.accentContainer else palette.card,
                ) {
                    Text(
                        text = label,
                        modifier = Modifier.padding(vertical = 10.dp),
                        textAlign = TextAlign.Center,
                        style = typo().labelLarge,
                        color = if (selected == key) palette.accent else palette.primaryText,
                    )
                }
            }
        }
    }
}

@Composable
private fun ListenTogetherEntryCard(
    activeRoomCode: String?,
    onOpen: () -> Unit,
) {
    val palette = nefySocialPalette()
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = palette.hero),
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Surface(
                modifier = Modifier.size(48.dp),
                shape = CircleShape,
                color = palette.accent,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = SimpIcons.PeopleAlt,
                        contentDescription = null,
                        tint = palette.primaryText,
                    )
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Listen Together", style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
                Text(
                    if (activeRoomCode == null) "Create a room or join a friend with a room code."
                    else "Room $activeRoomCode is ready — return to your shared queue.",
                    style = typo().bodySmall,
                    color = palette.primaryText,
                )
            }
            Text("Open", style = typo().labelLarge, color = palette.primaryText)
        }
    }
}

@Composable
private fun SharedPlaylistSummary(
    playlistCount: Int,
    onOpen: () -> Unit,
) {
    val palette = nefySocialPalette()
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = palette.card),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Surface(
                modifier = Modifier.size(44.dp),
                shape = RoundedCornerShape(14.dp),
                color = palette.accentContainer,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = SimpIcons.Share,
                        contentDescription = null,
                        tint = palette.primaryText,
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Shared playlists", style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
                Text("$playlistCount collaborative ${if (playlistCount == 1) "playlist" else "playlists"} in your circle", style = typo().bodySmall, color = palette.secondaryText)
            }
            Text("Open", style = typo().labelLarge, color = palette.accent)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FriendProfileSheet(
    friend: com.nefy.app.social.listening.NefyFriend,
    presence: NefyPresence?,
    onDismiss: () -> Unit,
    onPlayTrack: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onListenTogether: () -> Unit,
    onShareProfile: () -> Unit,
    onRemoveFriend: () -> Unit,
) {
    val palette = nefySocialPalette()
    val status = when {
        presence?.isPlaying == true -> "Playing now"
        presence?.track != null -> "Paused"
        presence != null -> "Online"
        else -> "Offline"
    }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = palette.card) {
        Column(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            BoxAvatar(label = friend.displayName.take(1).uppercase())
            Text(friend.displayName, style = typo().headlineSmall, fontWeight = FontWeight.Bold, color = palette.primaryText)
            friend.handle?.let { Text("@$it", style = typo().bodyMedium, color = palette.secondaryText) }
            Text(status, style = typo().labelLarge, color = palette.accent)
            presence?.track?.let { track ->
                Text("${track.title} · ${track.artist}", style = typo().bodyMedium, textAlign = TextAlign.Center)
            }
            if (presence?.track != null) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = onPlayTrack, modifier = Modifier.weight(1f)) { Text("Play") }
                    FilledTonalButton(onClick = onAddToPlaylist, modifier = Modifier.weight(1f)) { Text("Add to playlist") }
                }
            }
            FilledTonalButton(onClick = onListenTogether, modifier = Modifier.fillMaxWidth()) { Text("Listen Together") }
            TextButton(onClick = onShareProfile) { Text("Share profile", color = palette.accent) }
            TextButton(onClick = onRemoveFriend) { Text("Remove friend", color = palette.danger) }
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    }
}

@Composable
private fun LiveFriendCard(
    displayName: String,
    handle: String?,
    presence: NefyPresence?,
    onProfileClick: () -> Unit,
    onTrackClick: () -> Unit,
) {
    val palette = nefySocialPalette()
    val track = presence?.track
    val status = when {
        presence?.isPlaying == true -> "PLAYING"
        track != null -> "PAUSED"
        presence != null -> "ONLINE"
        else -> "OFFLINE"
    }
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onProfileClick),
        colors = CardDefaults.cardColors(
            containerColor = when {
                presence?.isPlaying == true -> palette.hero
                track != null -> palette.cardElevated
                else -> palette.card
            },
        ),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            BoxAvatar(label = displayName.take(1).uppercase())
            if (track != null) {
                AsyncImage(
                    model = track.artworkUrl,
                    contentDescription = track.title,
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)),
                )
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(displayName, style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
                Text(handle?.let { "@$it" } ?: status.lowercase(), style = typo().labelMedium, color = palette.secondaryText)
                if (track != null) {
                    TextButton(onClick = onTrackClick, contentPadding = PaddingValues(0.dp)) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(track.title, style = typo().bodyMedium, maxLines = 1)
                            Text(track.artist, style = typo().bodySmall, maxLines = 1, color = palette.secondaryText)
                        }
                    }
                } else {
                    Text(
                        if (presence == null) "Last seen unavailable" else "Last updated ${presence.updatedAt?.replace("T", " ")?.take(16) ?: "recently"}",
                        style = typo().bodySmall,
                        color = palette.secondaryText,
                    )
                }
            }
            Text(status, style = typo().labelSmall, color = if (presence?.isPlaying == true) palette.accent else palette.secondaryText)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FriendTrackActionSheet(
    presence: NefyPresence,
    onDismiss: () -> Unit,
    onPlay: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onListenTogether: () -> Unit,
) {
    val track = presence.track ?: return
    val palette = nefySocialPalette()
    var showMore by rememberSaveable { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = palette.card) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("${presence.displayName} is ${if (presence.isPlaying) "playing" else "paused on"}", style = typo().titleLarge, fontWeight = FontWeight.Bold, color = palette.primaryText)
            Card(colors = CardDefaults.cardColors(containerColor = palette.cardElevated), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AsyncImage(
                        model = track.artworkUrl,
                        contentDescription = track.title,
                        modifier = Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)),
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(track.title, style = typo().titleMedium, color = palette.primaryText)
                        Text(track.artist, style = typo().bodySmall, color = palette.secondaryText)
                        Text(if (presence.isPlaying) "Listening now" else "Paused", style = typo().labelSmall, color = palette.accent)
                    }
                }
            }
            Button(onClick = onPlay, modifier = Modifier.fillMaxWidth()) { Text("Play") }
            FilledTonalButton(onClick = onAddToPlaylist, modifier = Modifier.fillMaxWidth()) { Text("Add to playlist") }
            FilledTonalButton(onClick = onListenTogether, modifier = Modifier.fillMaxWidth()) { Text("Listen Together") }
            TextButton(onClick = { showMore = !showMore }, modifier = Modifier.fillMaxWidth()) { Text("More") }
            if (showMore) {
                Text("Use Play to start this song locally, or open Listen Together to add it to a shared room.", style = typo().bodySmall, color = palette.secondaryText)
            }
            TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Close") }
        }
    }
}

@Composable
private fun FriendRequestCard(
    request: NefyFriendRequest,
    onAccept: (() -> Unit)?,
    onDecline: (() -> Unit)?,
) {
    val palette = nefySocialPalette()
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = palette.card)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BoxAvatar(label = request.displayName.take(1).uppercase())
            Column(modifier = Modifier.weight(1f)) {
                Text(request.displayName, style = typo().titleMedium, color = palette.primaryText)
                Text(request.handle?.let { "@$it" } ?: "Friend code · ${request.friendCode.orEmpty()}", style = typo().bodySmall, color = palette.secondaryText)
                Text(if (request.direction == "incoming") "Wants to connect" else "Request sent", style = typo().labelSmall)
            }
            if (onAccept != null && onDecline != null) {
                Column {
                    Button(onClick = onAccept, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Accept") }
                    TextButton(onClick = onDecline, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Decline") }
                }
            }
        }
    }
}

@Composable
private fun SearchResultCard(
    displayName: String,
    handle: String?,
    friendCode: String?,
    onAdd: () -> Unit,
) {
    val palette = nefySocialPalette()
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = palette.card)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            BoxAvatar(label = displayName.take(1).uppercase())
            Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                Text(displayName, style = typo().titleMedium, color = palette.primaryText)
                Text(handle?.let { "@$it" } ?: "Friend code · ${friendCode.orEmpty()}", style = typo().bodySmall, color = palette.secondaryText)
            }
            FilledTonalButton(onClick = onAdd) { Text("Add") }
        }
    }
}

@Composable
private fun SocialEmptyCard(title: String, subtitle: String) {
    val palette = nefySocialPalette()
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = palette.card)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
            Text(subtitle, style = typo().bodyMedium, color = palette.secondaryText)
        }
    }
}

private fun toListeningTrack(
    current: NowPlayingTrackState?,
    sharedViewModel: SharedViewModel,
): ListeningTrack? {
    val song = current?.songEntity ?: return null
    if (song.videoId.isBlank()) return null
    return ListeningTrack(
        videoId = song.videoId,
        title = song.title,
        artist = song.artistName?.joinToString(", ").orEmpty().ifBlank { "Unknown artist" },
        artworkUrl = current.mediaItem.metadata.artworkUri ?: song.thumbnails,
        durationMs = sharedViewModel.timeline.value.total.takeIf { it > 0L }
            ?: song.durationSeconds.toLong() * 1000L,
    )
}

@Composable
private fun PlaylistsContent(
    state: NefySocialState,
    currentTrack: ListeningTrack?,
    onCreatePlaylist: (String, String) -> Unit,
    onAddTrack: (String, ListeningTrack) -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onRemoveTrack: (String, String) -> Unit,
    onCreateInvite: (String) -> Unit,
    onJoinInvite: (String) -> Unit,
) {
    var playlistName by rememberSaveable { mutableStateOf("") }
    var playlistDescription by rememberSaveable { mutableStateOf("") }
    var inviteCode by rememberSaveable { mutableStateOf("") }
    var expandedPlaylistId by rememberSaveable { mutableStateOf<String?>(null) }

    Text("Saved playlists", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
    Text(
        "Keep a shared collection for your next listening session. Playlists stay private until you share an invite.",
        style = typo().bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Create a playlist", style = typo().titleMedium)
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = playlistName,
                onValueChange = { playlistName = it.take(96) },
                label = { Text("Playlist name") },
                singleLine = true,
            )
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = playlistDescription,
                onValueChange = { playlistDescription = it.take(240) },
                label = { Text("Description (optional)") },
                singleLine = true,
            )
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = playlistName.trim().isNotBlank(),
                onClick = {
                    onCreatePlaylist(playlistName.trim(), playlistDescription.trim())
                    playlistName = ""
                    playlistDescription = ""
                },
            ) {
                Text("Create playlist")
            }
        }
    }

    if (state.playlists.isEmpty()) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                "No saved playlists yet. Create one above, then add the song currently playing.",
                modifier = Modifier.padding(16.dp),
                style = typo().bodyMedium,
            )
        }
    }

    state.playlists.forEach { playlist ->
        PlaylistCard(
            playlist = playlist,
            expanded = expandedPlaylistId == playlist.id,
            currentTrack = currentTrack,
            inviteCode = if (state.lastInvitePlaylistId == playlist.id) state.lastInviteCode else null,
            onExpand = { expandedPlaylistId = if (expandedPlaylistId == playlist.id) null else playlist.id },
            onAddTrack = { track -> onAddTrack(playlist.id, track) },
            onPlayTrack = onPlayTrack,
            onRemoveTrack = { videoId -> onRemoveTrack(playlist.id, videoId) },
            onCreateInvite = { onCreateInvite(playlist.id) },
        )
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Join a shared playlist", style = typo().titleMedium)
            Text(
                "Paste an invite code from a friend to add the playlist to your account.",
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = inviteCode,
                onValueChange = { inviteCode = it.uppercase().take(16) },
                label = { Text("Invite code") },
                singleLine = true,
            )
            FilledTonalButton(
                modifier = Modifier.fillMaxWidth(),
                enabled = inviteCode.trim().isNotBlank(),
                onClick = {
                    onJoinInvite(inviteCode)
                    inviteCode = ""
                },
            ) {
                Text("Join playlist")
            }
        }
    }
}

@Composable
private fun PlaylistCard(
    playlist: NefySavedPlaylist,
    expanded: Boolean,
    currentTrack: ListeningTrack?,
    inviteCode: String?,
    onExpand: () -> Unit,
    onAddTrack: (ListeningTrack) -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onRemoveTrack: (String) -> Unit,
    onCreateInvite: () -> Unit,
) {
    val palette = nefySocialPalette()
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = palette.card)) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Surface(
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)),
                    color = MaterialTheme.colorScheme.primaryContainer,
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            playlist.name.take(2).uppercase(),
                            style = typo().titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = palette.primaryText,
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(playlist.name, style = typo().titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        playlist.description.ifBlank { "Collaborative playlist" },
                        style = typo().bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        "${playlist.tracks.size} songs · ${if (playlist.collaborationEnabled) "Shared" else "Private"}",
                        style = typo().labelSmall,
                        color = palette.accent,
                    )
                }
                TextButton(onClick = onExpand) {
                    Text(if (expanded) "Hide" else "Open")
                }
            }
            if (expanded) {
                if (playlist.tracks.isEmpty()) {
                    Text("This playlist is empty.", style = typo().bodySmall)
                } else {
                    playlist.tracks.forEach { track ->
                        val playableTrack = ListeningTrack(
                            videoId = track.videoId,
                            title = track.title,
                            artist = track.artist,
                            artworkUrl = track.artworkUrl,
                            durationMs = track.durationMs,
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            TextButton(
                                modifier = Modifier.weight(1f),
                                onClick = { onPlayTrack(playableTrack) },
                            ) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Text(track.title, style = typo().bodyMedium)
                                    Text(track.artist, style = typo().bodySmall)
                                }
                            }
                            TextButton(onClick = { onRemoveTrack(track.videoId) }) {
                                Text("Remove")
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(
                        enabled = currentTrack != null,
                        onClick = { currentTrack?.let(onAddTrack) },
                    ) {
                        Text("Add current song")
                    }
                    TextButton(onClick = onCreateInvite) {
                        Icon(imageVector = SimpIcons.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Share")
                    }
                }
                inviteCode?.let { code ->
                    Text(
                        "Invite code: $code",
                        style = typo().labelLarge,
                        color = palette.accent,
                    )
                    TextButton(
                        onClick = {
                            shareUrl(
                                title = "Join my Nefy playlist",
                                url = "nefy://playlist/$code",
                            )
                        },
                    ) {
                        Text("Share invite link")
                    }
                }
                Text(
                    "Tap a track to remove it from this collaborative playlist.",
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ActivityContent(
    state: NefySocialState,
    onVisibilityChange: (Boolean) -> Unit,
) {
    Text("Friend activity", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
    Text(
        "See who is listening now, whether they are playing or paused, and what your shared circle changed recently.",
        style = typo().bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    Text("Listening now", style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
    val currentUserId = state.profile?.userId
    val liveFriends = state.presence.filter { it.userId != currentUserId && it.track != null }
    if (liveFriends.isEmpty()) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                if (state.friends.isEmpty()) {
                    "Invite someone to a shared playlist or listening room to see their live status here."
                } else {
                    "No friends are listening right now. Their current song will appear here as soon as they start or pause playback."
                },
                modifier = Modifier.padding(16.dp),
                style = typo().bodyMedium,
            )
        }
    } else {
        liveFriends.forEach { presence ->
            LivePresenceCard(presence)
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Activity visibility", style = typo().titleMedium)
                Text(
                    if (state.activityVisibleToFriends) "Friends and shared-playlist collaborators can see your live status" else "Your listening activity is hidden",
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = state.activityVisibleToFriends,
                onCheckedChange = onVisibilityChange,
            )
        }
    }

    Text("Recent activity", style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
    if (state.activities.isEmpty()) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                "Playlist edits and room listening events will appear here.",
                modifier = Modifier.padding(16.dp),
                style = typo().bodyMedium,
            )
        }
    } else {
        state.activities.take(30).forEach { activity ->
            ActivityCard(activity)
        }
    }
}

@Composable
private fun LivePresenceCard(presence: NefyPresence) {
    val track = presence.track ?: return
    val palette = nefySocialPalette()
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (presence.isPlaying) {
                palette.hero
            } else {
                palette.cardElevated
            },
        ),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            BoxAvatar(label = presence.displayName.firstOrNull()?.uppercase() ?: "?")
            Column(modifier = Modifier.weight(1f)) {
                Text(presence.displayName, style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
                Text(
                    if (presence.isPlaying) "Listening now" else "Paused",
                    style = typo().labelMedium,
                    color = if (presence.isPlaying) palette.accent else palette.secondaryText,
                )
                Text(track.title, style = typo().bodyMedium, maxLines = 1, color = palette.primaryText)
                Text(track.artist, style = typo().bodySmall, maxLines = 1, color = palette.secondaryText)
            }
            Text(
                if (presence.isPlaying) "PLAYING" else "PAUSED",
                style = typo().labelSmall,
                color = if (presence.isPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ActivityCard(activity: NefyActivityItem) {
    val palette = nefySocialPalette()
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = palette.card)) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(activity.actorName, style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
            Text(activityDescription(activity), style = typo().bodyMedium, color = palette.primaryText)
            activity.track?.let { track ->
                Text(
                    "${track.title} · ${track.artist}",
                    style = typo().bodySmall,
                    color = palette.accent,
                )
            }
            Text(
                activity.createdAt.replace("T", " ").take(19),
                style = typo().labelSmall,
                color = palette.secondaryText,
            )
        }
    }
}

private fun activityDescription(activity: NefyActivityItem): String = when (activity.eventType) {
    "playlist_created" -> "created a playlist"
    "track_added" -> "added a song to a playlist"
    "playlist_shared" -> "shared a playlist"
    "now_listening" -> "is listening now"
    else -> activity.eventType.replace('_', ' ')
}

@Composable
private fun EmptyRoomContent(
    displayName: String,
    roomCode: String,
    connection: ListeningRoomConnection,
    errorMessage: String?,
    onDisplayNameChange: (String) -> Unit,
    onRoomCodeChange: (String) -> Unit,
    onCreateRoom: () -> Unit,
    onJoinRoom: () -> Unit,
) {
    val palette = nefySocialPalette()
    val isCreatingRoom = connection == ListeningRoomConnection.Connecting
    val canCreateRoom = displayName.trim().isNotBlank() && !isCreatingRoom
    val canJoinRoom = roomCode.isNotBlank() && displayName.trim().isNotBlank() && !isCreatingRoom

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = SimpIcons.PeopleAlt,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(32.dp),
                )
                Text(
                    text = stringResource(Res.string.start_listening_together),
                    style = typo().headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = palette.primaryText,
                )
                Text(
                    text = stringResource(Res.string.join_room_description),
                    style = typo().bodyMedium,
                    color = palette.primaryText,
                )
            }
        }

        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = displayName,
            onValueChange = onDisplayNameChange,
            label = { Text("Display name") },
            singleLine = true,
        )
        Button(
            modifier = Modifier.fillMaxWidth(),
            enabled = canCreateRoom,
            onClick = onCreateRoom,
        ) {
            Icon(imageVector = SimpIcons.PeopleAlt, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isCreatingRoom) {
                    "Creating room…"
                } else {
                    stringResource(Res.string.create_listening_room)
                },
            )
        }
        Text(
            text = "Only accepted Nefy friends and explicitly invited people can join this room.",
            style = typo().bodySmall,
            color = palette.secondaryText,
        )
        if (connection == ListeningRoomConnection.Reconnecting) {
            Text(
                text = "Connecting to the room server…",
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        errorMessage?.let { message ->
            Text(
                text = message,
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = stringResource(Res.string.no_room_yet),
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.weight(1f))
        }

        Text(
            text = "Have an invitation from a friend?",
            style = typo().titleMedium,
            color = palette.primaryText,
        )
        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = roomCode,
            onValueChange = onRoomCodeChange,
            label = { Text(stringResource(Res.string.listening_room_code)) },
            placeholder = { Text(stringResource(Res.string.room_code_hint)) },
            singleLine = true,
        )
        FilledTonalButton(
            modifier = Modifier.fillMaxWidth(),
            enabled = canJoinRoom,
            onClick = onJoinRoom,
        ) {
            Text(text = stringResource(Res.string.join_room))
        }
    }
}

@Composable
private fun ActiveRoomContent(
    state: ListeningRoomState,
    onPlayingChange: (Boolean) -> Unit,
    onSeek: (Long) -> Unit,
    onShareTrack: () -> Unit,
    onEnqueueTrack: () -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onFollowHostChange: (Boolean) -> Unit,
    onRemoteControlChange: (Boolean) -> Unit,
    onAddSong: () -> Unit,
    onInviteFriends: () -> Unit,
    onOpenChat: () -> Unit,
    onRemoveQueueTrack: (String) -> Unit,
    onLeaveRoom: () -> Unit,
) {
    val palette = nefySocialPalette()
    val track = state.currentTrack
    val isHost = state.hostId == state.currentUserId
    val canControl = isHost || state.remoteControlEnabled
    var roomClockMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(state.isPlaying, state.positionUpdatedAtMs, track?.videoId) {
        while (state.isPlaying) {
            roomClockMs = System.currentTimeMillis()
            delay(500L)
        }
    }
    val currentPosition =
        if (state.isPlaying && state.positionUpdatedAtMs > 0L) {
            state.positionMs + (roomClockMs - state.positionUpdatedAtMs).coerceAtLeast(0L)
        } else {
            state.positionMs
        }
    val duration = track?.durationMs?.takeIf { it > 0L }
    var isSeeking by remember { mutableStateOf(false) }
    var pendingSeekMs by remember(track?.videoId) { mutableStateOf(currentPosition) }
    LaunchedEffect(currentPosition, track?.videoId, isSeeking) {
        if (!isSeeking) pendingSeekMs = currentPosition
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = stringResource(Res.string.listening_room), style = typo().headlineSmall)
                Text(
                    text = state.roomCode.orEmpty(),
                    style = typo().titleMedium,
                    color = palette.accent,
                )
                Text(
                    text = when (state.connection) {
                        ListeningRoomConnection.Connected -> "Connected · revision ${state.revision}"
                        ListeningRoomConnection.Connecting -> "Connecting…"
                        ListeningRoomConnection.Reconnecting -> "Reconnecting…"
                        ListeningRoomConnection.Disconnected -> "Disconnected"
                    },
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = onInviteFriends) {
                    Icon(imageVector = SimpIcons.PeopleAlt, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Invite")
                }
                TextButton(
                    onClick = {
                        shareUrl(
                            title = "Join my Nefy listening room",
                            url = "nefy://room/${state.roomCode}",
                        )
                    },
                ) {
                    Icon(imageVector = SimpIcons.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share")
                }
                TextButton(onClick = onOpenChat) {
                    Text("Chat${if (state.chatMessages.isEmpty()) "" else " ${state.chatMessages.size}"}")
                }
            }
        }

        if (state.recentReactions.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                state.recentReactions.takeLast(5).forEach { reaction ->
                    Surface(shape = CircleShape, color = palette.accentContainer, modifier = Modifier.padding(start = 4.dp)) {
                        Text(reaction.emoji, modifier = Modifier.padding(8.dp), style = typo().titleMedium)
                    }
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = palette.cardElevated),
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(text = stringResource(Res.string.currently_listening), style = typo().labelLarge, color = palette.secondaryText)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(
                        model = track?.artworkUrl,
                        contentDescription = track?.title,
                        modifier = Modifier.size(88.dp).clip(RoundedCornerShape(18.dp)),
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(text = track?.title ?: "Waiting for a song", style = typo().titleMedium, color = palette.primaryText, maxLines = 2)
                        Text(text = track?.artist ?: "Add a song from Nefy Search or Library", style = typo().bodySmall, color = palette.secondaryText, maxLines = 2)
                    }
                    if (canControl) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RippleIconButton(
                                imageVector = SimpIcons.SkipPrevious,
                                tint = MaterialTheme.colorScheme.onSurface,
                                onClick = onSkipPrevious,
                            )
                            RippleIconButton(
                                imageVector = if (state.isPlaying) SimpIcons.Pause else SimpIcons.PlayArrow,
                                tint = MaterialTheme.colorScheme.onSurface,
                                onClick = { onPlayingChange(!state.isPlaying) },
                            )
                            RippleIconButton(
                                imageVector = SimpIcons.SkipNext,
                                tint = MaterialTheme.colorScheme.onSurface,
                                onClick = onSkipNext,
                            )
                        }
                    } else {
                        Text(
                            text = "Host control",
                            style = typo().bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                duration?.let { totalDuration ->
                    Slider(
                        value = pendingSeekMs.coerceIn(0L, totalDuration).toFloat(),
                        onValueChange = { value ->
                            isSeeking = true
                            pendingSeekMs = value.toLong()
                        },
                        onValueChangeFinished = {
                            isSeeking = false
                            if (canControl) onSeek(pendingSeekMs.coerceIn(0L, totalDuration))
                        },
                        valueRange = 0f..totalDuration.toFloat(),
                        enabled = canControl,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = formatRoomTime(pendingSeekMs),
                            style = typo().labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = formatRoomTime(totalDuration),
                            style = typo().labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onAddSong) {
                        Icon(imageVector = SimpIcons.PeopleAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add song")
                    }
                    if (track != null && canControl) {
                        TextButton(onClick = onEnqueueTrack) { Text("Queue current") }
                    }
                }
            }
        }

        {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = palette.card),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(text = "Shared queue", style = typo().titleMedium, color = palette.primaryText)
                    if (state.queue.isEmpty()) {
                        Text("Queue is empty — add a song from Nefy Search or Library.", style = typo().bodySmall, color = palette.secondaryText)
                    }
                    state.queue.take(8).forEachIndexed { index, queuedTrack ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable(enabled = canControl) { onPlayTrack(queuedTrack) }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (index == state.queueIndex) "Now playing · ${queuedTrack.title}" else queuedTrack.title,
                                    style = typo().bodyMedium,
                                    color = palette.primaryText,
                                )
                                Text(text = queuedTrack.artist, style = typo().bodySmall, color = palette.secondaryText)
                            }
                            if (canControl && index != state.queueIndex) {
                                TextButton(onClick = { onRemoveQueueTrack(queuedTrack.videoId) }, contentPadding = PaddingValues(horizontal = 6.dp)) {
                                    Text("Remove", color = palette.danger)
                                }
                            }
                        }
                    }
                }
            }
        }

        Text(text = stringResource(Res.string.members), style = typo().titleMedium, color = palette.primaryText)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            state.members.take(4).forEach { member ->
                BoxAvatar(label = member.displayName.firstOrNull()?.uppercase() ?: "?")
            }
            Text(
                text = if (isHost) stringResource(Res.string.you_are_host) else "Following the host",
                style = typo().bodySmall,
                color = palette.secondaryText,
                modifier = Modifier.align(Alignment.CenterVertically),
            )
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = stringResource(Res.string.follow_host), style = typo().titleMedium)
                    Text(
                        text = stringResource(Res.string.invite_friends),
                        style = typo().bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = state.followHost, onCheckedChange = onFollowHostChange)
            }
        }

        if (isHost) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Remote control", style = typo().titleMedium)
                        Text(
                            text = "Allow everyone in this room to play, pause, and choose songs",
                            style = typo().bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = state.remoteControlEnabled,
                        onCheckedChange = onRemoteControlChange,
                    )
                }
            }
        } else {
            Text(
                text = if (state.remoteControlEnabled) {
                    "Remote control is enabled — you can control playback"
                } else {
                    "The host controls playback"
                },
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        TextButton(
            modifier = Modifier.align(Alignment.CenterHorizontally),
            onClick = onLeaveRoom,
        ) {
            Text(text = stringResource(Res.string.leave_room))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoomChatSheet(
    state: ListeningRoomState,
    onSendChat: (String) -> Unit,
    onSendReaction: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val palette = nefySocialPalette()
    var selectedTab by rememberSaveable { mutableStateOf("chat") }
    var draft by rememberSaveable { mutableStateOf("") }
    val reactions = listOf("❤", "✨", "🔥", "👏", "😂", "🎵")

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = palette.card) {
        Column(
            modifier = Modifier.fillMaxWidth().heightIn(max = 720.dp).padding(horizontal = 18.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Room chat", style = typo().headlineSmall, fontWeight = FontWeight.Bold, color = palette.primaryText)
                    Text("${state.roomCode.orEmpty()} · ${state.members.size} listeners", style = typo().bodySmall, color = palette.secondaryText)
                }
                TextButton(onClick = onDismiss) { Text("Close", color = palette.accent) }
            }
            state.currentTrack?.let { track ->
                Card(colors = CardDefaults.cardColors(containerColor = palette.cardElevated), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AsyncImage(model = track.artworkUrl, contentDescription = track.title, modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(track.title, style = typo().titleMedium, color = palette.primaryText, maxLines = 1)
                            Text(if (state.isPlaying) "Shared listening · live" else "Shared listening · paused", style = typo().bodySmall, color = palette.secondaryText)
                        }
                    }
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("chat" to "Chat", "reactions" to "Reactions").forEach { (key, label) ->
                    Surface(
                        modifier = Modifier.weight(1f).clickable { selectedTab = key },
                        shape = RoundedCornerShape(18.dp),
                        color = if (selectedTab == key) palette.accentContainer else palette.card,
                    ) {
                        Text(label, modifier = Modifier.padding(vertical = 10.dp), textAlign = TextAlign.Center, color = if (selectedTab == key) palette.accent else palette.primaryText)
                    }
                }
            }
            if (selectedTab == "chat") {
                Column(
                    modifier = Modifier.weight(1f, fill = false).fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (state.chatMessages.isEmpty()) {
                        Text("Say something to the room.", style = typo().bodyMedium, color = palette.secondaryText)
                    } else {
                        state.chatMessages.takeLast(30).forEach { message ->
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                                BoxAvatar(label = message.displayName.take(1).uppercase())
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(message.displayName, style = typo().labelLarge, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
                                    Surface(shape = RoundedCornerShape(16.dp), color = palette.cardElevated) {
                                        Text(message.message, modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp), color = palette.primaryText)
                                    }
                                    Text(formatRoomChatTime(message.createdAtMs), style = typo().labelSmall, color = palette.secondaryText)
                                }
                            }
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        modifier = Modifier.weight(1f),
                        value = draft,
                        onValueChange = { draft = it.take(280) },
                        placeholder = { Text("Message the room…") },
                        singleLine = true,
                    )
                    Button(onClick = { if (draft.trim().isNotBlank()) { onSendChat(draft); draft = "" } }, enabled = draft.trim().isNotBlank()) { Text("Send") }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    reactions.take(4).forEach { emoji ->
                        TextButton(onClick = { onSendReaction(emoji) }) { Text(emoji, style = typo().titleLarge) }
                    }
                }
            } else {
                Column(
                    modifier = Modifier.weight(1f, fill = false).fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Reactions float above the room for everyone.", style = typo().bodyMedium, color = palette.secondaryText)
                    state.recentReactions.takeLast(24).reversed().forEach { reaction ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(reaction.emoji, style = typo().headlineMedium)
                            Text("${reaction.displayName} reacted", style = typo().bodyMedium, color = palette.primaryText)
                            Spacer(modifier = Modifier.weight(1f))
                            Text(formatRoomChatTime(reaction.createdAtMs), style = typo().labelSmall, color = palette.secondaryText)
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    reactions.forEach { emoji ->
                        FilledTonalButton(onClick = { onSendReaction(emoji) }) { Text(emoji, style = typo().titleMedium) }
                    }
                }
            }
        }
    }
}

private fun formatRoomChatTime(timestampMs: Long): String {
    val totalMinutes = ((timestampMs.coerceAtLeast(0L) / 60_000L) % (24 * 60)).toInt()
    val hour = (totalMinutes / 60).toString().padStart(2, '0')
    val minute = (totalMinutes % 60).toString().padStart(2, '0')
    return "$hour:$minute"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoomSongPickerSheet(
    onDismiss: () -> Unit,
    onAddTrack: (ListeningTrack) -> Unit,
    searchViewModel: SearchViewModel = koinInject(),
    libraryViewModel: NowPlayingBottomSheetViewModel = koinInject(),
    localPlaylistRepository: LocalPlaylistRepository = koinInject(),
) {
    val searchState by searchViewModel.searchScreenState.collectAsStateWithLifecycle()
    val searchUiState by searchViewModel.searchScreenUIState.collectAsStateWithLifecycle()
    val libraryState by libraryViewModel.uiState.collectAsStateWithLifecycle()
    var source by rememberSaveable { mutableStateOf("search") }
    var query by rememberSaveable { mutableStateOf("") }
    var selectedPlaylistId by rememberSaveable { mutableStateOf<Long?>(null) }
    var selectedPlaylistTitle by rememberSaveable { mutableStateOf("") }
    var libraryTracks by remember { mutableStateOf<List<SongEntity>>(emptyList()) }

    LaunchedEffect(selectedPlaylistId) {
        libraryTracks = selectedPlaylistId?.let { localPlaylistRepository.getFullPlaylistTracks(it) }.orEmpty()
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier.fillMaxWidth().heightIn(max = 640.dp).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Add to shared queue", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
            Text("Choose music already available in Nefy.", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (source == "search") Button(onClick = { source = "search" }, modifier = Modifier.weight(1f)) { Text("Search Nefy") }
                else TextButton(onClick = { source = "search" }, modifier = Modifier.weight(1f)) { Text("Search Nefy") }
                if (source == "library") Button(onClick = { source = "library" }, modifier = Modifier.weight(1f)) { Text("Library") }
                else TextButton(onClick = { source = "library" }, modifier = Modifier.weight(1f)) { Text("Library") }
            }

            if (source == "search") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it.take(80) },
                        modifier = Modifier.weight(1f),
                        label = { Text("Song or artist") },
                        singleLine = true,
                    )
                    Button(onClick = { searchViewModel.searchSongs(query) }, enabled = query.trim().isNotBlank()) { Text("Search") }
                }
                when (searchUiState) {
                    SearchScreenUIState.Loading -> Text("Searching Nefy…", style = typo().bodySmall)
                    SearchScreenUIState.Error -> Text("Nefy search failed. Try again.", style = typo().bodySmall, color = MaterialTheme.colorScheme.error)
                    else -> Unit
                }
                if (searchState.searchSongsResult.isEmpty() && searchUiState != SearchScreenUIState.Loading) {
                    SocialEmptyCard("Search for a song", "Results from Nefy will appear here.")
                } else {
                    searchState.searchSongsResult.take(30).forEach { result ->
                        val track = ListeningTrack(
                            videoId = result.videoId,
                            title = result.title.orEmpty().ifBlank { "Untitled" },
                            artist = result.artists?.joinToString(", ") { it.name }.orEmpty().ifBlank { "Unknown artist" },
                            artworkUrl = result.thumbnails?.maxByOrNull { it.width }?.url,
                            durationMs = result.durationSeconds?.toLong()?.times(1000L) ?: 0L,
                        )
                        RoomPickerTrackRow(track = track, actionLabel = "Add", onAction = { onAddTrack(track) })
                    }
                }
            } else if (selectedPlaylistId == null) {
                Text("Your Library", style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
                if (libraryState.listLocalPlaylist.isEmpty()) {
                    SocialEmptyCard("No local playlists yet", "Create a playlist in Nefy Library first.")
                } else {
                    libraryState.listLocalPlaylist.forEach { playlist ->
                        Card(modifier = Modifier.fillMaxWidth().clickable {
                            selectedPlaylistId = playlist.id
                            selectedPlaylistTitle = playlist.title
                        }) {
                            Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                BoxAvatar(label = playlist.title.take(1).uppercase())
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(playlist.title, style = typo().titleMedium, fontWeight = FontWeight.SemiBold)
                                    Text("${playlist.tracks?.size ?: 0} songs", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("Open", style = typo().labelMedium, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { selectedPlaylistId = null; libraryTracks = emptyList() }) { Text("Back") }
                    Text(selectedPlaylistTitle, style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
                }
                if (libraryTracks.isEmpty()) {
                    SocialEmptyCard("Playlist is empty", "Add songs to this Library playlist first.")
                } else {
                    libraryTracks.forEach { song ->
                        val track = ListeningTrack(
                            videoId = song.videoId,
                            title = song.title,
                            artist = song.artistName?.joinToString(", ").orEmpty().ifBlank { "Unknown artist" },
                            artworkUrl = song.thumbnails,
                            durationMs = song.durationSeconds.toLong() * 1000L,
                        )
                        RoomPickerTrackRow(track = track, actionLabel = "Add", onAction = { onAddTrack(track) })
                    }
                }
            }
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Done") }
        }
    }
}

@Composable
private fun RoomPickerTrackRow(track: ListeningTrack, actionLabel: String, onAction: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AsyncImage(model = track.artworkUrl, contentDescription = track.title, modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)))
            Column(modifier = Modifier.weight(1f)) {
                Text(track.title, style = typo().bodyMedium, maxLines = 2)
                Text(track.artist, style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
            TextButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoomInviteSheet(
    friends: List<com.nefy.app.social.listening.NefyFriend>,
    roomCode: String,
    onInviteFriend: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val palette = nefySocialPalette()
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = palette.card) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Invite friends", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
            Text("Only accepted Nefy friends can join this room.", style = typo().bodySmall, color = palette.secondaryText)
            if (friends.isEmpty()) {
                SocialEmptyCard("No accepted friends yet", "Add friends from the Friends tab, or share the room link below.")
            } else {
                friends.forEach { friend ->
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        BoxAvatar(label = friend.displayName.take(1).uppercase())
                        Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(friend.displayName, style = typo().titleMedium, color = palette.primaryText)
                            Text(friend.handle?.let { "@$it" } ?: "Nefy friend", style = typo().bodySmall, color = palette.secondaryText)
                        }
                        TextButton(onClick = {
                            onInviteFriend(friend.userId)
                            shareUrl(title = "Join my Nefy listening room", url = "nefy://room/$roomCode")
                        }) { Text("Invite", color = palette.accent) }
                    }
                }
            }
            FilledTonalButton(onClick = { shareUrl(title = "Join my Nefy listening room", url = "nefy://room/$roomCode") }, modifier = Modifier.fillMaxWidth()) {
                Icon(imageVector = SimpIcons.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Share room link")
            }
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Close") }
        }
    }
}

@Composable
private fun formatRoomTime(milliseconds: Long): String {
    val seconds = (milliseconds.coerceAtLeast(0L) / 1_000L).toInt()
    val minutes = seconds / 60
    val remainder = (seconds % 60).toString().padStart(2, '0')
    return "$minutes:$remainder"
}

@Composable
private fun BoxAvatar(label: String) {
    val palette = nefySocialPalette()
    Surface(
        modifier = Modifier.size(42.dp).clip(CircleShape),
        color = palette.accentContainer,
        contentColor = palette.primaryText,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text = label, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        }
    }
}
