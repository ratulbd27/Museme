package com.nefy.app.ui.screen.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import androidx.compose.ui.Alignment
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import androidx.navigation.NavController
import com.nefy.app.expect.shareUrl
import com.nefy.app.social.listening.ListeningRoomConnection
import com.nefy.app.social.listening.ListeningRoomController
import com.nefy.app.social.listening.RoomInvitation
import com.nefy.app.social.listening.ListeningRoomState
import com.nefy.app.social.listening.ListeningTrack
import com.nefy.app.social.listening.NefyActivityItem
import com.nefy.app.social.listening.NefyPresence
import com.nefy.app.social.listening.NefyFriendRequest
import com.nefy.app.social.listening.NefyIdentity
import com.nefy.app.social.listening.NefySavedPlaylist
import com.nefy.app.social.listening.NefySocialState
import com.nefy.app.ui.component.RippleIconButton
import com.nefy.app.ui.icon.Add
import com.nefy.app.ui.icon.ArrowBackIosNew
import com.nefy.app.ui.icon.MoreVert
import com.nefy.app.ui.icon.Pause
import com.nefy.app.ui.icon.PeopleAlt
import com.nefy.app.ui.icon.PlayArrow
import com.nefy.app.ui.icon.QueueMusic
import com.nefy.app.ui.icon.Share
import com.nefy.app.ui.icon.SkipNext
import com.nefy.app.ui.icon.SkipPrevious
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.navigation.destination.home.FriendsDestination
import com.nefy.app.ui.theme.nefySocialPalette
import com.nefy.app.ui.theme.typo
import com.maxrave.domain.data.entities.LocalPlaylistEntity
import com.maxrave.domain.data.entities.SongEntity
import com.maxrave.domain.repository.LocalPlaylistRepository
import com.maxrave.domain.repository.SongRepository
import com.maxrave.domain.mediaservice.handler.NowPlayingTrackState
import com.nefy.app.viewModel.NowPlayingBottomSheetViewModel
import com.nefy.app.viewModel.SearchScreenUIState
import com.nefy.app.viewModel.SearchViewModel
import com.nefy.app.viewModel.SettingsViewModel
import com.nefy.app.viewModel.SharedViewModel
import com.nefy.app.viewModel.UIEvent
import nefy.composeapp.generated.resources.Res
import nefy.composeapp.generated.resources.create_listening_room
import nefy.composeapp.generated.resources.currently_listening
import nefy.composeapp.generated.resources.follow_host
import nefy.composeapp.generated.resources.friend_listening
import nefy.composeapp.generated.resources.invite_friends
import nefy.composeapp.generated.resources.join_room
import nefy.composeapp.generated.resources.nefy_icon
import nefy.composeapp.generated.resources.join_room_description
import nefy.composeapp.generated.resources.leave_room
import nefy.composeapp.generated.resources.listening_room
import nefy.composeapp.generated.resources.listening_room_code
import nefy.composeapp.generated.resources.members
import nefy.composeapp.generated.resources.no_room_yet
import nefy.composeapp.generated.resources.room_code_hint
import nefy.composeapp.generated.resources.share_room
import nefy.composeapp.generated.resources.start_listening_together
import nefy.composeapp.generated.resources.you_are_host
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import org.koin.compose.viewmodel.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FriendsScreen(
    navController: NavController,
    initialRoomCode: String? = null,
    initialPage: String? = null,
    playlistInvite: String? = null,
    playlistId: String? = null,
    roomController: ListeningRoomController = koinInject(),
    sharedViewModel: SharedViewModel = koinInject(),
    settingsViewModel: SettingsViewModel = koinViewModel(),
) {
    NefyFriendsFoundation(
        navController = navController,
        initialRoomCode = initialRoomCode,
        initialPage = initialPage,
        playlistInvite = playlistInvite,
        playlistId = playlistId,
        roomController = roomController,
        sharedViewModel = sharedViewModel,
        settingsViewModel = settingsViewModel,
    )
    return

    val roomState by roomController.state.collectAsStateWithLifecycle()
    val socialState by roomController.socialState.collectAsStateWithLifecycle()
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    val identity: NefyIdentity = koinInject()
    var roomCode by rememberSaveable { mutableStateOf(initialRoomCode.orEmpty()) }
    var displayName by rememberSaveable { mutableStateOf(identity.displayName) }
    var selectedSection by rememberSaveable { mutableStateOf("room") }

    LaunchedEffect(Unit) {
        roomController.loadSocial()
    }

    LaunchedEffect(
        roomState.revision,
        roomState.currentTrack?.videoId,
        roomState.isPlaying,
        roomState.positionMs,
        roomState.positionUpdatedAtMs,
        nowPlayingState?.songEntity?.videoId,
    ) {
        val sharedTrack = roomState.currentTrack
        if (sharedTrack != null && sharedTrack.videoId.isNotBlank() && sharedTrack.videoId != "museme-demo") {
            if (nowPlayingState?.songEntity?.videoId != sharedTrack.videoId) {
                sharedViewModel.loadSharedMediaItem(sharedTrack.videoId)
                delay(900)
            }
            val syncedPosition =
                if (roomState.isPlaying && roomState.positionUpdatedAtMs > 0L) {
                    roomState.positionMs + (System.currentTimeMillis() - roomState.positionUpdatedAtMs).coerceAtLeast(0L)
                } else {
                    roomState.positionMs
                }
            sharedViewModel.applyListeningPlayback(roomState.isPlaying, syncedPosition)
        }
    }

    val canControlRoom = roomState.hostId == roomState.currentUserId || roomState.remoteControlEnabled
    val latestRoomState by rememberUpdatedState(roomState)
    val latestCanControlRoom by rememberUpdatedState(canControlRoom)
    var lastAdvanceRequestTrackId by remember(roomState.roomCode) { mutableStateOf<String?>(null) }
    LaunchedEffect(roomState.currentTrack?.videoId) {
        if (roomState.currentTrack?.videoId != lastAdvanceRequestTrackId) {
            lastAdvanceRequestTrackId = null
        }
    }
    LaunchedEffect(roomState.roomCode) {
        sharedViewModel.playbackEnded.collect { endedTrackId ->
            val activeState = latestRoomState
            if (
                activeState.roomCode != null &&
                latestCanControlRoom &&
                activeState.isPlaying &&
                activeState.currentTrack?.videoId == endedTrackId &&
                lastAdvanceRequestTrackId != endedTrackId
            ) {
                lastAdvanceRequestTrackId = endedTrackId
                roomController.advanceQueue(endedTrackId)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(Res.string.friend_listening),
                        style = typo().titleMedium,
                    )
                },
                navigationIcon = {
                    RippleIconButton(
                        imageVector = SimpIcons.ArrowBackIosNew,
                        tint = MaterialTheme.colorScheme.onSurface,
                        onClick = { navController.navigateUp() },
                    )
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(innerPadding)
                    .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf("room" to "Room", "playlists" to "Playlists", "activity" to "Activity").forEach { (key, label) ->
                    if (selectedSection == key) {
                        Button(onClick = { selectedSection = key }, modifier = Modifier.weight(1f)) { Text(label) }
                    } else {
                        TextButton(onClick = { selectedSection = key }, modifier = Modifier.weight(1f)) { Text(label) }
                    }
                }
            }

            when (selectedSection) {
                "playlists" -> PlaylistsContent(
                    state = socialState,
                    currentTrack = toListeningTrack(nowPlayingState, sharedViewModel) ?: roomState.currentTrack,
                    onCreatePlaylist = { name, description -> roomController.createPlaylist(name, description) },
                    onAddTrack = roomController::addPlaylistTrack,
                    onPlayTrack = { track ->
                        sharedViewModel.loadSharedMediaItem(track.videoId)
                        if (roomState.roomCode != null) roomController.setTrack(track)
                    },
                    onRemoveTrack = roomController::removePlaylistTrack,
                    currentUserId = socialState.profile?.userId.orEmpty(),
                    onCreateInvite = roomController::createPlaylistInvite,
                    onJoinInvite = roomController::joinPlaylistInvite,
                )
                "activity" -> ActivityContent(
                    state = socialState,
                    onVisibilityChange = roomController::setActivityVisibility,
                )
                else -> if (roomState.roomCode == null) {
                EmptyRoomContent(
                    displayName = displayName,
                    roomCode = roomCode,
                    onDisplayNameChange = {
                        displayName = it.take(24)
                        identity.setDisplayName(displayName)
                    },
                    onRoomCodeChange = { roomCode = it.uppercase().take(8) },
                    connection = roomState.connection,
                    errorMessage = roomState.errorMessage,
                    onCreateRoom = { roomController.createRoom(displayName) },
                    onJoinRoom = { roomController.joinRoom(roomCode, displayName) },
                )
            } else {
                ActiveRoomContent(
                    state = roomState,
                    onPlayingChange = { isPlaying ->
                        val position = timelineState.current.coerceAtLeast(0L)
                        roomController.setPlayback(isPlaying = isPlaying, positionMs = position)
                        sharedViewModel.applyListeningPlayback(isPlaying, position)
                    },
                    onSeek = { positionMs ->
                        roomController.setPlayback(
                            isPlaying = roomState.isPlaying,
                            positionMs = positionMs,
                        )
                        sharedViewModel.applyListeningPlayback(roomState.isPlaying, positionMs)
                    },
                    onShareTrack = {
                        toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::setTrack)
                    },
                    onEnqueueTrack = {
                        toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::enqueueTrack)
                    },
                    onPlayTrack = roomController::setTrack,
                    onSkipNext = roomController::skipNext,
                    onSkipPrevious = roomController::skipPrevious,
                    onFollowHostChange = roomController::setFollowHost,
                    onRemoteControlChange = roomController::setRemoteControl,
                    onAddSong = {},
                    onInviteFriends = {},
                    onOpenChat = {},
                    onRemoveQueueTrack = {},
                    onLeaveRoom = roomController::leaveRoom,
                )
            }
        }
    }
}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NefyFriendsFoundation(
    navController: NavController,
    initialRoomCode: String?,
    initialPage: String?,
    playlistInvite: String?,
    playlistId: String?,
    roomController: ListeningRoomController,
    sharedViewModel: SharedViewModel,
    settingsViewModel: SettingsViewModel,
) {
    val socialState by roomController.socialState.collectAsStateWithLifecycle()
    val socialPalette = nefySocialPalette()
    val roomState by roomController.state.collectAsStateWithLifecycle()
    val invitations by roomController.invitations.collectAsStateWithLifecycle()
    val nowPlayingState by sharedViewModel.nowPlayingState.collectAsStateWithLifecycle()
    val timelineState by sharedViewModel.timeline.collectAsStateWithLifecycle()
    val identity: NefyIdentity = koinInject()
    val localPlaylistRepository: LocalPlaylistRepository = koinInject()
    val songRepository: SongRepository = koinInject()
    val coroutineScope = rememberCoroutineScope()
    var socialPage by rememberSaveable {
        mutableStateOf(
            when {
                !initialRoomCode.isNullOrBlank() -> "listen"
                !playlistId.isNullOrBlank() -> "playlists"
                initialPage in setOf("feed", "friends", "requests", "find", "activity") -> initialPage!!
                else -> "feed"
            },
        )
    }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var roomCode by rememberSaveable { mutableStateOf(initialRoomCode.orEmpty()) }
    var displayName by rememberSaveable { mutableStateOf(identity.displayName) }
    var selectedPresence by remember { mutableStateOf<NefyPresence?>(null) }
    var selectedFriend by remember { mutableStateOf<com.nefy.app.social.listening.NefyFriend?>(null) }
    var selectedPlaylistTrack by remember { mutableStateOf<ListeningTrack?>(null) }
    var showRoomSongPicker by rememberSaveable { mutableStateOf(false) }
    var showRoomInviteSheet by rememberSaveable { mutableStateOf(false) }
    var showRoomChat by rememberSaveable { mutableStateOf(false) }
    var pendingPlaylistInvite by rememberSaveable { mutableStateOf(playlistInvite?.takeIf { it.isNotBlank() }) }
    val latestRoomState by rememberUpdatedState(roomState)
    val latestCanControlRoom by rememberUpdatedState(roomState.hostId == roomState.currentUserId || roomState.remoteControlEnabled)
    var lastAdvanceRequestTrackId by remember(roomState.roomCode) { mutableStateOf<String?>(null) }
    var requestedSharedVideoId by remember(roomState.roomCode) { mutableStateOf<String?>(null) }
    val incomingRequests = socialState.pendingRequests.filter { it.direction == "incoming" }
    val selectedSharedPlaylist = playlistId?.let { id -> socialState.playlists.firstOrNull { it.id == id } }

    LaunchedEffect(Unit) {
        runCatching { settingsViewModel.syncSelectedNefyIdentity() }
        roomController.loadSocial()
    }
    LaunchedEffect(roomState.currentTrack?.videoId) {
        if (roomState.currentTrack?.videoId != lastAdvanceRequestTrackId) lastAdvanceRequestTrackId = null
        if (roomState.currentTrack?.videoId != requestedSharedVideoId) requestedSharedVideoId = null
    }
    LaunchedEffect(roomState.roomCode) {
        sharedViewModel.playbackEnded.collect { endedTrackId ->
            val active = latestRoomState
            if (active.roomCode != null && latestCanControlRoom && active.isPlaying && active.currentTrack?.videoId == endedTrackId && lastAdvanceRequestTrackId != endedTrackId) {
                lastAdvanceRequestTrackId = endedTrackId
                roomController.advanceQueue(endedTrackId)
            }
        }
    }
    LaunchedEffect(roomState.revision, roomState.currentTrack?.videoId, roomState.isPlaying, roomState.positionMs, roomState.positionUpdatedAtMs) {
        val sharedTrack = roomState.currentTrack
        if (roomState.roomCode != null && sharedTrack == null) {
            sharedViewModel.stopListeningPlayback()
        }
        if (sharedTrack != null && sharedTrack.videoId.isNotBlank()) {
            val shouldFollowRoom = roomState.followHost || roomState.hostId == roomState.currentUserId
            if (nowPlayingState?.songEntity?.videoId != sharedTrack.videoId && requestedSharedVideoId != sharedTrack.videoId) {
                requestedSharedVideoId = sharedTrack.videoId
                sharedViewModel.loadSharedMediaItem(
                    sharedTrack.videoId,
                    // Room playback is started by SharedViewModel only after the exact
                    // media item reaches READY; do not arm the player during loading.
                    playWhenReady = false,
                )
            }
            if (shouldFollowRoom) {
                val syncedPosition = roomState.estimatedPositionMs()
                sharedViewModel.applyListeningPlayback(roomState.isPlaying, syncedPosition, sharedTrack.videoId)
            }
        }
    }

    Scaffold(
        containerColor = socialPalette.pageBackground,
        topBar = {
            if (socialPage == "listen") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.statusBars),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(64.dp)
                            .padding(horizontal = 18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RippleIconButton(
                            imageVector = SimpIcons.ArrowBackIosNew,
                            tint = socialPalette.primaryText,
                            onClick = {
                                if (roomState.roomCode == null) navController.navigateUp() else socialPage = "feed"
                            },
                        )
                        Text(
                            text = if (roomState.roomCode == null) "Listen Together" else "Listening room",
                            modifier = Modifier.padding(start = 10.dp),
                            style = typo().headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = socialPalette.primaryText,
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            NefyMascotMark(palette = socialPalette, modifier = Modifier.size(42.dp))
                            if (roomState.roomCode != null) {
                                RippleIconButton(
                                    imageVector = SimpIcons.MoreVert,
                                    tint = socialPalette.primaryText,
                                    onClick = { showRoomChat = true },
                                )
                            }
                        }
                    }
                }
            } else if (socialPage == "playlists" && selectedSharedPlaylist != null) {
                // The shared playlist page owns its own gradient header and status-bar inset.
                // Keep the Friends scaffold top bar empty so it cannot introduce a second
                // social header above the normal playlist presentation.
            } else {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = socialPalette.pageBackground),
                    title = {
                        Text(
                            text = if (socialPage == "feed") "Friends" else socialPage.replaceFirstChar { it.uppercase() },
                            style = typo().titleMedium,
                            color = socialPalette.primaryText,
                        )
                    },
                    navigationIcon = {
                        RippleIconButton(
                            imageVector = SimpIcons.ArrowBackIosNew,
                            tint = socialPalette.primaryText,
                            onClick = { if (socialPage == "feed") navController.navigateUp() else socialPage = "feed" },
                        )
                    },
                    actions = {
                        TextButton(onClick = { socialPage = "listen" }) { Text("Listen") }
                        TextButton(onClick = { socialPage = "requests" }) {
                            Text(if (incomingRequests.isEmpty()) "Requests" else "Requests ${incomingRequests.size}")
                        }
                        TextButton(onClick = { socialPage = "find" }) { Text("Add") }
                    },
                )
            }
        },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(padding).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            invitations.firstOrNull()?.let { invitation ->
                RoomInvitationBanner(
                    invitation = invitation,
                    pendingCount = invitations.size,
                    onAccept = {
                        roomCode = invitation.roomCode
                        roomController.acceptInvitation(invitation, displayName)
                        socialPage = "listen"
                    },
                    onDecline = { roomController.declineInvitation(invitation.id) },
                    palette = socialPalette,
                )
            }
            roomState.errorMessage?.let { message ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = socialPalette.danger.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, socialPalette.danger.copy(alpha = 0.4f)),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(roomUserFacingError(message), modifier = Modifier.weight(1f), style = typo().bodySmall, color = socialPalette.danger)
                        TextButton(onClick = { roomController.loadSocial() }) {
                            Text("Retry", color = socialPalette.accent)
                        }
                    }
                }
            }
            if (socialPage == "feed" || socialPage == "friends") {
                SocialSegmentedTabs(
                    selected = socialPage,
                    onSelect = { socialPage = it },
                    palette = socialPalette,
                )
            }
            when (socialPage) {
                "feed" -> {
                    Text("Listening activity", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold, color = socialPalette.primaryText)
                    Text("Live updates from your circle, ordered by who is playing, paused, online, and offline.", style = typo().bodySmall, color = socialPalette.secondaryText)

                    ListenTogetherEntryCard(
                        activeRoomCode = roomState.roomCode,
                        onOpen = { socialPage = "listen" },
                    )

                    val presenceById = socialState.presence.associateBy { it.userId }
                    val orderedFriends = socialState.friends.sortedWith(
                        compareByDescending<com.nefy.app.social.listening.NefyFriend> { presenceById[it.userId]?.isPlaying == true }
                            .thenByDescending { presenceById[it.userId]?.track != null }
                            .thenByDescending { presenceById.containsKey(it.userId) }
                            .thenBy { it.displayName.lowercase() },
                    )
                    if (orderedFriends.isEmpty()) {
                        SocialEmptyCard("No friends yet", "Use Add to search by username or friend code, then watch their listening activity here.")
                    } else {
                        orderedFriends.forEach { friend ->
                            val presence = presenceById[friend.userId]
                            LiveFriendCard(
                                displayName = friend.displayName,
                                handle = friend.handle,
                                presence = presence,
                                onProfileClick = { selectedFriend = friend },
                                onTrackClick = { selectedPresence = presence },
                            )
                        }
                    }
                }
                "friends" -> {
                    Text("Your friends", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold, color = socialPalette.primaryText)
                    Text("Open a friend card to see their profile and listening status.", style = typo().bodySmall, color = socialPalette.secondaryText)
                    val presenceById = socialState.presence.associateBy { it.userId }
                    val orderedFriends = socialState.friends.sortedBy { it.displayName.lowercase() }
                    if (orderedFriends.isEmpty()) {
                        SocialEmptyCard("No friends yet", "Use Add to search by username or friend code.")
                    } else {
                        orderedFriends.forEach { friend ->
                            LiveFriendCard(
                                displayName = friend.displayName,
                                handle = friend.handle,
                                presence = presenceById[friend.userId],
                                onProfileClick = { selectedFriend = friend },
                                onTrackClick = { selectedPresence = presenceById[friend.userId] },
                            )
                        }
                    }
                }
                "requests" -> {
                    Text("Friend requests", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold, color = socialPalette.primaryText)
                    val outgoing = socialState.pendingRequests.filter { it.direction == "outgoing" }
                    if (incomingRequests.isEmpty() && outgoing.isEmpty()) SocialEmptyCard("No pending requests", "Requests will appear here when someone connects with you.")
                    incomingRequests.forEach { request ->
                        FriendRequestCard(
                            request = request,
                            onAccept = { roomController.respondFriendRequest(request.id, true) },
                            onDecline = { roomController.respondFriendRequest(request.id, false) },
                        )
                    }
                    if (outgoing.isNotEmpty()) {
                        Text("Sent", style = typo().titleMedium, color = socialPalette.primaryText)
                        outgoing.forEach { request -> FriendRequestCard(request = request, onAccept = null, onDecline = null) }
                    }
                }
                "find" -> {
                    Text("Find friends", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold, color = socialPalette.primaryText)
                    Text("Search a Nefy username, handle, or friend code.", style = typo().bodySmall, color = socialPalette.secondaryText)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            modifier = Modifier.weight(1f),
                            value = searchQuery,
                            onValueChange = { searchQuery = it.take(64) },
                            label = { Text("Username or code") },
                            singleLine = true,
                        )
                        Button(onClick = { roomController.searchProfiles(searchQuery) }, enabled = searchQuery.isNotBlank()) { Text("Search") }
                    }
                    if (socialState.searchResults.isEmpty()) {
                        SocialEmptyCard("Search Nefy profiles", "Results will appear here with an Add button.")
                    } else {
                        socialState.searchResults.forEach { result ->
                            SearchResultCard(
                                displayName = result.displayName,
                                handle = result.handle,
                                friendCode = result.friendCode,
                                relationship = result.relationship,
                                onAdd = {
                                    when (result.relationship) {
                                        "incoming" -> socialPage = "requests"
                                        "none" -> roomController.sendFriendRequest(result.userId)
                                    }
                                },
                            )
                        }
                    }
                }
                "activity" -> ActivityContent(
                    state = socialState,
                    onVisibilityChange = roomController::setActivityVisibility,
                )
                "playlists" -> {
                    if (selectedSharedPlaylist != null) {
                        SharedPlaylistDetailContent(
                            playlist = selectedSharedPlaylist,
                            currentUserId = socialState.profile?.userId.orEmpty(),
                            currentTrack = toListeningTrack(nowPlayingState, sharedViewModel) ?: roomState.currentTrack,
                            isPlaying = roomState.isPlaying,
                            navController = navController,
                            roomController = roomController,
                            onBack = { navController.navigateUp() },
                            onPlayTrack = { track -> sharedViewModel.loadSharedMediaItem(track.videoId) },
                            onCreateInvite = {
                                roomController.createPlaylistInvite(selectedSharedPlaylist.id)
                                val code = roomController.socialState.value.lastInviteCode
                                if (!code.isNullOrBlank()) {
                                    shareUrl(
                                        title = "Join my Nefy playlist",
                                        url = "nefy://playlist/$code\nhttps://museme-room-server.onrender.com/playlist/$code",
                                    )
                                }
                            },
                            palette = socialPalette,
                        )
                    } else {
                        PlaylistsContent(
                            state = socialState,
                            currentTrack = toListeningTrack(nowPlayingState, sharedViewModel) ?: roomState.currentTrack,
                            currentUserId = socialState.profile?.userId.orEmpty(),
                            onCreatePlaylist = { name, description -> roomController.createPlaylist(name, description) },
                            onAddTrack = roomController::addPlaylistTrack,
                            onPlayTrack = { track -> sharedViewModel.loadSharedMediaItem(track.videoId) },
                            onRemoveTrack = roomController::removePlaylistTrack,
                            onCreateInvite = roomController::createPlaylistInvite,
                            onJoinInvite = roomController::joinPlaylistInvite,
                            initialPlaylistId = playlistId,
                            onCopyToLocal = { playlist ->
                                coroutineScope.launch {
                                    copySharedPlaylistToLocal(
                                        playlist = playlist,
                                        localPlaylistRepository = localPlaylistRepository,
                                        songRepository = songRepository,
                                    )
                                }
                            },
                        )
                    }
                }
                "listen" -> {
                    if (roomState.roomCode == null) {
                        EmptyRoomContent(
                            displayName = displayName,
                            roomCode = roomCode,
                            onDisplayNameChange = {
                                displayName = it.take(24)
                                identity.setDisplayName(displayName)
                            },
                            onRoomCodeChange = { roomCode = it.uppercase().take(8) },
                            connection = roomState.connection,
                            errorMessage = roomState.errorMessage,
                            onCreateRoom = { roomController.createRoom(displayName) },
                            onJoinRoom = { roomController.joinRoom(roomCode, displayName) },
                        )
                    } else {
                        ReferenceActiveRoomContent(
                            state = roomState,
                            onPlayingChange = { isPlaying ->
                                val position = timelineState.current.coerceAtLeast(0L)
                                roomController.setPlayback(isPlaying, position)
                                sharedViewModel.applyListeningPlayback(isPlaying, position, roomState.currentTrack?.videoId)
                            },
                            onSeek = { positionMs ->
                                roomController.setPlayback(roomState.isPlaying, positionMs)
                                sharedViewModel.applyListeningPlayback(roomState.isPlaying, positionMs, roomState.currentTrack?.videoId)
                            },
                            onShareTrack = { toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::setTrack) },
                            onEnqueueTrack = { toListeningTrack(nowPlayingState, sharedViewModel)?.let(roomController::enqueueTrack) },
                            onPlayTrack = roomController::setTrack,
                            onSkipNext = roomController::skipNext,
                            onSkipPrevious = roomController::skipPrevious,
                            onFollowHostChange = roomController::setFollowHost,
                            onRemoteControlChange = roomController::setRemoteControl,
                            onAddSong = { showRoomSongPicker = true },
                            onInviteFriends = { showRoomInviteSheet = true },
                            onOpenChat = { showRoomChat = true },
                            onRemoveQueueTrack = roomController::removeQueueTrack,
                            onLeaveRoom = roomController::leaveRoom,
                        )
                    }
                }
            }
        }
    }

    selectedFriend?.let { friend ->
        val friendPresence = socialState.presence.firstOrNull { it.userId == friend.userId }
        FriendProfileSheet(
            friend = friend,
            presence = friendPresence,
            onDismiss = { selectedFriend = null },
            onPlayTrack = {
                friendPresence?.track?.let { track -> sharedViewModel.loadSharedMediaItem(track.videoId) }
                selectedFriend = null
            },
            onAddToPlaylist = {
                friendPresence?.track?.let { selectedPlaylistTrack = it }
                selectedFriend = null
            },
            onListenTogether = { selectedFriend = null; socialPage = "listen" },
            onShareProfile = {
                shareUrl(title = "Connect with ${friend.displayName} on Nefy", url = "nefy://profile/${friend.userId}")
            },
            onRemoveFriend = { roomController.removeFriend(friend.userId); selectedFriend = null },
        )
    }

    selectedPresence?.let { presence ->
        presence.track?.let { track ->
            FriendTrackActionSheet(
                presence = presence,
                onDismiss = { selectedPresence = null },
                onPlay = { sharedViewModel.loadSharedMediaItem(track.videoId); selectedPresence = null },
                onAddToPlaylist = { selectedPlaylistTrack = track; selectedPresence = null },
                onListenTogether = { selectedPresence = null; socialPage = "listen" },
            )
        }
    }

    if (showRoomSongPicker && roomState.roomCode != null) {
        RoomSongPickerSheet(
            onDismiss = { showRoomSongPicker = false },
            onAddTrack = { track ->
                if (roomState.currentTrack == null) roomController.setTrack(track) else roomController.enqueueTrack(track)
            },
        )
    }

    if (showRoomInviteSheet && roomState.roomCode != null) {
        RoomInviteSheet(
            friends = socialState.friends,
            roomCode = roomState.roomCode.orEmpty(),
            onInviteFriend = roomController::inviteFriend,
            onDismiss = { showRoomInviteSheet = false },
        )
    }

    if (showRoomChat && roomState.roomCode != null) {
        RoomChatSheet(
            state = roomState,
            onSendChat = roomController::sendChat,
            onSendReaction = roomController::sendReaction,
            onDismiss = { showRoomChat = false },
        )
    }

    pendingPlaylistInvite?.let { inviteCode ->
        ModalBottomSheet(onDismissRequest = { pendingPlaylistInvite = null }) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("Join shared playlist?", style = typo().headlineSmall, color = socialPalette.primaryText)
                Text(
                    "Accepting this invite will add the playlist to your Shared Playlists library. You can then listen, add songs, and collaborate.",
                    style = typo().bodyMedium,
                    color = socialPalette.secondaryText,
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        modifier = Modifier.weight(1f),
                        onClick = { pendingPlaylistInvite = null },
                    ) { Text("Cancel") }
                    Button(
                        modifier = Modifier.weight(1f),
                        onClick = {
                            roomController.joinPlaylistInvite(inviteCode)
                            roomController.loadSocial()
                            pendingPlaylistInvite = null
                            socialPage = "playlists"
                        },
                    ) { Text("Accept") }
                }
            }
        }
    }

    selectedPlaylistTrack?.let { track ->
        ModalBottomSheet(onDismissRequest = { selectedPlaylistTrack = null }) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Add to a shared Nefy playlist", style = typo().headlineSmall)
                if (socialState.playlists.isEmpty()) {
                    Text("Share a Library playlist first, then add this song to it.", style = typo().bodyMedium)
                } else {
                    socialState.playlists.forEach { playlist ->
                        TextButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                roomController.addPlaylistTrack(playlist.id, track)
                                selectedPlaylistTrack = null
                            },
                        ) { Text(playlist.name, modifier = Modifier.fillMaxWidth()) }
                    }
                }
                TextButton(onClick = { selectedPlaylistTrack = null }) { Text("Cancel") }
            }
        }
    }
}

@Composable
private fun RoomInvitationBanner(
    invitation: RoomInvitation,
    pendingCount: Int,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    palette: com.nefy.app.ui.theme.NefySocialPalette,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = palette.cardElevated),
        border = BorderStroke(1.dp, palette.accent.copy(alpha = 0.45f)),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Listening room invitation", style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
            Text("${invitation.inviterDisplayName} invited you to room ${invitation.roomCode}.", style = typo().bodyMedium, color = palette.secondaryText)
            if (pendingCount > 1) Text("$pendingCount invitations waiting", style = typo().labelSmall, color = palette.accent)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onDecline, modifier = Modifier.weight(1f)) { Text("Decline", color = palette.secondaryText) }
                Button(onClick = onAccept, modifier = Modifier.weight(1f)) { Text("Accept") }
            }
        }
    }
}

@Composable
private fun SocialSegmentedTabs(
    selected: String,
    onSelect: (String) -> Unit,
    palette: com.nefy.app.ui.theme.NefySocialPalette,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = palette.card,
        tonalElevation = 1.dp,
    ) {
        Row(modifier = Modifier.padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("feed" to "Activity", "friends" to "Friends").forEach { (key, label) ->
                Surface(
                    modifier = Modifier.weight(1f).clickable { onSelect(key) },
                    shape = RoundedCornerShape(20.dp),
                    color = if (selected == key) palette.accentContainer else palette.card,
                ) {
                    Text(
                        text = label,
                        modifier = Modifier.padding(vertical = 10.dp),
                        textAlign = TextAlign.Center,
                        style = typo().labelLarge,
                        color = if (selected == key) palette.accent else palette.primaryText,
                    )
                }
            }
        }
    }
}

@Composable
private fun NefyMascotMark(
    palette: com.nefy.app.ui.theme.NefySocialPalette,
    modifier: Modifier = Modifier.size(56.dp),
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = palette.cardElevated,
    ) {
        Image(
            painter = painterResource(Res.drawable.nefy_icon),
            contentDescription = "Nefy logo",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().padding(4.dp).clip(RoundedCornerShape(14.dp)),
        )
    }
}

@Composable
private fun ListenTogetherEntryCard(
    activeRoomCode: String?,
    onOpen: () -> Unit,
) {
    val palette = nefySocialPalette()
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        shape = RoundedCornerShape(26.dp),
        color = palette.cardElevated,
        border = BorderStroke(1.dp, palette.outline),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            NefyMascotMark(palette = palette, modifier = Modifier.size(60.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Listen Together", style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
                Text(
                    if (activeRoomCode == null) "Share the moment with friends, in sync."
                    else "Room $activeRoomCode is ready — return to your shared queue.",
                    style = typo().bodySmall,
                    color = palette.secondaryText,
                )
            }
            Text("Open", style = typo().labelLarge, color = palette.accent)
        }
    }
}

@Composable
private fun SharedPlaylistSummary(
    playlistCount: Int,
    onOpen: () -> Unit,
) {
    val palette = nefySocialPalette()
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = palette.card),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Surface(
                modifier = Modifier.size(44.dp),
                shape = RoundedCornerShape(14.dp),
                color = palette.accentContainer,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = SimpIcons.Share,
                        contentDescription = null,
                        tint = palette.primaryText,
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Shared playlists", style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
                Text("$playlistCount collaborative ${if (playlistCount == 1) "playlist" else "playlists"} in your circle", style = typo().bodySmall, color = palette.secondaryText)
            }
            Text("Open", style = typo().labelLarge, color = palette.accent)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FriendProfileSheet(
    friend: com.nefy.app.social.listening.NefyFriend,
    presence: NefyPresence?,
    onDismiss: () -> Unit,
    onPlayTrack: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onListenTogether: () -> Unit,
    onShareProfile: () -> Unit,
    onRemoveFriend: () -> Unit,
) {
    val palette = nefySocialPalette()
    val status = when {
        presence?.isPlaying == true -> "Playing now"
        presence?.track != null -> "Paused"
        presence != null -> "Online"
        else -> "Offline"
    }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = palette.card) {
        Column(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            BoxAvatar(label = friend.displayName.take(1).uppercase())
            Text(friend.displayName, style = typo().headlineSmall, fontWeight = FontWeight.Bold, color = palette.primaryText)
            friend.handle?.let { Text("@$it", style = typo().bodyMedium, color = palette.secondaryText) }
            Text(status, style = typo().labelLarge, color = palette.accent)
            presence?.track?.let { track ->
                Text("${track.title} · ${track.artist}", style = typo().bodyMedium, textAlign = TextAlign.Center)
            }
            if (presence?.track != null) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = onPlayTrack, modifier = Modifier.weight(1f)) { Text("Play") }
                    FilledTonalButton(onClick = onAddToPlaylist, modifier = Modifier.weight(1f)) { Text("Add to playlist") }
                }
            }
            FilledTonalButton(onClick = onListenTogether, modifier = Modifier.fillMaxWidth()) { Text("Listen Together") }
            TextButton(onClick = onShareProfile) { Text("Share profile", color = palette.accent) }
            TextButton(onClick = onRemoveFriend) { Text("Remove friend", color = palette.danger) }
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    }
}

@Composable
private fun LiveFriendCard(
    displayName: String,
    handle: String?,
    presence: NefyPresence?,
    onProfileClick: () -> Unit,
    onTrackClick: () -> Unit,
) {
    val palette = nefySocialPalette()
    val track = presence?.track
    val status = when {
        presence?.isPlaying == true -> "PLAYING"
        track != null -> "PAUSED"
        presence != null -> "ONLINE"
        else -> "OFFLINE"
    }
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onProfileClick),
        colors = CardDefaults.cardColors(
            containerColor = when {
                presence?.isPlaying == true -> palette.hero
                track != null -> palette.cardElevated
                else -> palette.card
            },
        ),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            BoxAvatar(label = displayName.take(1).uppercase())
            if (track != null) {
                AsyncImage(
                    model = track.artworkUrl,
                    contentDescription = track.title,
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)),
                )
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(displayName, style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
                Text(handle?.let { "@$it" } ?: status.lowercase(), style = typo().labelMedium, color = palette.secondaryText)
                if (track != null) {
                    TextButton(onClick = onTrackClick, contentPadding = PaddingValues(0.dp)) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(track.title, style = typo().bodyMedium, maxLines = 1)
                            Text(track.artist, style = typo().bodySmall, maxLines = 1, color = palette.secondaryText)
                        }
                    }
                } else {
                    Text(
                        if (presence == null) "Last seen unavailable" else "Last updated ${presence.updatedAt?.replace("T", " ")?.take(16) ?: "recently"}",
                        style = typo().bodySmall,
                        color = palette.secondaryText,
                    )
                }
            }
            Text(status, style = typo().labelSmall, color = if (presence?.isPlaying == true) palette.accent else palette.secondaryText)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FriendTrackActionSheet(
    presence: NefyPresence,
    onDismiss: () -> Unit,
    onPlay: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onListenTogether: () -> Unit,
) {
    val track = presence.track ?: return
    val palette = nefySocialPalette()
    var showMore by rememberSaveable { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = palette.card) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("${presence.displayName} is ${if (presence.isPlaying) "playing" else "paused on"}", style = typo().titleLarge, fontWeight = FontWeight.Bold, color = palette.primaryText)
            Card(colors = CardDefaults.cardColors(containerColor = palette.cardElevated), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AsyncImage(
                        model = track.artworkUrl,
                        contentDescription = track.title,
                        modifier = Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)),
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(track.title, style = typo().titleMedium, color = palette.primaryText)
                        Text(track.artist, style = typo().bodySmall, color = palette.secondaryText)
                        Text(if (presence.isPlaying) "Listening now" else "Paused", style = typo().labelSmall, color = palette.accent)
                    }
                }
            }
            Button(onClick = onPlay, modifier = Modifier.fillMaxWidth()) { Text("Play") }
            FilledTonalButton(onClick = onAddToPlaylist, modifier = Modifier.fillMaxWidth()) { Text("Add to playlist") }
            FilledTonalButton(onClick = onListenTogether, modifier = Modifier.fillMaxWidth()) { Text("Listen Together") }
            TextButton(onClick = { showMore = !showMore }, modifier = Modifier.fillMaxWidth()) { Text("More") }
            if (showMore) {
                Text("Use Play to start this song locally, or open Listen Together to add it to a shared room.", style = typo().bodySmall, color = palette.secondaryText)
            }
            TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Close") }
        }
    }
}

@Composable
private fun FriendRequestCard(
    request: NefyFriendRequest,
    onAccept: (() -> Unit)?,
    onDecline: (() -> Unit)?,
) {
    val palette = nefySocialPalette()
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = palette.card)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BoxAvatar(label = request.displayName.take(1).uppercase())
            Column(modifier = Modifier.weight(1f)) {
                Text(request.displayName, style = typo().titleMedium, color = palette.primaryText)
                Text(request.handle?.let { "@$it" } ?: "Friend code · ${request.friendCode.orEmpty()}", style = typo().bodySmall, color = palette.secondaryText)
                Text(if (request.direction == "incoming") "Wants to connect" else "Request sent", style = typo().labelSmall)
            }
            if (onAccept != null && onDecline != null) {
                Column {
                    Button(onClick = onAccept, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Accept") }
                    TextButton(onClick = onDecline, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Decline") }
                }
            }
        }
    }
}

@Composable
private fun SearchResultCard(
    displayName: String,
    handle: String?,
    friendCode: String?,
    relationship: String,
    onAdd: () -> Unit,
) {
    val palette = nefySocialPalette()
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = palette.card)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            BoxAvatar(label = displayName.take(1).uppercase())
            Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                Text(displayName, style = typo().titleMedium, color = palette.primaryText)
                Text(handle?.let { "@$it" } ?: "Friend code · ${friendCode.orEmpty()}", style = typo().bodySmall, color = palette.secondaryText)
            }
            FilledTonalButton(
                onClick = onAdd,
                enabled = relationship == "none" || relationship == "incoming",
            ) {
                Text(
                    when (relationship) {
                        "friends" -> "Friends"
                        "requested" -> "Requested"
                        "incoming" -> "Check requests"
                        else -> "Add"
                    },
                )
            }
        }
    }
}

@Composable
private fun SocialEmptyCard(title: String, subtitle: String) {
    val palette = nefySocialPalette()
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = palette.card)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
            Text(subtitle, style = typo().bodyMedium, color = palette.secondaryText)
        }
    }
}

private fun toListeningTrack(
    current: NowPlayingTrackState?,
    sharedViewModel: SharedViewModel,
): ListeningTrack? {
    val song = current?.songEntity ?: return null
    if (song.videoId.isBlank()) return null
    return ListeningTrack(
        videoId = song.videoId,
        title = song.title,
        artist = song.artistName?.joinToString(", ").orEmpty().ifBlank { "Unknown artist" },
        artworkUrl = current.mediaItem.metadata.artworkUri ?: song.thumbnails,
        durationMs = sharedViewModel.timeline.value.total.takeIf { it > 0L }
            ?: song.durationSeconds.toLong() * 1000L,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlaylistsContent(
    state: NefySocialState,
    currentTrack: ListeningTrack?,
    currentUserId: String = "",
    onCreatePlaylist: (String, String) -> Unit,
    onAddTrack: (String, ListeningTrack) -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onRemoveTrack: (String, String) -> Unit,
    onCreateInvite: (String) -> Unit,
    onJoinInvite: (String) -> Unit,
    initialPlaylistId: String? = null,
    onCopyToLocal: (NefySavedPlaylist) -> Unit = {},
) {
    var playlistName by rememberSaveable { mutableStateOf("") }
    var playlistDescription by rememberSaveable { mutableStateOf("") }
    var inviteCode by rememberSaveable { mutableStateOf("") }
    var expandedPlaylistId by rememberSaveable { mutableStateOf(initialPlaylistId) }

    Text("Saved playlists", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
    Text(
        "Create a playlist in your Library, then share a link with collaborators using their connected YouTube account.",
        style = typo().bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Create a playlist", style = typo().titleMedium)
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = playlistName,
                onValueChange = { playlistName = it.take(96) },
                label = { Text("Playlist name") },
                singleLine = true,
            )
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = playlistDescription,
                onValueChange = { playlistDescription = it.take(240) },
                label = { Text("Description (optional)") },
                singleLine = true,
            )
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = playlistName.trim().isNotBlank(),
                onClick = {
                    onCreatePlaylist(playlistName.trim(), playlistDescription.trim())
                    playlistName = ""
                    playlistDescription = ""
                },
            ) {
                Text("Create playlist")
            }
        }
    }

    if (state.playlists.isEmpty()) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                "No saved playlists yet. Create one above, then add the song currently playing.",
                modifier = Modifier.padding(16.dp),
                style = typo().bodyMedium,
            )
        }
    }

    state.playlists.forEach { playlist ->
        PlaylistCard(
            playlist = playlist,
            expanded = expandedPlaylistId == playlist.id,
            currentTrack = currentTrack,
            inviteCode = if (state.lastInvitePlaylistId == playlist.id) state.lastInviteCode else null,
            currentUserId = currentUserId,
            onExpand = { expandedPlaylistId = if (expandedPlaylistId == playlist.id) null else playlist.id },
            onAddTrack = { track -> onAddTrack(playlist.id, track) },
            onPlayTrack = onPlayTrack,
            onRemoveTrack = { videoId -> onRemoveTrack(playlist.id, videoId) },
            onCreateInvite = { onCreateInvite(playlist.id) },
            onCopyToLocal = { onCopyToLocal(playlist) },
        )
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Join a shared playlist", style = typo().titleMedium)
            Text(
                "Paste a collaboration link or invite code while signed in with your YouTube account.",
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = inviteCode,
                onValueChange = { inviteCode = it.uppercase().take(16) },
                label = { Text("Invite code") },
                singleLine = true,
            )
            FilledTonalButton(
                modifier = Modifier.fillMaxWidth(),
                enabled = inviteCode.trim().isNotBlank(),
                onClick = {
                    onJoinInvite(inviteCode)
                    inviteCode = ""
                },
            ) {
                Text("Join playlist")
            }
        }
    }
}

@Composable
private fun PlaylistCard(
    playlist: NefySavedPlaylist,
    expanded: Boolean,
    currentTrack: ListeningTrack?,
    inviteCode: String?,
    currentUserId: String,
    onExpand: () -> Unit,
    onAddTrack: (ListeningTrack) -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onRemoveTrack: (String) -> Unit,
    onCreateInvite: () -> Unit,
    onCopyToLocal: () -> Unit = {},
) {
    val palette = nefySocialPalette()
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = palette.card)) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Surface(
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)),
                    color = MaterialTheme.colorScheme.primaryContainer,
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            playlist.name.take(2).uppercase(),
                            style = typo().titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = palette.primaryText,
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(playlist.name, style = typo().titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        playlist.description.ifBlank { "Collaborative playlist" },
                        style = typo().bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        "${playlist.tracks.size} songs · ${if (playlist.collaborationEnabled) "Collaborative" else "Private"}",
                        style = typo().labelSmall,
                        color = palette.accent,
                    )
                    if (playlist.collaborationEnabled) {
                        Text("${playlist.contributors.size.coerceAtLeast(1)} collaborator${if (playlist.contributors.size == 1) "" else "s"}", style = typo().labelSmall, color = palette.secondaryText)
                    }
                }
                if (playlist.collaborationEnabled) {
                    Row(horizontalArrangement = Arrangement.spacedBy((-8).dp)) {
                        playlist.contributors.take(3).forEach { contributor ->
                            PlaylistContributorAvatar(contributor.displayName, contributor.avatarUrl, palette)
                        }
                    }
                }
                TextButton(onClick = onExpand) {
                    Text(if (expanded) "Hide" else "Open")
                }
            }
            if (expanded) {
                if (playlist.tracks.isEmpty()) {
                    Text("This playlist is empty.", style = typo().bodySmall)
                } else {
                    playlist.tracks.forEach { track ->
                        val playableTrack = ListeningTrack(
                            videoId = track.videoId,
                            title = track.title,
                            artist = track.artist,
                            artworkUrl = track.artworkUrl,
                            durationMs = track.durationMs,
                        )
                        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (track.artworkUrl.isNullOrBlank()) {
                                    Surface(modifier = Modifier.size(48.dp), shape = RoundedCornerShape(10.dp), color = palette.accentContainer) {
                                        Icon(SimpIcons.QueueMusic, contentDescription = null, tint = palette.accent, modifier = Modifier.padding(12.dp))
                                    }
                                } else {
                                    AsyncImage(model = track.artworkUrl, contentDescription = track.title, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)))
                                }
                                TextButton(modifier = Modifier.weight(1f), onClick = { onPlayTrack(playableTrack) }) {
                                    Column(modifier = Modifier.fillMaxWidth()) {
                                        Text(track.title, style = typo().bodyMedium, maxLines = 1)
                                        Text(track.artist, style = typo().bodySmall, color = palette.secondaryText, maxLines = 1)
                                        track.addedByDisplayName?.let { name ->
                                            Text("Added by $name", style = typo().labelSmall, color = palette.secondaryText)
                                        }
                                    }
                                }
                            }
                            if (track.addedBy == currentUserId || playlist.ownerId == currentUserId) {
                                TextButton(onClick = { onRemoveTrack(track.videoId) }, contentPadding = PaddingValues(horizontal = 4.dp)) {
                                    Text("Remove", color = palette.danger)
                                }
                            }
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(
                        modifier = Modifier.weight(1f),
                        enabled = currentTrack != null,
                        onClick = { currentTrack?.let(onAddTrack) },
                    ) {
                        Text("Add current song")
                    }
                    OutlinedButton(modifier = Modifier.weight(1f), onClick = onCopyToLocal) {
                        Text("Add to local")
                    }
                    if (playlist.ownerId == currentUserId) {
                        OutlinedButton(modifier = Modifier.weight(1f), onClick = onCreateInvite) {
                            Icon(imageVector = SimpIcons.Share, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share")
                        }
                    }
                }
                inviteCode?.let { code ->
                    Text("Collaboration link ready", style = typo().labelLarge, color = palette.accent)
                    TextButton(
                        onClick = {
                            shareUrl(
                                title = "Join my Nefy collaborative playlist",
                                url = "nefy://playlist/$code\nhttps://museme-room-server.onrender.com/playlist/$code",
                            )
                        },
                    ) {
                        Text("Share invite link", color = palette.accent)
                    }
                }
                Text(
                    if (playlist.ownerId == currentUserId) "Share this playlist with YouTube-account collaborators."
                    else "You can add tracks to this shared playlist.",
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

private suspend fun copySharedPlaylistToLocal(
    playlist: NefySavedPlaylist,
    localPlaylistRepository: LocalPlaylistRepository,
    songRepository: SongRepository,
) {
    playlist.tracks.forEach { track ->
        songRepository.insertSong(
            SongEntity(
                videoId = track.videoId,
                duration = "0:00",
                durationSeconds = (track.durationMs / 1000L).toInt().coerceAtLeast(0),
                isAvailable = true,
                isExplicit = false,
                likeStatus = "0",
                thumbnails = track.artworkUrl,
                title = track.title,
                videoType = "Song",
                category = "Music",
                resultType = "Song",
                artistName = listOf(track.artist),
            ),
        ).collect { }
    }
    localPlaylistRepository.insertLocalPlaylist(
        LocalPlaylistEntity(
            title = playlist.name,
            thumbnail = playlist.coverArtUrl ?: playlist.tracks.firstOrNull()?.artworkUrl,
            tracks = playlist.tracks.map { it.videoId }.distinct(),
        ),
        "Added local playlist",
    ).collect { }
}

@Composable
private fun ActivityContent(
    state: NefySocialState,
    onVisibilityChange: (Boolean) -> Unit,
) {
    Text("Friend activity", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
    Text(
        "See who is listening now, whether they are playing or paused, and what your shared circle changed recently.",
        style = typo().bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    Text("Listening now", style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
    val currentUserId = state.profile?.userId
    val liveFriends = state.presence.filter { it.userId != currentUserId && it.track != null }
    if (liveFriends.isEmpty()) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                if (state.friends.isEmpty()) {
                    "Invite someone to a shared playlist or listening room to see their live status here."
                } else {
                    "No friends are listening right now. Their current song will appear here as soon as they start or pause playback."
                },
                modifier = Modifier.padding(16.dp),
                style = typo().bodyMedium,
            )
        }
    } else {
        liveFriends.forEach { presence ->
            LivePresenceCard(presence)
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Activity visibility", style = typo().titleMedium)
                Text(
                    if (state.activityVisibleToFriends) "Friends and shared-playlist collaborators can see your live status" else "Your listening activity is hidden",
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = state.activityVisibleToFriends,
                onCheckedChange = onVisibilityChange,
            )
        }
    }

    Text("Recent activity", style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
    if (state.activities.isEmpty()) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                "Playlist edits and room listening events will appear here.",
                modifier = Modifier.padding(16.dp),
                style = typo().bodyMedium,
            )
        }
    } else {
        state.activities.take(30).forEach { activity ->
            ActivityCard(activity)
        }
    }
}

@Composable
private fun LivePresenceCard(presence: NefyPresence) {
    val track = presence.track ?: return
    val palette = nefySocialPalette()
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (presence.isPlaying) {
                palette.hero
            } else {
                palette.cardElevated
            },
        ),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            BoxAvatar(label = presence.displayName.firstOrNull()?.uppercase() ?: "?")
            Column(modifier = Modifier.weight(1f)) {
                Text(presence.displayName, style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
                Text(
                    if (presence.isPlaying) "Listening now" else "Paused",
                    style = typo().labelMedium,
                    color = if (presence.isPlaying) palette.accent else palette.secondaryText,
                )
                Text(track.title, style = typo().bodyMedium, maxLines = 1, color = palette.primaryText)
                Text(track.artist, style = typo().bodySmall, maxLines = 1, color = palette.secondaryText)
            }
            Text(
                if (presence.isPlaying) "PLAYING" else "PAUSED",
                style = typo().labelSmall,
                color = if (presence.isPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ActivityCard(activity: NefyActivityItem) {
    val palette = nefySocialPalette()
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = palette.card)) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(activity.actorName, style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
            Text(activityDescription(activity), style = typo().bodyMedium, color = palette.primaryText)
            activity.track?.let { track ->
                Text(
                    "${track.title} · ${track.artist}",
                    style = typo().bodySmall,
                    color = palette.accent,
                )
            }
            Text(
                activity.createdAt.replace("T", " ").take(19),
                style = typo().labelSmall,
                color = palette.secondaryText,
            )
        }
    }
}

private fun activityDescription(activity: NefyActivityItem): String = when (activity.eventType) {
    "playlist_created" -> "created a playlist"
    "track_added" -> "added a song to a playlist"
    "playlist_shared" -> "shared a playlist"
    "now_listening" -> "is listening now"
    else -> activity.eventType.replace('_', ' ')
}

@Composable
private fun ListenTogetherHeroCard() {
    val palette = nefySocialPalette()
    Surface(
        modifier = Modifier.fillMaxWidth().height(230.dp),
        shape = RoundedCornerShape(28.dp),
        color = palette.cardElevated,
        border = BorderStroke(1.dp, palette.outline),
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Listen together", style = typo().headlineMedium, fontWeight = FontWeight.Bold, color = palette.primaryText)
                Text("Share the moment with friends, in sync.", style = typo().bodyLarge, color = palette.secondaryText)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(modifier = Modifier.size(54.dp), shape = CircleShape, color = palette.accentContainer) {
                        Icon(SimpIcons.PeopleAlt, contentDescription = "Listener one", tint = palette.accent, modifier = Modifier.padding(12.dp))
                    }
                    Surface(modifier = Modifier.size(54.dp), shape = CircleShape, color = Color(0xFF332452)) {
                        Icon(SimpIcons.PeopleAlt, contentDescription = "Listener two", tint = Color(0xFFB9A2F4), modifier = Modifier.padding(12.dp))
                    }
                }
                NefyMascotMark(palette = palette, modifier = Modifier.size(96.dp))
            }
        }
    }
}

@Composable
private fun EmptyRoomContent(
    displayName: String,
    roomCode: String,
    connection: ListeningRoomConnection,
    errorMessage: String?,
    onDisplayNameChange: (String) -> Unit,
    onRoomCodeChange: (String) -> Unit,
    onCreateRoom: () -> Unit,
    onJoinRoom: () -> Unit,
) {
    val palette = nefySocialPalette()
    val isCreatingRoom = connection == ListeningRoomConnection.Connecting
    val canCreateRoom = displayName.trim().isNotBlank() && !isCreatingRoom
    val canJoinRoom = roomCode.isNotBlank() && displayName.trim().isNotBlank() && !isCreatingRoom
    val roomButtonContent = Color(0xFF07111B)

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ListenTogetherHeroCard()
        Text("Start a room", style = typo().headlineMedium, fontWeight = FontWeight.Bold, color = palette.primaryText)
        Text("Display name", style = typo().titleMedium, color = palette.secondaryText)
        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = displayName,
            onValueChange = onDisplayNameChange,
            placeholder = { Text("Your display name") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
        )
        Button(
            modifier = Modifier.fillMaxWidth().height(58.dp),
            enabled = canCreateRoom,
            onClick = onCreateRoom,
            colors = ButtonDefaults.buttonColors(
                containerColor = palette.accent,
                contentColor = roomButtonContent,
                disabledContainerColor = palette.accent.copy(alpha = 0.58f),
                disabledContentColor = roomButtonContent,
            ),
            shape = RoundedCornerShape(18.dp),
        ) {
            Icon(imageVector = SimpIcons.PeopleAlt, contentDescription = null)
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = if (isCreatingRoom) "Creating room…" else "Create a listening room",
                fontWeight = FontWeight.SemiBold,
            )
        }
        Text("✦  You can invite friends after creating the room.", style = typo().bodySmall, color = palette.secondaryText)
        if (connection == ListeningRoomConnection.Reconnecting) {
            Text("Connecting to the room server…", style = typo().bodySmall, color = palette.secondaryText)
        }
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            color = Color.Transparent,
            border = BorderStroke(1.dp, palette.outline),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Join a room", style = typo().headlineSmall, fontWeight = FontWeight.Bold, color = palette.primaryText)
                Text("Have a room code from a friend?", style = typo().bodyMedium, color = palette.secondaryText)
                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = roomCode,
                    onValueChange = onRoomCodeChange,
                    placeholder = { Text("Enter room code") },
                    leadingIcon = { Icon(SimpIcons.PeopleAlt, contentDescription = null, tint = palette.secondaryText) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                )
                OutlinedButton(
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    enabled = canJoinRoom,
                    onClick = onJoinRoom,
                    border = BorderStroke(1.dp, palette.accent),
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Text(stringResource(Res.string.join_room), color = palette.accent, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = palette.card,
        ) {
            Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(SimpIcons.PeopleAlt, contentDescription = null, tint = palette.accent, modifier = Modifier.size(24.dp))
                Text("Your display name is visible to people in the room.", style = typo().bodySmall, color = palette.secondaryText)
            }
        }
        errorMessage?.let { message ->
            Text(roomUserFacingError(message), style = typo().bodySmall, color = palette.danger)
        }
        Spacer(modifier = Modifier.height(170.dp))
    }
}

@Composable
private fun ReferenceActiveRoomContent(
    state: ListeningRoomState,
    onPlayingChange: (Boolean) -> Unit,
    onSeek: (Long) -> Unit,
    onShareTrack: () -> Unit,
    onEnqueueTrack: () -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onFollowHostChange: (Boolean) -> Unit,
    onRemoteControlChange: (Boolean) -> Unit,
    onAddSong: () -> Unit,
    onInviteFriends: () -> Unit,
    onOpenChat: () -> Unit,
    onRemoveQueueTrack: (String) -> Unit,
    onLeaveRoom: () -> Unit,
) {
    val palette = nefySocialPalette()
    val track = state.currentTrack
    val isHost = state.hostId == state.currentUserId
    val canControl = isHost || state.remoteControlEnabled
    var roomClockMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(state.isPlaying, state.positionUpdatedAtMs, track?.videoId) {
        while (state.isPlaying) {
            roomClockMs = System.currentTimeMillis()
            delay(500L)
        }
    }
    val currentPosition = state.estimatedPositionMs(roomClockMs)
    val duration = track?.durationMs?.takeIf { it > 0L }
    var isSeeking by remember { mutableStateOf(false) }
    var pendingSeekMs by remember(track?.videoId) { mutableStateOf(currentPosition) }
    LaunchedEffect(currentPosition, track?.videoId, isSeeking) {
        if (!isSeeking) pendingSeekMs = currentPosition
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                NefyMascotMark(palette = palette, modifier = Modifier.size(58.dp))
                Column {
                    Text(state.roomCode.orEmpty(), style = typo().headlineSmall, fontWeight = FontWeight.Bold, color = palette.primaryText)
                    Text("Connected · ${state.members.size} listeners", style = typo().bodyMedium, color = palette.secondaryText)
                }
            }
            Text("LIVE", style = typo().titleMedium, color = palette.accent, fontWeight = FontWeight.Bold)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = onInviteFriends,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.primaryText),
                border = BorderStroke(1.dp, palette.outline),
                shape = RoundedCornerShape(14.dp),
            ) {
                Icon(SimpIcons.PeopleAlt, contentDescription = null, tint = palette.accent, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(5.dp))
                Text("Invite", color = palette.primaryText)
            }
            OutlinedButton(
                onClick = {
                    shareUrl(title = "Join my Nefy listening room", url = "nefy://room/${state.roomCode}")
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.primaryText),
                border = BorderStroke(1.dp, palette.outline),
                shape = RoundedCornerShape(14.dp),
            ) {
                Icon(SimpIcons.Share, contentDescription = null, tint = palette.accent, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(5.dp))
                Text("Share", color = palette.primaryText)
            }
            OutlinedButton(
                onClick = onOpenChat,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.primaryText),
                border = BorderStroke(1.dp, palette.outline),
                shape = RoundedCornerShape(14.dp),
            ) {
                Text("Chat${if (state.chatMessages.isEmpty()) "" else " ${state.chatMessages.size}"}", color = palette.primaryText)
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = palette.card,
            border = BorderStroke(1.dp, palette.outline),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Currently listening", style = typo().titleMedium, color = palette.secondaryText)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(modifier = Modifier.size(126.dp).clip(RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                        if (track?.artworkUrl.isNullOrBlank()) {
                            Surface(modifier = Modifier.fillMaxSize(), color = palette.accentContainer) {
                                Icon(SimpIcons.QueueMusic, contentDescription = null, tint = palette.accent, modifier = Modifier.padding(36.dp))
                            }
                        } else {
                            AsyncImage(model = track.artworkUrl, contentDescription = track.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        }
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(track?.title ?: "Waiting for a song", style = typo().titleLarge, fontWeight = FontWeight.SemiBold, color = palette.primaryText, maxLines = 2)
                        Text(track?.artist ?: "Add a song from Nefy Search or Library", style = typo().bodyMedium, color = palette.secondaryText, maxLines = 2)
                        Text(if (state.isPlaying) "Shared listening" else "Paused", style = typo().bodySmall, color = palette.accent)
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    RippleIconButton(imageVector = SimpIcons.SkipPrevious, tint = palette.primaryText, enabled = canControl, onClick = onSkipPrevious)
                    Surface(shape = CircleShape, color = palette.accent) {
                        RippleIconButton(imageVector = if (state.isPlaying) SimpIcons.Pause else SimpIcons.PlayArrow, tint = palette.pageBackground, enabled = canControl, onClick = { onPlayingChange(!state.isPlaying) })
                    }
                    RippleIconButton(imageVector = SimpIcons.SkipNext, tint = palette.primaryText, enabled = canControl, onClick = onSkipNext)
                }
                duration?.let { totalDuration ->
                    Slider(
                        value = pendingSeekMs.coerceIn(0L, totalDuration).toFloat(),
                        onValueChange = { value -> isSeeking = true; pendingSeekMs = value.toLong() },
                        onValueChangeFinished = { isSeeking = false; if (canControl) onSeek(pendingSeekMs.coerceIn(0L, totalDuration)) },
                        valueRange = 0f..totalDuration.toFloat(),
                        enabled = canControl,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text(formatRoomTime(pendingSeekMs), style = typo().labelSmall, color = palette.secondaryText)
                        Spacer(modifier = Modifier.weight(1f))
                        Text(formatRoomTime(totalDuration), style = typo().labelSmall, color = palette.secondaryText)
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onAddSong,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.accent,
                            contentColor = Color(0xFF07111B),
                            disabledContainerColor = palette.accent.copy(alpha = 0.58f),
                            disabledContentColor = Color(0xFF07111B),
                        ),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Icon(SimpIcons.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "Add song",
                            style = typo().labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF07111B),
                        )
                    }
                    OutlinedButton(
                        onClick = onOpenChat,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.primaryText),
                        border = BorderStroke(1.dp, palette.outline),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text("Chat", color = palette.primaryText)
                    }
                }
            }
        }

        Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), color = palette.card, border = BorderStroke(1.dp, palette.outline)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Shared queue", style = typo().titleMedium, color = palette.primaryText)
                if (state.queue.isEmpty()) {
                    Text("Queue is empty — add a song from Nefy Search or Library.", style = typo().bodySmall, color = palette.secondaryText)
                } else {
                    state.queue.forEachIndexed { index, queuedTrack ->
                        Row(modifier = Modifier.fillMaxWidth().clickable(enabled = canControl) { onPlayTrack(queuedTrack) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Surface(modifier = Modifier.size(48.dp), shape = RoundedCornerShape(12.dp), color = palette.accentContainer) {
                                Icon(SimpIcons.QueueMusic, contentDescription = null, tint = palette.accent, modifier = Modifier.padding(12.dp))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(if (index == state.queueIndex) "Now playing · ${queuedTrack.title}" else queuedTrack.title, style = typo().bodyMedium, color = palette.primaryText, maxLines = 1)
                                Text(queuedTrack.artist, style = typo().bodySmall, color = palette.secondaryText, maxLines = 1)
                            }
                            if (canControl && index != state.queueIndex) {
                                RippleIconButton(imageVector = SimpIcons.MoreVert, tint = palette.secondaryText, onClick = { onRemoveQueueTrack(queuedTrack.videoId) })
                            }
                        }
                    }
                }
            }
        }

        Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), color = palette.card, border = BorderStroke(1.dp, palette.outline)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Members", style = typo().titleMedium, color = palette.primaryText)
                state.members.forEach { member ->
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        BoxAvatar(label = member.displayName.firstOrNull()?.uppercase() ?: "?")
                        Column(modifier = Modifier.weight(1f)) {
                            Text(member.displayName, style = typo().titleMedium, color = palette.primaryText)
                            Text(if (member.isHost) "Host" else "Listener", style = typo().bodySmall, color = if (member.isHost) palette.accent else palette.secondaryText)
                        }
                        Icon(SimpIcons.MoreVert, contentDescription = null, tint = palette.secondaryText)
                    }
                }
            }
        }

        Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = palette.card) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Follow host", style = typo().titleMedium, color = palette.primaryText)
                    Text("Stay synced with the room playback.", style = typo().bodySmall, color = palette.secondaryText)
                }
                Switch(checked = state.followHost, onCheckedChange = onFollowHostChange)
            }
        }
        if (isHost) {
            Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = palette.card) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Remote control", style = typo().titleMedium, color = palette.primaryText)
                        Text("Let everyone play, pause, and choose songs.", style = typo().bodySmall, color = palette.secondaryText)
                    }
                    Switch(checked = state.remoteControlEnabled, onCheckedChange = onRemoteControlChange)
                }
            }
        } else {
            Text(if (state.remoteControlEnabled) "Remote control is enabled — you can control playback" else "The host controls playback", style = typo().bodySmall, color = palette.secondaryText)
        }
        Text("✦  Everyone stays in sync automatically.", style = typo().bodySmall, color = palette.secondaryText)
        OutlinedButton(
            modifier = Modifier.fillMaxWidth().height(52.dp),
            onClick = onLeaveRoom,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.danger),
            border = BorderStroke(1.dp, palette.danger),
            shape = RoundedCornerShape(16.dp),
        ) {
            Text(stringResource(Res.string.leave_room), color = palette.danger, fontWeight = FontWeight.SemiBold)
        }
        Spacer(modifier = Modifier.height(180.dp))
    }
}

@Composable
private fun ActiveRoomContent(
    state: ListeningRoomState,
    onPlayingChange: (Boolean) -> Unit,
    onSeek: (Long) -> Unit,
    onShareTrack: () -> Unit,
    onEnqueueTrack: () -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onFollowHostChange: (Boolean) -> Unit,
    onRemoteControlChange: (Boolean) -> Unit,
    onAddSong: () -> Unit,
    onInviteFriends: () -> Unit,
    onOpenChat: () -> Unit,
    onRemoveQueueTrack: (String) -> Unit,
    onLeaveRoom: () -> Unit,
) {
    val palette = nefySocialPalette()
    val track = state.currentTrack
    val isHost = state.hostId == state.currentUserId
    val canControl = isHost || state.remoteControlEnabled
    var roomClockMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(state.isPlaying, state.positionUpdatedAtMs, track?.videoId) {
        while (state.isPlaying) {
            roomClockMs = System.currentTimeMillis()
            delay(500L)
        }
    }
    val currentPosition = state.estimatedPositionMs(roomClockMs)
    val duration = track?.durationMs?.takeIf { it > 0L }
    var isSeeking by remember { mutableStateOf(false) }
    var pendingSeekMs by remember(track?.videoId) { mutableStateOf(currentPosition) }
    LaunchedEffect(currentPosition, track?.videoId, isSeeking) {
        if (!isSeeking) pendingSeekMs = currentPosition
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = stringResource(Res.string.listening_room), style = typo().headlineSmall)
                Text(
                    text = state.roomCode.orEmpty(),
                    style = typo().titleMedium,
                    color = palette.accent,
                )
                Text(
                    text = when (state.connection) {
                        ListeningRoomConnection.Connected -> "Connected · revision ${state.revision}"
                        ListeningRoomConnection.Connecting -> "Connecting…"
                        ListeningRoomConnection.Reconnecting -> "Reconnecting…"
                        ListeningRoomConnection.Disconnected -> "Disconnected"
                    },
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = onInviteFriends) {
                    Icon(imageVector = SimpIcons.PeopleAlt, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Invite")
                }
                TextButton(
                    onClick = {
                        shareUrl(
                            title = "Join my Nefy listening room",
                            url = "nefy://room/${state.roomCode}",
                        )
                    },
                ) {
                    Icon(imageVector = SimpIcons.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share")
                }
                TextButton(onClick = onOpenChat) {
                    Text("Chat${if (state.chatMessages.isEmpty()) "" else " ${state.chatMessages.size}"}")
                }
            }
        }

        if (state.recentReactions.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                state.recentReactions.takeLast(5).forEach { reaction ->
                    Surface(shape = CircleShape, color = palette.accentContainer, modifier = Modifier.padding(start = 4.dp)) {
                        Text(reaction.emoji, modifier = Modifier.padding(8.dp), style = typo().titleMedium)
                    }
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = palette.cardElevated),
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(text = stringResource(Res.string.currently_listening), style = typo().labelLarge, color = palette.secondaryText)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(
                        model = track?.artworkUrl,
                        contentDescription = track?.title,
                        modifier = Modifier.size(88.dp).clip(RoundedCornerShape(18.dp)),
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(text = track?.title ?: "Waiting for a song", style = typo().titleMedium, color = palette.primaryText, maxLines = 2)
                        Text(text = track?.artist ?: "Add a song from Nefy Search or Library", style = typo().bodySmall, color = palette.secondaryText, maxLines = 2)
                    }
                    if (canControl) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RippleIconButton(
                                imageVector = SimpIcons.SkipPrevious,
                                tint = MaterialTheme.colorScheme.onSurface,
                                onClick = onSkipPrevious,
                            )
                            RippleIconButton(
                                imageVector = if (state.isPlaying) SimpIcons.Pause else SimpIcons.PlayArrow,
                                tint = MaterialTheme.colorScheme.onSurface,
                                onClick = { onPlayingChange(!state.isPlaying) },
                            )
                            RippleIconButton(
                                imageVector = SimpIcons.SkipNext,
                                tint = MaterialTheme.colorScheme.onSurface,
                                onClick = onSkipNext,
                            )
                        }
                    } else {
                        Text(
                            text = "Host control",
                            style = typo().bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                duration?.let { totalDuration ->
                    Slider(
                        value = pendingSeekMs.coerceIn(0L, totalDuration).toFloat(),
                        onValueChange = { value ->
                            isSeeking = true
                            pendingSeekMs = value.toLong()
                        },
                        onValueChangeFinished = {
                            isSeeking = false
                            if (canControl) onSeek(pendingSeekMs.coerceIn(0L, totalDuration))
                        },
                        valueRange = 0f..totalDuration.toFloat(),
                        enabled = canControl,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = formatRoomTime(pendingSeekMs),
                            style = typo().labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = formatRoomTime(totalDuration),
                            style = typo().labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onAddSong) {
                        Icon(imageVector = SimpIcons.PeopleAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "Add song",
                            style = typo().labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF07111B),
                        )
                    }
                    if (track != null && canControl) {
                        TextButton(onClick = onEnqueueTrack) { Text("Queue current") }
                    }
                }
            }
        }

        Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = palette.card),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(text = "Shared queue", style = typo().titleMedium, color = palette.primaryText)
                    if (state.queue.isEmpty()) {
                        Text("Queue is empty — add a song from Nefy Search or Library.", style = typo().bodySmall, color = palette.secondaryText)
                    }
                    state.queue.forEachIndexed { index, queuedTrack ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable(enabled = canControl) { onPlayTrack(queuedTrack) }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (index == state.queueIndex) "Now playing · ${queuedTrack.title}" else queuedTrack.title,
                                    style = typo().bodyMedium,
                                    color = palette.primaryText,
                                )
                                Text(text = queuedTrack.artist, style = typo().bodySmall, color = palette.secondaryText)
                            }
                            if (canControl && index != state.queueIndex) {
                                TextButton(onClick = { onRemoveQueueTrack(queuedTrack.videoId) }, contentPadding = PaddingValues(horizontal = 6.dp)) {
                                    Text("Remove", color = palette.danger)
                                }
                            }
                        }
                    }
                }
            }

        Text(text = stringResource(Res.string.members), style = typo().titleMedium, color = palette.primaryText)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            state.members.take(4).forEach { member ->
                BoxAvatar(label = member.displayName.firstOrNull()?.uppercase() ?: "?")
            }
            Text(
                text = if (isHost) stringResource(Res.string.you_are_host) else "Following the host",
                style = typo().bodySmall,
                color = palette.secondaryText,
                modifier = Modifier.align(Alignment.CenterVertically),
            )
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = stringResource(Res.string.follow_host), style = typo().titleMedium)
                    Text(
                        text = stringResource(Res.string.invite_friends),
                        style = typo().bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = state.followHost, onCheckedChange = onFollowHostChange)
            }
        }

        if (isHost) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Remote control", style = typo().titleMedium)
                        Text(
                            text = "Allow everyone in this room to play, pause, and choose songs",
                            style = typo().bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = state.remoteControlEnabled,
                        onCheckedChange = onRemoteControlChange,
                    )
                }
            }
        } else {
            Text(
                text = if (state.remoteControlEnabled) {
                    "Remote control is enabled — you can control playback"
                } else {
                    "The host controls playback"
                },
                style = typo().bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        TextButton(
            modifier = Modifier.align(Alignment.CenterHorizontally),
            onClick = onLeaveRoom,
        ) {
            Text(text = stringResource(Res.string.leave_room))
        }
        Spacer(modifier = Modifier.height(180.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoomChatSheet(
    state: ListeningRoomState,
    onSendChat: (String) -> Unit,
    onSendReaction: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val palette = nefySocialPalette()
    val isRoomConnected = state.connection == ListeningRoomConnection.Connected
    var selectedTab by rememberSaveable { mutableStateOf("chat") }
    var draft by rememberSaveable { mutableStateOf("") }
    val reactions = listOf("❤", "✨", "🔥", "👏")
    val reactionCounts = state.recentReactions.groupingBy { it.emoji }.eachCount()

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = palette.pageBackground) {
        Column(
            modifier = Modifier.fillMaxWidth().heightIn(max = 860.dp).padding(horizontal = 18.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Room chat", style = typo().headlineSmall, fontWeight = FontWeight.Bold, color = palette.primaryText)
                    Text("${state.roomCode.orEmpty()} · ${state.members.size} listeners", style = typo().bodySmall, color = palette.secondaryText)
                }
                TextButton(onClick = onDismiss) { Text("Close", color = palette.accent) }
            }
            state.currentTrack?.let { track ->
                Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), color = palette.card, border = BorderStroke(1.dp, palette.outline)) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(modifier = Modifier.size(72.dp).clip(RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                            if (track.artworkUrl.isNullOrBlank()) {
                                Surface(modifier = Modifier.fillMaxSize(), color = palette.accentContainer) {
                                    Icon(SimpIcons.QueueMusic, contentDescription = null, tint = palette.accent, modifier = Modifier.padding(22.dp))
                                }
                            } else {
                                AsyncImage(model = track.artworkUrl, contentDescription = track.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            }
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(track.title, style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText, maxLines = 1)
                            Text("Shared listening", style = typo().bodyMedium, color = palette.secondaryText)
                        }
                        Surface(shape = RoundedCornerShape(14.dp), color = palette.accentContainer) {
                            Text(if (state.isPlaying) "LIVE" else "PAUSED", modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = typo().labelSmall, color = palette.accent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            state.errorMessage?.let { message ->
                Text(message, style = typo().bodySmall, color = palette.danger)
            }
            if (!isRoomConnected) {
                Text("Connecting to the room… chat and reactions will be enabled when connected.", style = typo().bodySmall, color = palette.secondaryText)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("chat" to "Chat", "reactions" to "Reactions").forEach { (key, label) ->
                    Surface(
                        modifier = Modifier.weight(1f).clickable { selectedTab = key },
                        shape = RoundedCornerShape(16.dp),
                        color = Color.Transparent,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            Text(label, modifier = Modifier.padding(vertical = 10.dp), textAlign = TextAlign.Center, color = if (selectedTab == key) palette.primaryText else palette.secondaryText)
                            Surface(modifier = Modifier.fillMaxWidth().height(3.dp), color = if (selectedTab == key) palette.accent else Color.Transparent) {}
                        }
                    }
                }
            }
            Surface(modifier = Modifier.fillMaxWidth().weight(1f, fill = false), shape = RoundedCornerShape(22.dp), color = palette.card, border = BorderStroke(1.dp, palette.outline)) {
                if (selectedTab == "chat") {
                    Column(modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp, max = 430.dp).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        if (state.chatMessages.isEmpty()) {
                            Text("Say something to the room.", style = typo().bodyMedium, color = palette.secondaryText)
                        } else {
                            state.chatMessages.takeLast(30).forEach { message ->
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                                    BoxAvatar(label = message.displayName.take(1).uppercase())
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(message.displayName, style = typo().titleMedium, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
                                        Surface(shape = RoundedCornerShape(16.dp), color = palette.cardElevated) {
                                            Text(message.message, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), color = palette.primaryText)
                                        }
                                        Text(formatRoomChatTime(message.createdAtMs), style = typo().labelSmall, color = palette.secondaryText)
                                    }
                                }
                            }
                        }
                        if (reactionCounts.isNotEmpty()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                reactionCounts.toList().take(4).forEach { (emoji, count) ->
                                    Surface(shape = CircleShape, color = palette.accentContainer) {
                                        Text("$emoji $count", modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), color = palette.primaryText)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Column(modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp, max = 430.dp).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Reactions float above the room for everyone.", style = typo().bodyMedium, color = palette.secondaryText)
                        if (state.recentReactions.isEmpty()) {
                            Text("Send the first reaction.", style = typo().bodyMedium, color = palette.primaryText)
                        } else {
                            state.recentReactions.takeLast(24).reversed().forEach { reaction ->
                                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    BoxAvatar(label = reaction.displayName.take(1).uppercase())
                                    Text(reaction.emoji, style = typo().headlineMedium)
                                    Text("${reaction.displayName} reacted", style = typo().bodyMedium, color = palette.primaryText)
                                    Spacer(modifier = Modifier.weight(1f))
                                    Text(formatRoomChatTime(reaction.createdAtMs), style = typo().labelSmall, color = palette.secondaryText)
                                }
                            }
                        }
                    }
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(modifier = Modifier.size(50.dp).clickable(enabled = isRoomConnected) { selectedTab = "reactions" }, shape = CircleShape, color = palette.card, border = BorderStroke(1.dp, palette.outline)) {
                    Icon(SimpIcons.Add, contentDescription = "Open reactions", tint = palette.accent, modifier = Modifier.padding(13.dp))
                }
                OutlinedTextField(
                    modifier = Modifier.weight(1f),
                    value = draft,
                    onValueChange = { draft = it.take(280) },
                    placeholder = { Text("Message the room…") },
                    singleLine = true,
                    enabled = isRoomConnected,
                    shape = RoundedCornerShape(18.dp),
                )
                Button(
                    onClick = {
                        val message = draft.trim()
                        if (message.isNotBlank()) {
                            onSendChat(message)
                            draft = ""
                        }
                    },
                    enabled = isRoomConnected && draft.trim().isNotBlank(),
                    modifier = Modifier.size(54.dp),
                    contentPadding = PaddingValues(0.dp),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = palette.accent, contentColor = palette.pageBackground),
                ) { Text("➤", style = typo().titleLarge) }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                reactions.forEach { emoji ->
                    FilledTonalButton(onClick = { onSendReaction(emoji) }, enabled = isRoomConnected, shape = CircleShape, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)) {
                        Text(emoji, style = typo().titleMedium)
                    }
                }
            }
        }
    }
}

private fun formatRoomChatTime(timestampMs: Long): String {
    val totalMinutes = ((timestampMs.coerceAtLeast(0L) / 60_000L) % (24 * 60)).toInt()
    val hour = (totalMinutes / 60).toString().padStart(2, '0')
    val minute = (totalMinutes % 60).toString().padStart(2, '0')
    return "$hour:$minute"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoomSongPickerSheet(
    onDismiss: () -> Unit,
    onAddTrack: (ListeningTrack) -> Unit,
    searchViewModel: SearchViewModel = koinInject(),
    libraryViewModel: NowPlayingBottomSheetViewModel = koinInject(),
    localPlaylistRepository: LocalPlaylistRepository = koinInject(),
) {
    val searchState by searchViewModel.searchScreenState.collectAsStateWithLifecycle()
    val searchUiState by searchViewModel.searchScreenUIState.collectAsStateWithLifecycle()
    val libraryState by libraryViewModel.uiState.collectAsStateWithLifecycle()
    var source by rememberSaveable { mutableStateOf("search") }
    var query by rememberSaveable { mutableStateOf("") }
    var selectedPlaylistId by rememberSaveable { mutableStateOf<Long?>(null) }
    var selectedPlaylistTitle by rememberSaveable { mutableStateOf("") }
    var libraryTracks by remember { mutableStateOf<List<SongEntity>>(emptyList()) }
    val palette = nefySocialPalette()
    val buttonContent = Color(0xFF07111B)

    LaunchedEffect(selectedPlaylistId) {
        libraryTracks = selectedPlaylistId?.let { localPlaylistRepository.getFullPlaylistTracks(it) }.orEmpty()
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier.fillMaxWidth().heightIn(max = 640.dp).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Add to shared queue", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold)
            Text("Choose music already available in Nefy.", style = typo().bodySmall, color = palette.secondaryText)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (source == "search") {
                    Button(
                        onClick = { source = "search" },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent, contentColor = buttonContent),
                    ) { Text("Search Nefy", color = buttonContent, fontWeight = FontWeight.SemiBold) }
                } else {
                    TextButton(
                        onClick = { source = "search" },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColors(contentColor = palette.primaryText),
                    ) { Text("Search Nefy", color = palette.primaryText) }
                }
                if (source == "library") {
                    Button(
                        onClick = { source = "library" },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent, contentColor = buttonContent),
                    ) { Text("Library", color = buttonContent, fontWeight = FontWeight.SemiBold) }
                } else {
                    TextButton(
                        onClick = { source = "library" },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColors(contentColor = palette.primaryText),
                    ) { Text("Library", color = palette.primaryText) }
                }
            }

            if (source == "search") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it.take(80) },
                        modifier = Modifier.weight(1f),
                        label = { Text("Song or artist") },
                        singleLine = true,
                    )
                    Button(
                        onClick = { searchViewModel.searchSongs(query) },
                        enabled = query.trim().isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.accent,
                            contentColor = buttonContent,
                            disabledContainerColor = palette.outline.copy(alpha = 0.50f),
                            disabledContentColor = palette.primaryText,
                        ),
                    ) { Text("Search", color = if (query.trim().isNotBlank()) buttonContent else palette.primaryText, fontWeight = FontWeight.SemiBold) }
                }
                when (searchUiState) {
                    SearchScreenUIState.Loading -> Text("Searching Nefy…", style = typo().bodySmall, color = palette.secondaryText)
                    SearchScreenUIState.Error -> Text("Nefy search failed. Try again.", style = typo().bodySmall, color = palette.danger)
                    else -> Unit
                }
                if (searchState.searchSongsResult.isEmpty() && searchUiState != SearchScreenUIState.Loading) {
                    SocialEmptyCard("Search for a song", "Results from Nefy will appear here.")
                } else {
                    searchState.searchSongsResult.forEach { result ->
                        val track = ListeningTrack(
                            videoId = result.videoId,
                            title = result.title.orEmpty().ifBlank { "Untitled" },
                            artist = result.artists?.joinToString(", ") { it.name }.orEmpty().ifBlank { "Unknown artist" },
                            artworkUrl = result.thumbnails?.maxByOrNull { it.width }?.url,
                            durationMs = result.durationSeconds?.toLong()?.times(1000L) ?: 0L,
                        )
                        RoomPickerTrackRow(track = track, actionLabel = "Add", onAction = { onAddTrack(track) })
                    }
                }
            } else if (selectedPlaylistId == null) {
                Text("Your Library", style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
                if (libraryState.listLocalPlaylist.isEmpty()) {
                    SocialEmptyCard("No local playlists yet", "Create a playlist in Nefy Library first.")
                } else {
                    libraryState.listLocalPlaylist.forEach { playlist ->
                        Card(modifier = Modifier.fillMaxWidth().clickable {
                            selectedPlaylistId = playlist.id
                            selectedPlaylistTitle = playlist.title
                        }) {
                            Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                BoxAvatar(label = playlist.title.take(1).uppercase())
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(playlist.title, style = typo().titleMedium, fontWeight = FontWeight.SemiBold)
                                    Text("${playlist.tracks?.size ?: 0} songs", style = typo().bodySmall, color = palette.secondaryText)
                                }
                                Text("Open", style = typo().labelMedium, color = palette.accent)
                            }
                        }
                    }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { selectedPlaylistId = null; libraryTracks = emptyList() }, colors = ButtonDefaults.textButtonColors(contentColor = palette.primaryText)) { Text("Back", color = palette.primaryText) }
                    Text(selectedPlaylistTitle, style = typo().titleLarge, fontWeight = FontWeight.SemiBold)
                }
                if (libraryTracks.isEmpty()) {
                    SocialEmptyCard("Playlist is empty", "Add songs to this Library playlist first.")
                } else {
                    libraryTracks.forEach { song ->
                        val track = ListeningTrack(
                            videoId = song.videoId,
                            title = song.title,
                            artist = song.artistName?.joinToString(", ").orEmpty().ifBlank { "Unknown artist" },
                            artworkUrl = song.thumbnails,
                            durationMs = song.durationSeconds.toLong() * 1000L,
                        )
                        RoomPickerTrackRow(track = track, actionLabel = "Add", onAction = { onAddTrack(track) })
                    }
                }
            }
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End), colors = ButtonDefaults.textButtonColors(contentColor = palette.primaryText)) { Text("Done", color = palette.primaryText) }
        }
    }
}

@Composable
private fun RoomPickerTrackRow(track: ListeningTrack, actionLabel: String, onAction: () -> Unit) {
    val palette = nefySocialPalette()
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = palette.card)) {
        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AsyncImage(model = track.artworkUrl, contentDescription = track.title, modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)))
            Column(modifier = Modifier.weight(1f)) {
                Text(track.title, style = typo().bodyMedium, color = palette.primaryText, maxLines = 2)
                Text(track.artist, style = typo().bodySmall, color = palette.secondaryText, maxLines = 1)
            }
            TextButton(onClick = onAction, colors = ButtonDefaults.textButtonColors(contentColor = palette.accent)) { Text(actionLabel, color = palette.accent) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoomInviteSheet(
    friends: List<com.nefy.app.social.listening.NefyFriend>,
    roomCode: String,
    onInviteFriend: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val palette = nefySocialPalette()
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = palette.card) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Invite friends", style = typo().headlineSmall, fontWeight = FontWeight.SemiBold, color = palette.primaryText)
            Text("Only accepted Nefy friends can join this room.", style = typo().bodySmall, color = palette.secondaryText)
            if (friends.isEmpty()) {
                SocialEmptyCard("No accepted friends yet", "Add friends from the Friends tab, or share the room link below.")
            } else {
                friends.forEach { friend ->
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        BoxAvatar(label = friend.displayName.take(1).uppercase())
                        Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(friend.displayName, style = typo().titleMedium, color = palette.primaryText)
                            Text(friend.handle?.let { "@$it" } ?: "Nefy friend", style = typo().bodySmall, color = palette.secondaryText)
                        }
                        TextButton(onClick = {
                            onInviteFriend(friend.userId)
                            shareUrl(title = "Join my Nefy listening room", url = "nefy://room/$roomCode")
                        }) { Text("Invite", color = palette.accent) }
                    }
                }
            }
            FilledTonalButton(onClick = { shareUrl(title = "Join my Nefy listening room", url = "nefy://room/$roomCode") }, modifier = Modifier.fillMaxWidth()) {
                Icon(imageVector = SimpIcons.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Share room link")
            }
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Close") }
        }
    }
}

private fun roomUserFacingError(message: String): String = when {
    message.contains("401", ignoreCase = true) || message.contains("invalid api key", ignoreCase = true) ->
        "Nefy social services are temporarily unavailable. You can still use the room controls."
    message.contains("service_role", ignoreCase = true) || message.contains("anon", ignoreCase = true) ->
        "Nefy social services need configuration. Room playback is still available."
    else -> message
}

private fun formatRoomTime(milliseconds: Long): String {
    val seconds = (milliseconds.coerceAtLeast(0L) / 1_000L).toInt()
    val minutes = seconds / 60
    val remainder = (seconds % 60).toString().padStart(2, '0')
    return "$minutes:$remainder"
}

@Composable
private fun BoxAvatar(label: String) {
    val palette = nefySocialPalette()
    Surface(
        modifier = Modifier.size(42.dp).clip(CircleShape),
        color = palette.accentContainer,
        contentColor = palette.primaryText,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text = label, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        }
    }
}


@Composable
private fun PlaylistContributorAvatar(
    displayName: String,
    avatarUrl: String?,
    palette: com.nefy.app.ui.theme.NefySocialPalette,
) {
    if (avatarUrl.isNullOrBlank()) {
        Surface(modifier = Modifier.size(30.dp), shape = CircleShape, color = palette.accentContainer) {
            Box(contentAlignment = Alignment.Center) {
                Text(displayName.take(1).uppercase(), color = palette.primaryText, style = typo().labelSmall, fontWeight = FontWeight.Bold)
            }
        }
    } else {
        AsyncImage(model = avatarUrl, contentDescription = displayName, modifier = Modifier.size(30.dp).clip(CircleShape))
    }
}
