package com.nefy.app.ui.navigation.graph

import androidx.compose.foundation.layout.PaddingValues
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.navigation.toRoute
import com.nefy.app.ui.navigation.destination.home.AnalyticsDestination
import com.nefy.app.ui.navigation.destination.home.CreditDestination
import com.nefy.app.ui.navigation.destination.home.FriendsDestination
import com.nefy.app.ui.navigation.destination.home.MoodDestination
import com.nefy.app.ui.navigation.destination.home.NotificationDestination
import com.nefy.app.ui.navigation.destination.home.RecentlySongsDestination
import com.nefy.app.ui.navigation.destination.home.SettingsDestination
import com.nefy.app.ui.navigation.destination.home.ProfileDestination
import com.nefy.app.ui.screen.home.FriendsScreen
import com.nefy.app.ui.screen.home.MoodScreen
import com.nefy.app.ui.screen.home.NotificationScreen
import com.nefy.app.ui.screen.home.RecentlySongsScreen
import com.nefy.app.ui.screen.home.SettingScreen
import com.nefy.app.ui.screen.home.ProfileScreen
import com.nefy.app.ui.screen.home.analytics.AnalyticsScreen
import com.nefy.app.ui.screen.other.CreditScreen

fun NavGraphBuilder.homeScreenGraph(
    innerPadding: PaddingValues,
    navController: NavController,
) {
    composable<FriendsDestination> { entry ->
        FriendsScreen(
            navController = navController,
            initialRoomCode = entry.toRoute<FriendsDestination>().roomCode,
            initialPage = entry.toRoute<FriendsDestination>().initialPage,
            playlistInvite = entry.toRoute<FriendsDestination>().playlistInvite,
            playlistId = entry.toRoute<FriendsDestination>().playlistId,
        )
    }
    composable<CreditDestination> {
        CreditScreen(
            paddingValues = innerPadding,
            navController = navController,
        )
    }
    composable<MoodDestination> { entry ->
        val params = entry.toRoute<MoodDestination>().params
        MoodScreen(
            navController = navController,
            params = params,
        )
    }
    composable<NotificationDestination> {
        NotificationScreen(
            navController = navController,
        )
    }
    composable<RecentlySongsDestination> {
        RecentlySongsScreen(
            navController = navController,
            innerPadding = innerPadding,
        )
    }
    composable<ProfileDestination> {
        ProfileScreen(
            navController = navController,
            innerPadding = innerPadding,
        )
    }
    composable<SettingsDestination> {
        SettingScreen(
            navController = navController,
            innerPadding = innerPadding,
        )
    }
    composable<AnalyticsDestination> {
        AnalyticsScreen(
            navController = navController,
            innerPadding = innerPadding,
        )
    }
}