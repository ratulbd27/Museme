package com.nefy.app.ui.component

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.nefy.app.ui.icon.Downloading
import com.nefy.app.ui.icon.Favorite
import com.nefy.app.ui.icon.Insights
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.icon.TrendingUp
import com.nefy.app.ui.navigation.destination.library.LibraryDynamicPlaylistDestination
import com.nefy.app.ui.screen.library.LibraryDynamicPlaylistType
import com.nefy.app.ui.theme.typo
import org.jetbrains.compose.resources.StringResource
import org.jetbrains.compose.resources.stringResource
import nefy.composeapp.generated.resources.Res
import nefy.composeapp.generated.resources.downloaded
import nefy.composeapp.generated.resources.favorite
import nefy.composeapp.generated.resources.followed
import nefy.composeapp.generated.resources.most_played

@Composable
fun LibraryTilingBox(navController: androidx.navigation.NavController) {
    val listItem = listOf(
        LibraryTilingState.Favorite,
        LibraryTilingState.Followed,
        LibraryTilingState.MostPlayed,
        LibraryTilingState.Downloaded,
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        listItem.chunked(2).forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                rowItems.forEach { item ->
                    LibraryTilingItem(
                        state = item,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            navController.navigate(
                                LibraryDynamicPlaylistDestination(
                                    type = item.playlistType.toStringParams(),
                                ),
                            )
                        },
                    )
                }
                if (rowItems.size == 1) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun LibraryTilingItem(
    state: LibraryTilingState,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {},
) {
    val title = stringResource(state.title)
    val interactionSource = remember { MutableInteractionSource() }

    Surface(
        modifier = modifier
            .height(72.dp)
            .nefyPressScale(interactionSource = interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
            ),
        shape = RoundedCornerShape(18.dp),
        color = state.containerColor,
        contentColor = Color.Black,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(
                imageVector = state.icon,
                contentDescription = title,
                modifier = Modifier.size(34.dp),
                tint = state.iconColor,
            )
            Text(
                text = title,
                style = typo().titleMedium,
                color = Color.Black,
                maxLines = 1,
            )
        }
    }
}

data class LibraryTilingState(
    val title: StringResource,
    val playlistType: LibraryDynamicPlaylistType,
    val containerColor: Color,
    val icon: ImageVector,
    val iconColor: Color,
) {
    companion object {
        val Favorite = LibraryTilingState(
            title = Res.string.favorite,
            playlistType = LibraryDynamicPlaylistType.Favorite,
            containerColor = Color(0xFFFF99AE),
            icon = SimpIcons.Favorite,
            iconColor = Color(0xFFD10000),
        )
        val Followed = LibraryTilingState(
            title = Res.string.followed,
            playlistType = LibraryDynamicPlaylistType.Followed,
            containerColor = Color(0xFFFFEB3B),
            icon = SimpIcons.Insights,
            iconColor = Color.Black,
        )
        val MostPlayed = LibraryTilingState(
            title = Res.string.most_played,
            playlistType = LibraryDynamicPlaylistType.MostPlayed,
            containerColor = Color(0xFF00BCD4),
            icon = SimpIcons.TrendingUp,
            iconColor = Color.Black,
        )
        val Downloaded = LibraryTilingState(
            title = Res.string.downloaded,
            playlistType = LibraryDynamicPlaylistType.Downloaded,
            containerColor = Color(0xFF4CAF50),
            icon = SimpIcons.Downloading,
            iconColor = Color.Black,
        )
    }
}
