package com.nefy.app.ui.player

/** Presentation-only player styles. Playback state and event routing are shared by both modes. */
object PlayerStyle {
    const val KEY = "nefy_player_style"
    const val CLASSIC = "classic"
    const val PIXEL = "pixel"

    fun isPixel(value: String?): Boolean = value == PIXEL
}

/** Stable labels used by the settings selector and player-mode branches. */
object PlayerStyleLabel {
    const val CLASSIC = "Nefy player"
    const val PIXEL = "Pixel-style player"
}
