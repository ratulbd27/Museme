package com.nefy.app.social.listening

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ListeningRoomMember(
    val id: String,
    val displayName: String,
    val isHost: Boolean = false,
    val isOnline: Boolean = true,
)

@Serializable
data class ListeningTrack(
    val videoId: String,
    val title: String,
    val artist: String,
    val artworkUrl: String? = null,
    val durationMs: Long = 0L,
)

@Serializable
data class RoomChatMessage(
    val id: String,
    val userId: String,
    val displayName: String,
    val message: String,
    val createdAtMs: Long,
)

@Serializable
data class RoomReaction(
    val id: String,
    val userId: String,
    val displayName: String,
    val emoji: String,
    val createdAtMs: Long,
)

@Serializable
data class RoomInvitation(
    val id: String,
    val roomCode: String,
    val inviterUserId: String,
    val inviterDisplayName: String,
    val createdAtMs: Long,
)

@Serializable
enum class ListeningRoomConnection {
    Disconnected,
    Connecting,
    Connected,
    Reconnecting,
}

@Serializable
data class ListeningRoomState(
    val roomCode: String? = null,
    val hostId: String? = null,
    val currentUserId: String = "you",
    val members: List<ListeningRoomMember> = emptyList(),
    val currentTrack: ListeningTrack? = null,
    val queue: List<ListeningTrack> = emptyList(),
    val queueIndex: Int = -1,
    val positionMs: Long = 0L,
    val positionUpdatedAtMs: Long = 0L,
    val serverTimeMs: Long = 0L,
    val snapshotReceivedAtMs: Long = 0L,
    val isPlaying: Boolean = false,
    val followHost: Boolean = true,
    val remoteControlEnabled: Boolean = true,
    val chatMessages: List<RoomChatMessage> = emptyList(),
    val recentReactions: List<RoomReaction> = emptyList(),
    val revision: Long = 0L,
    val connection: ListeningRoomConnection = ListeningRoomConnection.Disconnected,
    val errorMessage: String? = null,
) {
    fun estimatedServerNowMs(nowMs: Long = System.currentTimeMillis()): Long =
        if (serverTimeMs > 0L && snapshotReceivedAtMs > 0L) {
            serverTimeMs + (nowMs - snapshotReceivedAtMs).coerceAtLeast(0L)
        } else {
            nowMs
        }

    fun estimatedPositionMs(nowMs: Long = System.currentTimeMillis()): Long =
        if (isPlaying && positionUpdatedAtMs > 0L) {
            positionMs + (estimatedServerNowMs(nowMs) - positionUpdatedAtMs).coerceAtLeast(0L)
        } else {
            positionMs
        }
}

@Serializable
sealed class ListeningRoomCommand {
    @Serializable
    @SerialName("create_room")
    data class CreateRoom(
        val displayName: String,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("join_room")
    data class JoinRoom(
        val roomCode: String,
        val displayName: String,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("leave_room")
    data object LeaveRoom : ListeningRoomCommand()

    @Serializable
    @SerialName("invite_friend")
    data class InviteFriend(
        val friendUserId: String,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("playback")
    data class Playback(
        val isPlaying: Boolean,
        val positionMs: Long,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("set_track")
    data class SetTrack(
        val track: ListeningTrack,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("enqueue_track")
    data class EnqueueTrack(
        val track: ListeningTrack,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("remove_queue_track")
    data class RemoveQueueTrack(
        val videoId: String,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("skip_next")
    data object SkipNext : ListeningRoomCommand()

    @Serializable
    @SerialName("skip_previous")
    data object SkipPrevious : ListeningRoomCommand()

    @Serializable
    @SerialName("advance_queue")
    data class AdvanceQueue(
        val expectedTrackId: String,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("send_chat")
    data class SendChat(
        val message: String,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("send_reaction")
    data class SendReaction(
        val emoji: String,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("follow_host")
    data class SetFollowHost(
        val enabled: Boolean,
    ) : ListeningRoomCommand()

    @Serializable
    @SerialName("remote_control")
    data class SetRemoteControl(
        val enabled: Boolean,
    ) : ListeningRoomCommand()
}

@Serializable
sealed class ListeningRoomEvent {
    @Serializable
    @SerialName("snapshot")
    data class Snapshot(
        val state: ListeningRoomState,
    ) : ListeningRoomEvent()

    @Serializable
    @SerialName("connection")
    data class ConnectionChanged(
        val connection: ListeningRoomConnection,
    ) : ListeningRoomEvent()

    @Serializable
    @SerialName("error")
    data class Error(
        val message: String,
    ) : ListeningRoomEvent()

    @Serializable
    @SerialName("social_snapshot")
    data class SocialSnapshot(
        val state: NefySocialState,
    ) : ListeningRoomEvent()

    @Serializable
    @SerialName("social_presence")
    data class SocialPresence(
        val presence: List<NefyPresence> = emptyList(),
    ) : ListeningRoomEvent()

    @Serializable
    @SerialName("room_invitation")
    data class RoomInvitationReceived(
        val invitation: RoomInvitation,
    ) : ListeningRoomEvent()
}
