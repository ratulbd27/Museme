package com.nefy.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.adaptive.currentWindowAdaptiveInfo
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.window.core.layout.WindowSizeClass.Companion.WIDTH_DP_MEDIUM_LOWER_BOUND
import coil3.toUri
import com.maxrave.domain.data.player.GenericMediaItem
import com.maxrave.domain.manager.DataStoreManager
import com.maxrave.domain.manager.DataStoreManager.Values.TRUE
import com.maxrave.logger.Logger
import com.nefy.app.expect.Orientation
import com.nefy.app.expect.currentOrientation
import com.nefy.app.expect.openUrl
import com.nefy.app.expect.ui.layerBackdrop
import com.nefy.app.expect.ui.rememberBackdrop
import com.nefy.app.extension.copy
import com.nefy.app.ui.component.AppBottomNavigationBar
import com.nefy.app.ui.component.AppNavigationRail
import com.nefy.app.ui.component.NefyExpressiveMotion
import com.nefy.app.ui.component.LiquidGlassAppBottomNavigationBar
import com.nefy.app.ui.icon.ArrowForwardIos
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.navigation.destination.home.FriendsDestination
import com.nefy.app.ui.navigation.destination.home.NotificationDestination
import com.nefy.app.ui.navigation.destination.list.AlbumDestination
import com.nefy.app.ui.navigation.destination.list.ArtistDestination
import com.nefy.app.ui.navigation.destination.list.PlaylistDestination
import com.nefy.app.ui.navigation.destination.player.FullscreenDestination
import com.nefy.app.ui.player.PlayerStyle
import com.nefy.app.ui.navigation.graph.AppNavigationGraph
import com.nefy.app.ui.screen.MiniPlayer
import com.nefy.app.ui.screen.player.PixelMusicFullPlayer
import com.nefy.app.ui.screen.player.PixelMusicMiniPlayer
import com.nefy.app.ui.screen.player.NowPlayingScreen
import com.nefy.app.ui.screen.player.NowPlayingScreenContent
import com.nefy.app.ui.theme.AppTheme
import com.nefy.app.ui.theme.ForceDarkContent
import com.nefy.app.ui.theme.parseThemeColorHex
import com.nefy.app.ui.theme.fontFamily
import com.nefy.app.ui.theme.typo
import com.nefy.app.viewModel.SharedViewModel
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.materials.HazeMaterials
import dev.chrisbanes.haze.rememberHazeState
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import nefy.composeapp.generated.resources.Res
import nefy.composeapp.generated.resources.cancel
import nefy.composeapp.generated.resources.do_not_show_again
import nefy.composeapp.generated.resources.download
import nefy.composeapp.generated.resources.good_night
import nefy.composeapp.generated.resources.notification
import nefy.composeapp.generated.resources.sleep_timer_off
import nefy.composeapp.generated.resources.this_app_needs_to_access_your_notification
import nefy.composeapp.generated.resources.this_link_is_not_supported
import nefy.composeapp.generated.resources.yes

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun App(viewModel: SharedViewModel = koinInject()) {
    val windowSize = currentWindowAdaptiveInfo().windowSizeClass
    val navController = rememberNavController()

    val sleepTimerState by viewModel.sleepTimerState.collectAsStateWithLifecycle()
    val nowPlayingData by viewModel.nowPlayingState.collectAsStateWithLifecycle()
    val intent by viewModel.intent.collectAsStateWithLifecycle()
    val showNotificationPermissionDialog by viewModel.showNotificationPermissionDialog.collectAsStateWithLifecycle()

    val isTranslucentBottomBar by viewModel.getTranslucentBottomBar().collectAsStateWithLifecycle(DataStoreManager.FALSE)
    val isLiquidGlassEnabled by viewModel.getEnableLiquidGlass().collectAsStateWithLifecycle(DataStoreManager.FALSE)
    val playerStyle by viewModel.getPlayerStyle().collectAsStateWithLifecycle(PlayerStyle.CLASSIC)
    val usePixelPlayer = PlayerStyle.isPixel(playerStyle)

    val themeMode by viewModel.getThemeMode().collectAsStateWithLifecycle(DataStoreManager.THEME_MODE_DARK)
    val themeColorSource by viewModel.getThemeColorSource().collectAsStateWithLifecycle(DataStoreManager.THEME_COLOR_DEFAULT)
    val customThemeColorHex by viewModel.getCustomThemeColor().collectAsStateWithLifecycle(DataStoreManager.DEFAULT_THEME_COLOR_HEX)
    // MiniPlayer visibility logic
    var isShowMiniPlayer by rememberSaveable {
        mutableStateOf(true)
    }

    // Now playing screen
    var isShowNowPlaylistScreen by rememberSaveable {
        mutableStateOf(false)
    }

    // Fullscreen
    var isInFullscreen by rememberSaveable {
        mutableStateOf(false)
    }

    var isNavBarVisible by rememberSaveable {
        mutableStateOf(true)
    }

    val hazeState =
        rememberHazeState(
            blurEnabled = true,
        )

    LaunchedEffect(nowPlayingData) {
        isShowMiniPlayer = !(nowPlayingData?.mediaItem == null || nowPlayingData?.mediaItem == GenericMediaItem.EMPTY)
    }

    LaunchedEffect(intent) {
        val intent = intent ?: return@LaunchedEffect
        val data = intent.data
        Logger.d("MainActivity", "onCreate: $data")
        if (data != null) {
            if (data.scheme == "nefy" && data.host == "room") {
                val roomCode = data.pathSegments.firstOrNull()?.uppercase()
                viewModel.setIntent(null)
                if (!roomCode.isNullOrBlank()) {
                    navController.navigate(FriendsDestination(roomCode = roomCode))
                }
            } else if (data.scheme == "nefy" && data.host == "playlist") {
                val inviteCode = data.pathSegments.firstOrNull()?.uppercase()
                viewModel.setIntent(null)
                if (!inviteCode.isNullOrBlank()) {
                    navController.navigate(FriendsDestination(initialPage = "playlists", playlistInvite = inviteCode))
                }
            } else if (data == "nefy://notification".toUri()) {
                viewModel.setIntent(null)
                navController.navigate(
                    NotificationDestination,
                )
            } else if (data.scheme == "wordbyword" && data.host == "lastfm-auth") {
                // Last.fm sends the user back here after they approve access, carrying the request
                // token: wordbyword://lastfm-auth?token=xxx. The callback is fixed on the API
                // account, which is why the scheme is not "simpmusic".
                val token = data.getQueryParameter("token")
                Logger.d("MainActivity", "Last.fm callback, token present: ${!token.isNullOrEmpty()}")
                viewModel.setIntent(null)
                // Deliberately no navigation: the login screen is almost certainly already open —
                // the browser was opened from it — and navigating would stack a second copy on top
                // of it. The token is handed straight to the shared view model, and the screen
                // closes itself when it sees a session key appear.
                token?.let { viewModel.completeLastfmLogin(it) }
            } else if (data.scheme == "nefy") {
                // nefy://watch?v=VIDEO_ID
                // nefy://playlist?list=PLAYLIST_ID
                // nefy://channel/CHANNEL_ID
                // nefy://watch?v=VIDEO_ID  (host="watch", no path)
                // nefy://playlist?list=PLAYLIST_ID
                // nefy://channel/CHANNEL_ID
                val segments = data.pathSegments
                // For Nefy: segments = ["app", "watch"] → appPath = segments[1]
                // For nefy://: host IS the appPath (e.g. host="watch"), segments = []
                val appPath =
                    if (data.scheme == "nefy") {
                        data.host
                    } else {
                        segments.getOrNull(1)
                    }
                Logger.d("MainActivity", "Nefy deep link, appPath: $appPath")
                viewModel.setIntent(null)
                when (appPath) {
                    "watch" -> {
                        data.getQueryParameter("v")?.let { videoId ->
                            viewModel.loadSharedMediaItem(videoId)
                        }
                    }

                    "playlist" -> {
                        data.getQueryParameter("list")?.let { playlistId ->
                            if (playlistId.startsWith("OLAK5uy_")) {
                                navController.navigate(AlbumDestination(browseId = playlistId))
                            } else if (playlistId.startsWith("VL")) {
                                navController.navigate(PlaylistDestination(playlistId = playlistId))
                            } else {
                                navController.navigate(PlaylistDestination(playlistId = "VL$playlistId"))
                            }
                        }
                    }

                    "channel", "c" -> {
                        // nefy://channel/UCxxx → segments = ["UCxxx"]
                        // Nefy/app/channel/UCxxx → segments = ["app", "channel", "UCxxx"]
                        val artistId =
                            if (data.scheme == "nefy") {
                                segments.firstOrNull()
                            } else {
                                segments.getOrNull(2)
                            }
                        artistId?.let {
                            if (it.startsWith("UC")) {
                                navController.navigate(ArtistDestination(channelId = it))
                            } else {
                                viewModel.makeToast(getString(Res.string.this_link_is_not_supported))
                            }
                        }
                    }

                    "album" -> {
                        data.getQueryParameter("id")?.let { albumId ->
                            navController.navigate(AlbumDestination(browseId = albumId))
                        }
                    }

                    else -> {
                        viewModel.makeToast(getString(Res.string.this_link_is_not_supported))
                    }
                }
            } else {
                Logger.d("MainActivity", "onCreate: $data")
                when (val path = data.pathSegments.firstOrNull()) {
                    "playlist" -> {
                        data
                            .getQueryParameter("list")
                            ?.let { playlistId ->
                                viewModel.setIntent(null)
                                if (playlistId.startsWith("OLAK5uy_")) {
                                    navController.navigate(
                                        AlbumDestination(
                                            browseId = playlistId,
                                        ),
                                    )
                                } else if (playlistId.startsWith("VL")) {
                                    navController.navigate(
                                        PlaylistDestination(
                                            playlistId = playlistId,
                                        ),
                                    )
                                } else {
                                    navController.navigate(
                                        PlaylistDestination(
                                            playlistId = "VL$playlistId",
                                        ),
                                    )
                                }
                            }
                    }

                    "channel", "c" -> {
                        data.lastPathSegment?.let { artistId ->
                            if (artistId.startsWith("UC")) {
                                viewModel.setIntent(null)
                                navController.navigate(
                                    ArtistDestination(
                                        channelId = artistId,
                                    ),
                                )
                            } else {
                                viewModel.makeToast(
                                    getString(
                                        Res.string.this_link_is_not_supported,
                                    ),
                                )
                            }
                        }
                    }

                    else -> {
                        when {
                            path == "watch" -> data.getQueryParameter("v")
                            data.host == "youtu.be" -> path
                            else -> null
                        }?.let { videoId ->
                            viewModel.loadSharedMediaItem(videoId)
                        }
                    }
                }
            }
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    LaunchedEffect(navBackStackEntry) {
        Logger.d("MainActivity", "Current destination: ${navBackStackEntry?.destination?.route}")
        if (navBackStackEntry?.destination?.route?.contains("FullscreenDestination") == true) {
            isShowNowPlaylistScreen = false
        }
        isInFullscreen = navBackStackEntry?.destination?.hierarchy?.any {
            it.hasRoute(FullscreenDestination::class)
        } == true
    }
    var isScrolledToTop by rememberSaveable {
        mutableStateOf(false)
    }
    val isTablet = windowSize.isWidthAtLeastBreakpoint(WIDTH_DP_MEDIUM_LOWER_BOUND)
    val isTabletLandscape = isTablet && currentOrientation() == Orientation.LANDSCAPE

    AppTheme(
        themeMode = themeMode,
        themeColorSource = themeColorSource,
        customThemeColor = parseThemeColorHex(customThemeColorHex),
    ) {
        // Backdrop base must match the theme: white page → white glass, dark/AMOLED → black glass.
        // Read inside AppTheme so MaterialTheme reflects the resolved scheme (light background is #FFFFFF).
        val backdrop =
            rememberBackdrop(
                if (MaterialTheme.colorScheme.background.luminance() > 0.5f) Color.White else Color.Black,
            )
        Scaffold(
            bottomBar = {
                if (!isTablet) {
                    AnimatedVisibility(
                        isNavBarVisible && !isShowNowPlaylistScreen,
                        enter = fadeIn(
                            animationSpec = tween(NefyExpressiveMotion.standard, easing = NefyExpressiveMotion.emphasized),
                        ) + slideInVertically(
                            animationSpec = tween(NefyExpressiveMotion.expressive, easing = NefyExpressiveMotion.emphasized),
                            initialOffsetY = { it / 2 },
                        ),
                        exit = fadeOut(
                            animationSpec = tween(NefyExpressiveMotion.short),
                        ) + slideOutVertically(
                            animationSpec = tween(NefyExpressiveMotion.standard, easing = NefyExpressiveMotion.emphasized),
                            targetOffsetY = { it / 3 },
                        ),
                    ) {
                        Column {
                            AnimatedVisibility(
                                isShowMiniPlayer && !isShowNowPlaylistScreen && isLiquidGlassEnabled == DataStoreManager.FALSE,
                                enter =
                                    fadeIn(
                                        animationSpec = tween(
                                            NefyExpressiveMotion.standard,
                                            easing = NefyExpressiveMotion.emphasized,
                                        ),
                                    ) +
                                        slideInVertically(
                                            animationSpec = tween(
                                                NefyExpressiveMotion.expressive,
                                                easing = NefyExpressiveMotion.emphasized,
                                            ),
                                            initialOffsetY = { it / 2 },
                                        ) +
                                        scaleIn(
                                            initialScale = 0.96f,
                                            animationSpec = tween(
                                                NefyExpressiveMotion.expressive,
                                                easing = NefyExpressiveMotion.emphasized,
                                            ),
                                        ),
                                exit =
                                    fadeOut(
                                        animationSpec = tween(
                                            NefyExpressiveMotion.short,
                                        ),
                                    ) +
                                        slideOutVertically(
                                            animationSpec = tween(
                                                NefyExpressiveMotion.standard,
                                                easing = NefyExpressiveMotion.emphasized,
                                            ),
                                            targetOffsetY = { it / 3 },
                                        ) +
                                        scaleOut(
                                            targetScale = 0.96f,
                                            animationSpec = tween(
                                                NefyExpressiveMotion.standard,
                                                easing = NefyExpressiveMotion.emphasized,
                                            ),
                                        ),
                            ) {
                                val miniPlayerModifier =
                                    Modifier
                                        .height(64.dp)
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp)
                                        .padding(bottom = 8.dp)
                                if (usePixelPlayer) {
                                    PixelMusicMiniPlayer(
                                        modifier = miniPlayerModifier,
                                        sharedViewModel = viewModel,
                                        onClick = { isShowNowPlaylistScreen = true },
                                        onClose = {
                                            viewModel.stopPlayer()
                                            viewModel.isServiceRunning = false
                                        },
                                    )
                                } else {
                                    MiniPlayer(
                                        miniPlayerModifier,
                                        backdrop = backdrop,
                                        onClick = { isShowNowPlaylistScreen = true },
                                        onClose = {
                                            viewModel.stopPlayer()
                                            viewModel.isServiceRunning = false
                                        },
                                    )
                                }
                            }
                            if (isLiquidGlassEnabled == TRUE) {
                                LiquidGlassAppBottomNavigationBar(
                                    navController = navController,
                                    backdrop = backdrop,
                                    viewModel = viewModel,
                                    onOpenNowPlaying = { isShowNowPlaylistScreen = true },
                                    isScrolledToTop = isScrolledToTop,
                                ) { klass ->
                                    viewModel.reloadDestination(klass)
                                }
                            } else {
                                AppBottomNavigationBar(
                                    navController = navController,
                                    isTranslucentBackground = isTranslucentBottomBar == TRUE,
                                ) { klass ->
                                    viewModel.reloadDestination(klass)
                                }
                            }
                        }
                    }
                }
            },
            content = { innerPadding ->
                Box(
                    Modifier
                        .fillMaxSize()
                        .then(
                            if (isLiquidGlassEnabled == TRUE && !isTablet) {
                                Modifier.layerBackdrop(backdrop)
                            } else {
                                Modifier
                            },
                        ),
                ) {
                    Row(
                        Modifier.fillMaxSize(),
                    ) {
                        if (isTablet && !isInFullscreen) {
                            AppNavigationRail(
                                navController = navController,
                            ) { klass ->
                                viewModel.reloadDestination(klass)
                            }
                        }
                        Box(
                            Modifier
                                .fillMaxSize()
                                .weight(1f),
                        ) {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .then(
                                        if (isLiquidGlassEnabled == TRUE && isTablet && !isInFullscreen) {
                                            Modifier.layerBackdrop(backdrop)
                                        } else {
                                            Modifier
                                        },
                                    ).hazeSource(hazeState),
                            ) {
                                AppNavigationGraph(
                                    innerPadding = innerPadding,
                                    navController = navController,
                                    hideNavBar = {
                                        isNavBarVisible = false
                                    },
                                    showNavBar = {
                                        isNavBarVisible = true
                                    },
                                    showNowPlayingSheet = {
                                        isShowNowPlaylistScreen = true
                                    },
                                    onScrolling = {
                                        isScrolledToTop = it
                                    },
                                )
                            }
                            this@Row.AnimatedVisibility(
                                modifier =
                                    Modifier
                                        .padding(innerPadding)
                                        .align(Alignment.BottomCenter),
                                visible = isShowMiniPlayer && !isShowNowPlaylistScreen && isTablet && !isInFullscreen,
                                enter = fadeIn() + slideInHorizontally(),
                                exit = fadeOut(),
                            ) {
                                val miniPlayerModifier =
                                    if (getPlatform() == Platform.Android) {
                                        Modifier
                                            .height(56.dp)
                                            .fillMaxWidth(0.8f)
                                            .padding(horizontal = 12.dp)
                                            .padding(bottom = 4.dp)
                                    } else {
                                        Modifier
                                            .fillMaxWidth()
                                            .height(84.dp)
                                            .background(Color.Transparent)
                                            .hazeEffect(hazeState, style = HazeMaterials.ultraThin()) {
                                                blurEnabled = true
                                            }
                                    }
                                if (usePixelPlayer) {
                                    PixelMusicMiniPlayer(
                                        modifier = miniPlayerModifier,
                                        sharedViewModel = viewModel,
                                        onClick = { isShowNowPlaylistScreen = true },
                                        onClose = {
                                            viewModel.stopPlayer()
                                            viewModel.isServiceRunning = false
                                        },
                                    )
                                } else {
                                    MiniPlayer(
                                        miniPlayerModifier,
                                        backdrop = backdrop,
                                        onClick = { isShowNowPlaylistScreen = true },
                                        onClose = {
                                            viewModel.stopPlayer()
                                            viewModel.isServiceRunning = false
                                        },
                                    )
                                }
                            }
                        }
                        if (isTablet && isTabletLandscape && !isInFullscreen) {
                            AnimatedVisibility(
                                isShowNowPlaylistScreen,
                                enter =
                                    expandHorizontally(
                                        animationSpec = tween(
                                            NefyExpressiveMotion.playerSheetDuration,
                                            easing = NefyExpressiveMotion.playerSheetEasing,
                                        ),
                                    ) +
                                        fadeIn(
                                            animationSpec = tween(
                                                NefyExpressiveMotion.playerSheetDuration,
                                                easing = NefyExpressiveMotion.playerSheetEasing,
                                            ),
                                        ),
                                exit =
                                    shrinkHorizontally(
                                        animationSpec = tween(
                                            NefyExpressiveMotion.playerSheetDuration,
                                            easing = NefyExpressiveMotion.playerSheetEasing,
                                        ),
                                    ) +
                                        fadeOut(
                                            animationSpec = tween(NefyExpressiveMotion.playerSheetDuration, easing = NefyExpressiveMotion.playerSheetEasing),
                                        ),
                            ) {
                                Row(
                                    Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(0.35f),
                                ) {
                                    Spacer(Modifier.width(8.dp))
                                    Box(
                                        Modifier
                                            .padding(
                                                innerPadding.copy(
                                                    start = 0.dp,
                                                    top = 0.dp,
                                                    bottom = 0.dp,
                                                ),
                                            ).clip(
                                                RoundedCornerShape(12.dp),
                                            ),
                                    ) {
                                        if (usePixelPlayer) {
                                            PixelMusicFullPlayer(
                                                sharedViewModel = viewModel,
                                                onDismiss = { isShowNowPlaylistScreen = false },
                                            )
                                        } else {
                                            ForceDarkContent {
                                                NowPlayingScreenContent(
                                                    navController = navController,
                                                    sharedViewModel = viewModel,
                                                    isExpanded = true,
                                                    dismissIcon = SimpIcons.ArrowForwardIos,
                                                ) {
                                                    isShowNowPlaylistScreen = false
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                AnimatedVisibility(
                    visible = isShowNowPlaylistScreen && !isTabletLandscape,
                    enter =
                        fadeIn(
                            animationSpec = tween(
                                NefyExpressiveMotion.playerSheetDuration,
                                easing = NefyExpressiveMotion.playerSheetEasing,
                            ),
                        ) +
                            slideInVertically(
                                animationSpec = tween(
                                    NefyExpressiveMotion.playerSheetDuration,
                                    easing = NefyExpressiveMotion.playerSheetEasing,
                                ),
                                initialOffsetY = { it / 3 },
                            ) +
                            scaleIn(
                                initialScale = 0.985f,
                                animationSpec = NefyExpressiveMotion.playerSheetSpring,
                            ),
                    exit =
                        fadeOut(
                            animationSpec = tween(
                                NefyExpressiveMotion.playerSheetDuration,
                                easing = NefyExpressiveMotion.playerSheetEasing,
                            ),
                        ) +
                            slideOutVertically(
                                animationSpec = tween(
                                    NefyExpressiveMotion.playerSheetDuration,
                                    easing = NefyExpressiveMotion.playerSheetEasing,
                                ),
                                targetOffsetY = { it / 4 },
                            ) +
                            scaleOut(
                                targetScale = 0.985f,
                                animationSpec = tween(
                                    NefyExpressiveMotion.playerSheetDuration,
                                    easing = NefyExpressiveMotion.playerSheetEasing,
                                ),
                            ),
                ) {
                    if (usePixelPlayer) {
                        PixelMusicFullPlayer(
                            sharedViewModel = viewModel,
                            onDismiss = { isShowNowPlaylistScreen = false },
                        )
                    } else {
                        ForceDarkContent {
                            NowPlayingScreen(
                                navController = navController,
                            ) {
                                isShowNowPlaylistScreen = false
                            }
                        }
                    }
                }

                if (sleepTimerState.isDone) {
                    Logger.w("MainActivity", "Sleep Timer Done: $sleepTimerState")
                    AlertDialog(
                        properties =
                            DialogProperties(
                                dismissOnBackPress = false,
                                dismissOnClickOutside = false,
                            ),
                        onDismissRequest = {
                            viewModel.stopSleepTimer()
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                viewModel.stopSleepTimer()
                            }) {
                                Text(
                                    stringResource(Res.string.yes),
                                    style = typo().bodySmall,
                                )
                            }
                        },
                        text = {
                            Text(
                                stringResource(Res.string.sleep_timer_off),
                                style = typo().labelSmall,
                            )
                        },
                        title = {
                            Text(
                                stringResource(Res.string.good_night),
                                style = typo().bodySmall,
                            )
                        },
                    )
                }

                if (showNotificationPermissionDialog) {
                    var doNotShowAgain by remember { mutableStateOf(false) }
                    AlertDialog(
                        onDismissRequest = {
                            viewModel.dismissNotificationPermissionDialog(doNotShowAgain)
                        },
                        confirmButton = {
                            TextButton(
                                onClick = {
                                    viewModel.dismissNotificationPermissionDialog(doNotShowAgain)
                                },
                            ) {
                                Text(
                                    stringResource(Res.string.yes),
                                    style = typo().bodySmall,
                                )
                            }
                        },
                        title = {
                            Text(
                                stringResource(Res.string.notification),
                                style = typo().labelSmall,
                            )
                        },
                        text = {
                            Column {
                                Text(
                                    stringResource(Res.string.this_app_needs_to_access_your_notification),
                                    style = typo().bodySmall,
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier =
                                        Modifier
                                            .clickable { doNotShowAgain = !doNotShowAgain }
                                            .fillMaxWidth(),
                                ) {
                                    Checkbox(
                                        checked = doNotShowAgain,
                                        onCheckedChange = { doNotShowAgain = it },
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        stringResource(Res.string.do_not_show_again),
                                        style = typo().bodySmall,
                                    )
                                }
                            }
                        },
                    )
                }
            },
        )
    }
}