package com.nefy.app.ui.screen.library

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import coil3.compose.LocalPlatformContext
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.maxrave.common.LibraryChipType
import com.maxrave.domain.utils.LocalResource
import com.maxrave.logger.Logger
import com.nefy.app.extension.copy
import com.nefy.app.extension.isScrollingUp
import com.nefy.app.social.listening.ListeningRoomController
import com.nefy.app.social.listening.NefySavedPlaylist
import com.nefy.app.social.listening.SharedPlaylistLibraryItem
import com.nefy.app.ui.component.Chip
import com.nefy.app.ui.component.EndOfPage
import com.nefy.app.ui.component.GridLibraryPlaylist
import com.nefy.app.ui.component.LibraryItem
import com.nefy.app.ui.component.LibraryItemState
import com.nefy.app.ui.component.LibraryItemType
import com.nefy.app.ui.component.LibraryTilingBox
import com.nefy.app.ui.icon.AutoGraph
import com.nefy.app.ui.icon.PeopleAlt
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.navigation.destination.home.AnalyticsDestination
import com.nefy.app.ui.navigation.destination.home.FriendsDestination
import com.nefy.app.ui.theme.nefySocialPalette
import com.nefy.app.ui.theme.typo
import com.nefy.app.viewModel.LibraryViewModel
import com.nefy.app.viewModel.SettingsViewModel
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.materials.ExperimentalHazeMaterialsApi
import dev.chrisbanes.haze.materials.HazeMaterials
import dev.chrisbanes.haze.rememberHazeState
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.koinInject
import org.koin.compose.viewmodel.koinViewModel
import nefy.composeapp.generated.resources.Res
import nefy.composeapp.generated.resources.chart
import nefy.composeapp.generated.resources.create
import nefy.composeapp.generated.resources.downloaded_playlists
import nefy.composeapp.generated.resources.favorite_playlists
import nefy.composeapp.generated.resources.favorite_podcasts
import nefy.composeapp.generated.resources.library
import nefy.composeapp.generated.resources.mix_for_you
import nefy.composeapp.generated.resources.no_YouTube_playlists
import nefy.composeapp.generated.resources.no_charts_found
import nefy.composeapp.generated.resources.no_favorite_playlists
import nefy.composeapp.generated.resources.no_favorite_podcasts
import nefy.composeapp.generated.resources.no_mixes_found
import nefy.composeapp.generated.resources.no_playlists_added
import nefy.composeapp.generated.resources.no_playlists_downloaded
import nefy.composeapp.generated.resources.playlist_name
import nefy.composeapp.generated.resources.playlist_name_cannot_be_empty
import nefy.composeapp.generated.resources.your_library
import nefy.composeapp.generated.resources.shared_playlists
import nefy.composeapp.generated.resources.your_playlists
import nefy.composeapp.generated.resources.your_youtube_playlists

@OptIn(ExperimentalMaterial3Api::class, ExperimentalHazeMaterialsApi::class)
@Composable
fun LibraryScreen(
    innerPadding: PaddingValues,
    viewModel: LibraryViewModel = koinViewModel(),
    roomController: ListeningRoomController = koinInject(),
    settingsViewModel: SettingsViewModel = koinViewModel(),
    navController: NavController,
    onScrolling: (onTop: Boolean) -> Unit = {},
) {
    val density = LocalDensity.current

    val loggedIn by viewModel.youtubeLoggedIn.collectAsStateWithLifecycle(initialValue = false)
    val nowPlaying by viewModel.nowPlayingVideoId.collectAsStateWithLifecycle()
    val youTubePlaylist by viewModel.youTubePlaylist.collectAsStateWithLifecycle()
    val youTubeMixForYou by viewModel.youTubeMixForYou.collectAsStateWithLifecycle()
    val listCanvasSong by viewModel.listCanvasSong.collectAsStateWithLifecycle()
    val yourLocalPlaylist by viewModel.yourLocalPlaylist.collectAsStateWithLifecycle()
    val favoritePlaylist by viewModel.favoritePlaylist.collectAsStateWithLifecycle()
    val downloadedPlaylist by viewModel.downloadedPlaylist.collectAsStateWithLifecycle()
    val favoritePodcasts by viewModel.favoritePodcasts.collectAsStateWithLifecycle()
    val chartPlaylists by viewModel.chartPlaylists.collectAsStateWithLifecycle()
    val recentlyAdded by viewModel.recentlyAdded.collectAsStateWithLifecycle()
    val accountThumbnail by viewModel.accountThumbnail.collectAsStateWithLifecycle()
    val socialState by roomController.socialState.collectAsStateWithLifecycle()
    val roomState by roomController.state.collectAsStateWithLifecycle()
    val hazeState =
        rememberHazeState(
            blurEnabled = true,
        )

    var topAppBarHeight by remember {
        mutableStateOf(0.dp)
    }
    var showAddSheet by remember { mutableStateOf(false) }
    var creatingSharedPlaylist by remember { mutableStateOf(false) }
    var pendingSharedPlaylistName by remember { mutableStateOf<String?>(null) }

    val sharedPlaylistItems = remember(socialState.playlists) {
        LocalResource.Success(
            socialState.playlists.map { playlist ->
                SharedPlaylistLibraryItem(
                    playlistId = playlist.id,
                    title = playlist.name,
                    artworkUrl = playlist.coverArtUrl,
                    ownerName = playlist.contributors
                        .firstOrNull { it.userId == playlist.ownerId }
                        ?.displayName
                        ?: "You",
                )
            },
        )
    }

    LaunchedEffect(socialState.playlists, pendingSharedPlaylistName) {
        val name = pendingSharedPlaylistName ?: return@LaunchedEffect
        socialState.playlists.lastOrNull { it.name == name }?.let { createdPlaylist ->
            pendingSharedPlaylistName = null
            navController.navigate(
                FriendsDestination(
                    initialPage = "playlists",
                    playlistId = createdPlaylist.id,
                ),
            )
        }
    }

    LaunchedEffect(nowPlaying) {
        Logger.w("LibraryScreen", "Check nowPlaying: $nowPlaying")
        viewModel.getRecentlyAdded()
    }
    LaunchedEffect(Unit) {
        runCatching { settingsViewModel.syncSelectedNefyIdentity() }
        roomController.loadSocial()
    }

    val chipRowState = rememberScrollState()
    val currentFilter by viewModel.currentScreen.collectAsStateWithLifecycle()

    LaunchedEffect(currentFilter) {
        when (currentFilter) {
            LibraryChipType.YOUTUBE_MUSIC_PLAYLIST -> {
                if (youTubePlaylist.data.isNullOrEmpty()) {
                    viewModel.getYouTubePlaylist()
                }
            }

            LibraryChipType.YOUTUBE_MIX_FOR_YOU -> {
                if (youTubeMixForYou.data.isNullOrEmpty()) {
                    viewModel.getYouTubeMixedForYou()
                }
            }

            LibraryChipType.YOUR_LIBRARY -> {
                viewModel.getCanvasSong()
                viewModel.getRecentlyAdded()
            }

            LibraryChipType.LOCAL_PLAYLIST -> {
                viewModel.getLocalPlaylist()
            }

            LibraryChipType.SHARED_PLAYLIST -> {
                roomController.loadSocial()
            }

            LibraryChipType.FAVORITE_PLAYLIST -> {
                viewModel.getPlaylistFavorite()
            }

            LibraryChipType.DOWNLOADED_PLAYLIST -> {
                viewModel.getDownloadedPlaylist()
            }

            LibraryChipType.FAVORITE_PODCAST -> {
                viewModel.getFavoritePodcasts()
            }

            LibraryChipType.CHART -> {
                if (chartPlaylists.data.isNullOrEmpty()) {
                    viewModel.getChartPlaylists()
                }
            }
        }
    }

    Crossfade(
        modifier = Modifier.hazeSource(hazeState),
        targetState = currentFilter,
    ) { filter ->
        when (filter) {
            LibraryChipType.YOUR_LIBRARY -> {
                val state = rememberLazyListState()
                val isScrollingUp by state.isScrollingUp()
                LaunchedEffect(state) {
                    snapshotFlow { state.firstVisibleItemIndex }
                        .collect {
                            if (it <= 1) {
                                onScrolling.invoke(true)
                            } else {
                                onScrolling.invoke(isScrollingUp)
                            }
                        }
                }
                LazyColumn(
                    contentPadding =
                        innerPadding.copy(
                            top = topAppBarHeight,
                        ),
                    state = state,
                ) {
                    item {
                        LibraryTilingBox(navController)
                    }

                    if (!listCanvasSong.data.isNullOrEmpty()) {
                        item {
                            LibraryItem(
                                state =
                                    LibraryItemState(
                                        type = LibraryItemType.CanvasSong,
                                        data = listCanvasSong.data ?: emptyList(),
                                        isLoading = listCanvasSong is LocalResource.Loading,
                                    ),
                                navController = navController,
                            )
                        }
                    }

                    item {
                        LibraryItem(
                            state =
                                LibraryItemState(
                                    type =
                                        LibraryItemType.RecentlyAdded(
                                            playingVideoId = nowPlaying,
                                        ),
                                    data = recentlyAdded.data ?: emptyList(),
                                    isLoading = recentlyAdded is LocalResource.Loading,
                                ),
                            navController = navController,
                        )
                    }
                    item {
                        EndOfPage()
                    }
                }
            }

            LibraryChipType.YOUTUBE_MUSIC_PLAYLIST -> {
                GridLibraryPlaylist(
                    navController,
                    innerPadding.copy(top = topAppBarHeight),
                    youTubePlaylist,
                    emptyText = Res.string.no_YouTube_playlists,
                    onScrolling = onScrolling,
                ) {
                    viewModel.getYouTubePlaylist()
                }
            }

            LibraryChipType.YOUTUBE_MIX_FOR_YOU -> {
                GridLibraryPlaylist(
                    navController,
                    innerPadding.copy(top = topAppBarHeight),
                    youTubeMixForYou,
                    emptyText = Res.string.no_mixes_found,
                    onScrolling = onScrolling,
                ) {
                    viewModel.getYouTubeMixedForYou()
                }
            }

            LibraryChipType.LOCAL_PLAYLIST -> {
                GridLibraryPlaylist(
                    navController,
                    innerPadding.copy(top = topAppBarHeight),
                    yourLocalPlaylist,
                    onScrolling = onScrolling,
                    emptyText = Res.string.no_playlists_added,
                    createNewPlaylist = {
                        creatingSharedPlaylist = false
                        showAddSheet = true
                    },
                ) {
                    viewModel.getLocalPlaylist()
                }
            }

            LibraryChipType.SHARED_PLAYLIST -> {
                GridLibraryPlaylist(
                    navController = navController,
                    contentPadding = innerPadding.copy(top = topAppBarHeight),
                    data = sharedPlaylistItems,
                    emptyText = Res.string.no_playlists_added,
                    onScrolling = onScrolling,
                    createNewPlaylist = {
                        creatingSharedPlaylist = true
                        showAddSheet = true
                    },
                    onItemClick = { item ->
                        navController.navigate(
                            FriendsDestination(
                                initialPage = "playlists",
                                playlistId = item.playlistId,
                            ),
                        )
                    },
                    onReload = roomController::loadSocial,
                )
            }

            LibraryChipType.FAVORITE_PLAYLIST -> {
                GridLibraryPlaylist(
                    navController,
                    innerPadding.copy(top = topAppBarHeight),
                    favoritePlaylist,
                    emptyText = Res.string.no_favorite_playlists,
                    onScrolling = onScrolling,
                ) {
                    viewModel.getPlaylistFavorite()
                }
            }

            LibraryChipType.DOWNLOADED_PLAYLIST -> {
                GridLibraryPlaylist(
                    navController,
                    innerPadding.copy(top = topAppBarHeight),
                    downloadedPlaylist,
                    emptyText = Res.string.no_playlists_downloaded,
                    onScrolling = onScrolling,
                ) {
                    viewModel.getDownloadedPlaylist()
                }
            }

            LibraryChipType.FAVORITE_PODCAST -> {
                GridLibraryPlaylist(
                    navController,
                    innerPadding.copy(top = topAppBarHeight),
                    favoritePodcasts,
                    emptyText = Res.string.no_favorite_podcasts,
                    onScrolling = onScrolling,
                ) {
                    viewModel.getFavoritePodcasts()
                }
            }

            LibraryChipType.CHART -> {
                GridLibraryPlaylist(
                    navController,
                    innerPadding.copy(top = topAppBarHeight),
                    chartPlaylists,
                    emptyText = Res.string.no_charts_found,
                    onScrolling = onScrolling,
                ) {
                    viewModel.getChartPlaylists()
                }
            }
        }
    }
    val coroutineScope = rememberCoroutineScope()
    if (showAddSheet) {
        var newTitle by remember { mutableStateOf("") }
        val showAddSheetState =
            rememberModalBottomSheetState(
                skipPartiallyExpanded = true,
            )
        val hideEditTitleBottomSheet: () -> Unit =
            {
                coroutineScope.launch {
                    showAddSheetState.hide()
                    showAddSheet = false
                }
            }
        ModalBottomSheet(
            onDismissRequest = { showAddSheet = false },
            sheetState = showAddSheetState,
            containerColor = Color.Transparent,
            contentColor = Color.Transparent,
            dragHandle = null,
            scrimColor = Color.Black.copy(alpha = .5f),
        ) {
            Card(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .wrapContentHeight(),
                shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp),
                colors = CardDefaults.cardColors().copy(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Spacer(modifier = Modifier.height(5.dp))
                    Card(
                        modifier =
                            Modifier
                                .width(60.dp)
                                .height(4.dp),
                        colors =
                            CardDefaults.cardColors().copy(
                                containerColor = MaterialTheme.colorScheme.outline,
                            ),
                        shape = RoundedCornerShape(50),
                    ) {}
                    Spacer(modifier = Modifier.height(5.dp))
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { s -> newTitle = s },
                        label = {
                            Text(text = stringResource(Res.string.playlist_name))
                        },
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp),
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                    TextButton(
                        onClick = {
                            if (newTitle.isBlank()) {
                                viewModel.makeToast(runBlocking { getString(Res.string.playlist_name_cannot_be_empty) })
                            } else {
                                val title = newTitle.trim()
                                if (creatingSharedPlaylist) {
                                    pendingSharedPlaylistName = title
                                    roomController.createPlaylist(title)
                                    roomController.loadSocial()
                                } else {
                                    viewModel.createPlaylist(title)
                                }
                                hideEditTitleBottomSheet()
                            }
                        },
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .align(Alignment.CenterHorizontally),
                    ) {
                        Text(text = stringResource(Res.string.create))
                    }
                }
            }
        }
    }
    Column(
        Modifier
            .background(Color.Transparent)
            .hazeEffect(hazeState, style = HazeMaterials.ultraThin()) {
                blurEnabled = true
            }.onGloballyPositioned { coordinates ->
                topAppBarHeight = with(density) { coordinates.size.height.toDp() }
            },
    ) {
        TopAppBar(
            title = {
                Text(
                    text = stringResource(Res.string.library),
                    style = typo().titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            },
            colors =
                TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                ),
            actions = {
                IconButton(
                    onClick = {
                        navController.navigate(AnalyticsDestination)
                    },
                ) {
                    Box {
                        Icon(SimpIcons.AutoGraph, "Analytics", tint = MaterialTheme.colorScheme.onBackground)
                        Text(
                            "NEW",
                            Modifier.align(Alignment.BottomEnd),
                            style =
                                typo().bodySmall.copy(
                                    fontSize = 5.sp,
                                ),
                        )
                    }
                }
            },
            navigationIcon = {
                AnimatedVisibility(
                    !accountThumbnail.isNullOrEmpty(),
                    modifier = Modifier.padding(horizontal = 12.dp),
                    enter = fadeIn() + expandHorizontally(),
                    exit = fadeOut() + shrinkVertically(),
                ) {
                    AsyncImage(
                        model =
                            ImageRequest
                                .Builder(LocalPlatformContext.current)
                                .data(accountThumbnail)
                                .crossfade(550)
                                .build(),
                        placeholder = rememberVectorPainter(SimpIcons.PeopleAlt),
                        error = rememberVectorPainter(SimpIcons.PeopleAlt),
                        contentDescription = null,
                        modifier =
                            Modifier
                                .size(26.dp)
                                .clip(CircleShape),
                    )
                }
            },
        )
        Row(
            modifier =
                Modifier
                    .horizontalScroll(chipRowState)
                    .padding(horizontal = 15.dp)
                    .padding(bottom = 8.dp)
                    .background(Color.Transparent),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            LibraryChipType.entries.forEach { type ->
                if (type == LibraryChipType.CHART) return@forEach
                if ((type == LibraryChipType.YOUTUBE_MUSIC_PLAYLIST || type == LibraryChipType.YOUTUBE_MIX_FOR_YOU) && !loggedIn) {
                    return@forEach
                }
                Chip(
                    isAnimated = false,
                    isSelected = type == currentFilter,
                    text =
                        when (type) {
                            LibraryChipType.YOUR_LIBRARY -> stringResource(Res.string.your_library)
                            LibraryChipType.YOUTUBE_MUSIC_PLAYLIST -> stringResource(Res.string.your_youtube_playlists)
                            LibraryChipType.YOUTUBE_MIX_FOR_YOU -> stringResource(Res.string.mix_for_you)
                            LibraryChipType.LOCAL_PLAYLIST -> stringResource(Res.string.your_playlists)
                            LibraryChipType.SHARED_PLAYLIST -> stringResource(Res.string.shared_playlists)
                            LibraryChipType.FAVORITE_PLAYLIST -> stringResource(Res.string.favorite_playlists)
                            LibraryChipType.DOWNLOADED_PLAYLIST -> stringResource(Res.string.downloaded_playlists)
                            LibraryChipType.FAVORITE_PODCAST -> stringResource(Res.string.favorite_podcasts)
                            LibraryChipType.CHART -> stringResource(Res.string.chart)
                        },
                ) {
                    viewModel.setCurrentScreen(type)
                }
            }
        }
    }
}


@Composable
private fun SharedPlaylistsLibraryGrid(
    playlists: List<NefySavedPlaylist>,
    contentPadding: PaddingValues,
    errorMessage: String?,
    navController: NavController,
    onScrolling: (Boolean) -> Unit,
    onReload: () -> Unit,
) {
    val gridState = rememberLazyGridState()
    val isScrollingUp by gridState.isScrollingUp()
    LaunchedEffect(gridState) {
        snapshotFlow { gridState.firstVisibleItemIndex }
            .collect { index -> onScrolling(if (index <= 1) true else isScrollingUp) }
    }
    LazyVerticalGrid(
        columns = GridCells.FixedSize(132.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        contentPadding = contentPadding,
        state = gridState,
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(
                    text = "Cloud playlists shared with you",
                    style = typo().titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    text = "Persistent across devices, with contributor attribution and invite links.",
                    style = typo().bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                errorMessage?.let { message ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Shared playlist sync unavailable: $message", modifier = Modifier.weight(1f), style = typo().bodySmall, color = nefySocialPalette().danger)
                        TextButton(onClick = onReload) { Text("Retry") }
                    }
                }
            }
        }
        if (playlists.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(modifier = Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(SimpIcons.PeopleAlt, contentDescription = null, tint = nefySocialPalette().accent, modifier = Modifier.size(42.dp))
                    Text("No shared playlists yet", style = typo().titleMedium, color = MaterialTheme.colorScheme.onBackground)
                    Text("Create or join one from the Friends area.", style = typo().bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { navController.navigate(FriendsDestination(initialPage = "playlists")) }) { Text("Create or join") }
                }
            }
        } else {
            items(playlists, key = { it.id }) { playlist ->
                val artwork = playlist.coverArtUrl ?: playlist.tracks.firstOrNull()?.artworkUrl
                Column(
                    modifier = Modifier.width(132.dp).padding(10.dp).clickable {
                        navController.navigate(FriendsDestination(initialPage = "playlists", playlistId = playlist.id))
                    },
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Box(
                        modifier = Modifier.size(132.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.BottomEnd,
                    ) {
                        if (!artwork.isNullOrBlank()) {
                            AsyncImage(model = artwork, contentDescription = playlist.name, modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)))
                        } else {
                            Icon(SimpIcons.PeopleAlt, contentDescription = null, tint = nefySocialPalette().accent, modifier = Modifier.align(Alignment.Center).size(48.dp))
                        }
                        Surface(shape = RoundedCornerShape(topStart = 8.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)) {
                            Text("${playlist.contributors.size.coerceAtLeast(1)}", style = typo().labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                        }
                    }
                    Text(playlist.name, style = typo().titleSmall, color = MaterialTheme.colorScheme.onBackground, maxLines = 1)
                    Text("${playlist.tracks.size} songs", style = typo().labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) { EndOfPage() }
    }
}

@Composable
private fun CollaborativePlaylistsLibraryCard(
    playlists: List<NefySavedPlaylist>,
    errorMessage: String?,
    onOpen: () -> Unit,
    onRetry: () -> Unit,
) {
    val palette = nefySocialPalette()
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = palette.card),
        shape = RoundedCornerShape(22.dp),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(SimpIcons.PeopleAlt, contentDescription = null, tint = palette.accent)
                Column(modifier = Modifier.weight(1f)) {
                Text("Shared playlists", style = typo().titleMedium, color = palette.primaryText)
                Text(
                    if (playlists.isEmpty()) "Create or join a playlist with friends" else "Shared playlists in your Library",
                    style = typo().bodySmall,
                    color = palette.secondaryText,
                )
                }
                TextButton(onClick = onOpen) {
                    Text(if (playlists.isEmpty()) "Create" else "Open", style = typo().labelLarge, color = palette.accent)
                }
            }
            errorMessage?.let { message ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Social sync unavailable", modifier = Modifier.weight(1f), style = typo().bodySmall, color = palette.danger)
                    TextButton(onClick = onRetry) { Text("Retry", color = palette.accent) }
                }
            }
            if (playlists.isEmpty()) {
                Text("Invite friends, add tracks from Nefy Library, and vote on the order.", style = typo().bodySmall, color = palette.secondaryText)
            }
            playlists.take(3).forEach { playlist ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    playlist.contributors.take(3).forEach { contributor ->
                        if (contributor.avatarUrl.isNullOrBlank()) {
                            Surface(modifier = Modifier.size(28.dp), shape = CircleShape, color = palette.accentContainer) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(contributor.displayName.take(1).uppercase(), color = palette.primaryText, style = typo().labelSmall)
                                }
                            }
                        } else {
                            AsyncImage(model = contributor.avatarUrl, contentDescription = contributor.displayName, modifier = Modifier.size(28.dp).clip(CircleShape))
                        }
                    }
                    Text(playlist.name, modifier = Modifier.weight(1f), style = typo().bodyMedium, color = palette.primaryText, maxLines = 1)
                    Text("${playlist.tracks.size} songs", style = typo().labelSmall, color = palette.secondaryText)
                }
            }
        }
    }
}
