package com.nefy.app.ui.navigation.destination.list

import kotlinx.serialization.Serializable

@Serializable
data class ArtistDestination(
    val channelId: String,
)