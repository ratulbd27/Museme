package com.nefy.app.ui.component

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.nefy.app.ui.icon.Check
import com.nefy.app.ui.icon.FavoriteBorder
import com.nefy.app.ui.icon.MoreVert
import com.nefy.app.ui.icon.Pause
import com.nefy.app.ui.icon.PlayArrow
import com.nefy.app.ui.icon.Repeat
import com.nefy.app.ui.icon.Shuffle
import com.nefy.app.ui.icon.SkipNext
import com.nefy.app.ui.icon.SkipPrevious
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.player.PlayerStyle
import com.nefy.app.ui.theme.typo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerStyleSelectorDrawer(
    selectedStyle: String,
    classicLabel: String,
    pixelLabel: String,
    title: String,
    description: String,
    onStyleSelected: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        tonalElevation = 0.dp,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(top = 8.dp)
                    .size(width = 48.dp, height = 5.dp)
                    .clip(RoundedCornerShape(50))
                    .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f)),
            )
        },
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(start = 20.dp, end = 20.dp, bottom = 24.dp),
        ) {
            Text(
                text = title,
                style = typo().headlineMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = description,
                style = typo().bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(20.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top,
            ) {
                PlayerStylePreviewCard(
                    modifier = Modifier.weight(1f),
                    label = classicLabel,
                    selected = selectedStyle == PlayerStyle.CLASSIC,
                    classic = true,
                    onClick = { onStyleSelected(PlayerStyle.CLASSIC) },
                )
                PlayerStylePreviewCard(
                    modifier = Modifier.weight(1f),
                    label = pixelLabel,
                    selected = selectedStyle == PlayerStyle.PIXEL,
                    classic = false,
                    onClick = { onStyleSelected(PlayerStyle.PIXEL) },
                )
            }
        }
    }
}

@Composable
private fun PlayerStylePreviewCard(
    modifier: Modifier,
    label: String,
    selected: Boolean,
    classic: Boolean,
    onClick: () -> Unit,
) {
    val outlineColor = if (selected) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)
    }
    val previewShape = RoundedCornerShape(20.dp)

    Column(
        modifier = modifier
            .clip(previewShape)
            .border(width = if (selected) 2.dp else 1.dp, color = outlineColor, shape = previewShape)
            .clickable(onClick = onClick)
            .padding(8.dp),
    ) {
        PlayerLayoutPreview(classic = classic)
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                modifier = Modifier.weight(1f),
                text = label,
                style = typo().labelLarge,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
            )
            if (selected) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = SimpIcons.Check,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(17.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayerLayoutPreview(
    classic: Boolean,
) {
    val previewShape = RoundedCornerShape(16.dp)
    val background = if (classic) {
        Brush.verticalGradient(
            listOf(Color(0xFF8C1D16), Color(0xFF190B0B)),
        )
    } else {
        Brush.verticalGradient(
            listOf(Color(0xFF6E414D), Color(0xFF2A1B25)),
        )
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(previewShape)
            .background(background)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(118.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    if (classic) Color(0xFFB3291C) else Color(0xFF4C7880),
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (classic) {
                Box(
                    modifier = Modifier
                        .size(width = 72.dp, height = 92.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFBB927A)),
                )
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = "NEFY",
                        style = typo().titleMedium,
                        color = Color.White,
                    )
                    Text(
                        text = "PIXEL MIX",
                        style = typo().labelSmall,
                        color = Color.White.copy(alpha = 0.8f),
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (classic) "Current track" else "Pixel mix",
                    style = typo().labelMedium,
                    color = Color.White,
                    maxLines = 1,
                )
                Text(
                    text = if (classic) "Nefy player" else "Nefy layout",
                    style = typo().labelSmall,
                    color = Color.White.copy(alpha = 0.7f),
                    maxLines = 1,
                )
            }
            Icon(
                imageVector = if (classic) SimpIcons.FavoriteBorder else SimpIcons.MoreVert,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.9f),
                modifier = Modifier.size(18.dp),
            )
        }
        Spacer(Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.35f)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(if (classic) 0.42f else 0.18f)
                    .height(3.dp)
                    .clip(CircleShape)
                    .background(if (classic) Color.White else Color(0xFFFFC7D4)),
            )
        }
        Spacer(Modifier.height(9.dp))
        if (classic) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PreviewIcon(SimpIcons.Shuffle)
                PreviewIcon(SimpIcons.SkipPrevious)
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = SimpIcons.Pause,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp),
                    )
                }
                PreviewIcon(SimpIcons.SkipNext)
                PreviewIcon(SimpIcons.Repeat)
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PreviewPillIcon(SimpIcons.SkipPrevious)
                PreviewPillIcon(SimpIcons.PlayArrow, emphasized = true)
                PreviewPillIcon(SimpIcons.SkipNext)
            }
        }
    }
}

@Composable
private fun PreviewIcon(icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Icon(
        imageVector = icon,
        contentDescription = null,
        tint = Color.White.copy(alpha = 0.9f),
        modifier = Modifier.size(17.dp),
    )
}

@Composable
private fun RowScope.PreviewPillIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    emphasized: Boolean = false,
) {
    Box(
        modifier = Modifier
            .weight(1f)
            .height(25.dp)
            .clip(CircleShape)
            .background(if (emphasized) Color(0xFFFFD99C) else Color(0xFFFFB4C4)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color(0xFF3D2028),
            modifier = Modifier.size(14.dp),
        )
    }
}
