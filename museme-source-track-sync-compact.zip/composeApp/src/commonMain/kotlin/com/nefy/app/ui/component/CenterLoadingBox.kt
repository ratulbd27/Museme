package com.nefy.app.ui.component

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Branded centered loader used by non-content screens and legacy loading branches.
 * Music-content screens use SongsAlbumsLoadingShimmer with the same mascot treatment.
 */
@Composable
fun CenterLoadingBox(modifier: Modifier) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center,
    ) {
        NefyMascotLoadingBox(
            modifier = Modifier.fillMaxSize(),
            size = 72.dp,
        )
    }
}
