package com.nefy.app.social.listening

import io.ktor.client.HttpClient
import io.ktor.client.engine.cio.CIO
import io.ktor.client.plugins.websocket.DefaultClientWebSocketSession
import io.ktor.client.plugins.websocket.WebSockets
import io.ktor.client.plugins.websocket.webSocketSession
import io.ktor.client.request.header
import io.ktor.http.HttpHeaders
import io.ktor.http.encodeURLParameter
import io.ktor.websocket.Frame
import io.ktor.websocket.close
import io.ktor.websocket.readText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.Json
import kotlin.time.Duration.Companion.seconds

/**
 * Production-shaped transport for the room server. The default Koin binding remains local so the
 * app is usable without a configured backend; inject this implementation with a wss:// endpoint
 * for real cross-device rooms.
 */
class KtorListeningRoomTransport(
    private val endpoint: String,
    private val userId: String,
    private val displayName: String,
    private val authToken: String? = null,
    private val client: HttpClient =
        HttpClient(CIO) {
            install(WebSockets)
        },
) : ListeningRoomTransport {
    private val json =
        Json {
            classDiscriminator = "type"
            encodeDefaults = true
            ignoreUnknownKeys = true
        }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val socketMutex = Mutex()
    private val _events = MutableSharedFlow<ListeningRoomEvent>(replay = 1, extraBufferCapacity = 8)
    override val events = _events.asSharedFlow()

    private val websocketEndpoint =
        endpoint.trim().trimEnd('/').let { configuredEndpoint ->
            when {
                configuredEndpoint.startsWith("https://") -> "wss://${configuredEndpoint.removePrefix("https://")}"
                configuredEndpoint.startsWith("http://") -> "ws://${configuredEndpoint.removePrefix("http://")}"
                configuredEndpoint.startsWith("ws://") || configuredEndpoint.startsWith("wss://") -> configuredEndpoint
                else -> "wss://$configuredEndpoint"
            }
        }
    private var socket: DefaultClientWebSocketSession? = null
    private var receiverJob: Job? = null
    private var reconnectJob: Job? = null
    private var activeRoomCode: String? = null
    private var lastJoinCommand: ListeningRoomCommand? = null
    private var closing = false

    override suspend fun sendSocial(command: NefySocialCommand) {
        socketMutex.withLock {
            closing = false
            if (socket == null || socket?.isActive != true) {
                if (activeRoomCode == null) activeRoomCode = "new"
                connectLocked()
            }
            val currentSocket = socket
            if (currentSocket == null || !currentSocket.isActive) {
                _events.emit(ListeningRoomEvent.Error("Unable to connect to Nefy social services"))
                return
            }
            currentSocket.send(Frame.Text(json.encodeToString(command)))
        }
    }

    override suspend fun send(command: ListeningRoomCommand) {
        when (command) {
            is ListeningRoomCommand.CreateRoom -> {
                activeRoomCode = "new"
                lastJoinCommand = command
                closing = false
                sendAfterConnecting(command)
            }

            is ListeningRoomCommand.JoinRoom -> {
                activeRoomCode = command.roomCode.trim().uppercase()
                lastJoinCommand = command
                closing = false
                sendAfterConnecting(command)
            }

            ListeningRoomCommand.LeaveRoom -> {
                closing = true
                socketMutex.withLock {
                    socket?.send(Frame.Text(json.encodeToString(command)))
                    socket?.close()
                    socket = null
                }
                receiverJob?.cancel()
                reconnectJob?.cancel()
                activeRoomCode = null
                lastJoinCommand = null
                _events.emit(ListeningRoomEvent.ConnectionChanged(ListeningRoomConnection.Disconnected))
            }

            is ListeningRoomCommand.Playback,
            is ListeningRoomCommand.SetTrack,
            is ListeningRoomCommand.EnqueueTrack,
            is ListeningRoomCommand.RemoveQueueTrack,
            is ListeningRoomCommand.InviteFriend,
            is ListeningRoomCommand.SendChat,
            is ListeningRoomCommand.SendReaction,
            ListeningRoomCommand.SkipNext,
            ListeningRoomCommand.SkipPrevious,
            is ListeningRoomCommand.AdvanceQueue,
            is ListeningRoomCommand.SetFollowHost,
            is ListeningRoomCommand.SetRemoteControl,
            -> {
                val currentSocket = socket
                if (currentSocket == null || !currentSocket.isActive) {
                    _events.emit(ListeningRoomEvent.Error("Room connection is not ready"))
                    return
                }
                currentSocket.send(Frame.Text(json.encodeToString(command)))
            }
        }
    }

    private suspend fun sendAfterConnecting(command: ListeningRoomCommand) {
        socketMutex.withLock {
            if (socket == null || socket?.isActive != true) {
                connectLocked()
            }
            val currentSocket = socket
            if (currentSocket == null || !currentSocket.isActive) {
                _events.emit(ListeningRoomEvent.Error("Unable to connect to the listening room"))
                return
            }
            currentSocket.send(Frame.Text(json.encodeToString(command)))
        }
    }

    private suspend fun connectLocked() {
        val roomCode = activeRoomCode ?: return
        _events.emit(ListeningRoomEvent.ConnectionChanged(ListeningRoomConnection.Connecting))
        val url =
            "${websocketEndpoint}/rooms/${roomCode.encodeURLParameter()}" +
                "?userId=${userId.encodeURLParameter()}&displayName=${displayName.encodeURLParameter()}"
        val connectionAttempt =
            runCatching {
                client.webSocketSession(url) {
                    authToken?.trim()?.takeIf { it.isNotEmpty() }?.let { token ->
                        header(HttpHeaders.Authorization, "Bearer $token")
                    }
                }
            }
        val newSocket = connectionAttempt.getOrElse { _ ->
            _events.emit(
                ListeningRoomEvent.Error(
                    "Could not connect to the room server. Check your internet connection and try again.",
                ),
            )
            _events.emit(ListeningRoomEvent.ConnectionChanged(ListeningRoomConnection.Reconnecting))
            scheduleReconnect()
            return
        }
        socket = newSocket
        _events.emit(ListeningRoomEvent.ConnectionChanged(ListeningRoomConnection.Connected))
        receiverJob?.cancel()
        receiverJob = scope.launch { receiveLoop(newSocket) }
    }

    private suspend fun receiveLoop(currentSocket: DefaultClientWebSocketSession) {
        try {
            currentSocket.incoming.receiveAsFlow().collect { frame ->
                if (frame !is Frame.Text) return@collect
                val event = runCatching { json.decodeFromString<ListeningRoomEvent>(frame.readText()) }.getOrNull()
                if (event == null) {
                    _events.emit(ListeningRoomEvent.Error("Received an invalid room event"))
                } else {
                    _events.emit(
                        when (event) {
                            is ListeningRoomEvent.Snapshot -> {
                                event.state.roomCode?.let { resolvedCode ->
                                    activeRoomCode = resolvedCode
                                    if (lastJoinCommand is ListeningRoomCommand.CreateRoom) {
                                        lastJoinCommand =
                                            ListeningRoomCommand.JoinRoom(
                                                roomCode = resolvedCode,
                                                displayName = (lastJoinCommand as ListeningRoomCommand.CreateRoom).displayName,
                                            )
                                    }
                                }
                                event.copy(state = event.state.copy(connection = ListeningRoomConnection.Connected))
                            }
                            else -> event
                        },
                    )
                }
            }
        } catch (error: Throwable) {
            if (!closing) {
                _events.emit(ListeningRoomEvent.Error(error.message ?: "Room connection lost"))
            }
        } finally {
            if (socket === currentSocket) socket = null
            if (!closing && activeRoomCode != null) {
                _events.emit(ListeningRoomEvent.ConnectionChanged(ListeningRoomConnection.Reconnecting))
                scheduleReconnect()
            }
        }
    }

    private fun scheduleReconnect() {
        if (reconnectJob?.isActive == true) return
        reconnectJob =
            scope.launch {
                var attempt = 0
                while (isActive && !closing && activeRoomCode != null && socket == null && attempt < 6) {
                    delay((1L shl attempt.coerceAtMost(4)).coerceAtMost(30L).seconds)
                    socketMutex.withLock {
                        if (socket == null && !closing) {
                            connectLocked()
                            lastJoinCommand?.let { command -> socket?.send(Frame.Text(json.encodeToString(command))) }
                        }
                    }
                    attempt += 1
                }
            }
    }

}
