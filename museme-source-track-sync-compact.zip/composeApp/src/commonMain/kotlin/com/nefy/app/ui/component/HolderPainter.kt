package com.nefy.app.ui.component

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.painter.Painter
import org.jetbrains.compose.resources.painterResource
import nefy.composeapp.generated.resources.Res
import nefy.composeapp.generated.resources.nefy_icon

/**
 * Nefy-branded artwork placeholder used whenever a remote thumbnail is missing or fails to load.
 * The `isVideo` parameter remains for call-site compatibility; missing artwork is intentionally
 * branded consistently across audio and video surfaces.
 */
@Composable
fun rememberHolderPainter(isVideo: Boolean = false): Painter = painterResource(Res.drawable.nefy_icon)
