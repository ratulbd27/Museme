package com.nefy.app.ui.component

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.graphics.painter.Painter

/**
 * Neutral artwork fallback used when a remote thumbnail is missing or fails to load.
 * The `isVideo` parameter remains for call-site compatibility. Loading surfaces use
 * content-shaped shimmer components instead of displaying a mascot image.
 */
@Composable
fun rememberHolderPainter(isVideo: Boolean = false): Painter = ColorPainter(Color.Transparent)
