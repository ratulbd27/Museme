package com.nefy.app.social.listening

import com.maxrave.domain.manager.DataStoreManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlin.random.Random

/** Stable device-local identity used by Nefy rooms and private social data. */
class NefyIdentity(
    private val dataStoreManager: DataStoreManager,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val userId: String
    var displayName: String
        private set
    var handle: String
        private set
    var bio: String
        private set
    var youtubeAccountKey: String?
        private set

    init {
        val storedUserId = runBlocking {
            dataStoreManager.getString(USER_ID_KEY).first().orEmpty()
        }
        userId = storedUserId.ifBlank {
            "guest-${Random.nextInt(100_000, 999_999)}".also { generated ->
                runBlocking { dataStoreManager.putString(USER_ID_KEY, generated) }
            }
        }

        displayName = runBlocking {
            dataStoreManager.getString(DISPLAY_NAME_KEY).first().orEmpty()
        }.ifBlank { DEFAULT_DISPLAY_NAME }
        val storedHandle = runBlocking {
            dataStoreManager.getString(HANDLE_KEY).first().orEmpty()
        }
        handle = storedHandle.takeIf { it.isNotBlank() && it != LEGACY_DEFAULT_HANDLE } ?: run {
            "nefy-${userId.removePrefix("guest-").takeLast(8).lowercase()}".also { generated ->
                runBlocking { dataStoreManager.putString(HANDLE_KEY, generated) }
            }
        }
        bio = runBlocking {
            dataStoreManager.getString(BIO_KEY).first().orEmpty()
        }
        youtubeAccountKey = runBlocking {
            dataStoreManager.getString(YOUTUBE_ACCOUNT_KEY).first().orEmpty()
        }.takeIf { it.isNotBlank() }
    }

    fun setDisplayName(value: String) {
        setProfile(value, handle, bio)
    }

    /**
     * Links the social identity to the currently selected YouTube account without storing its
     * email or cookies in the social transport. The resulting key is deterministic for the same
     * account and survives app reinstalls once the account is connected again.
     */
    fun linkYouTubeAccount(email: String?, pageId: String?) {
        val source = email?.trim().orEmpty().ifBlank { pageId?.trim().orEmpty() }
        if (source.isBlank()) return
        val key = stableYouTubeAccountKey(source)
        if (youtubeAccountKey == key) return
        youtubeAccountKey = key
        scope.launch { dataStoreManager.putString(YOUTUBE_ACCOUNT_KEY, key) }
    }

    fun setProfile(displayNameValue: String, handleValue: String, bioValue: String) {
        val safeDisplayName = displayNameValue.trim().take(MAX_DISPLAY_NAME_LENGTH)
        val safeHandle = normalizeHandle(handleValue)
        val safeBio = bioValue.trim().take(MAX_BIO_LENGTH)
        if (safeDisplayName.isBlank()) return
        val changed = safeDisplayName != displayName || safeHandle != handle || safeBio != bio
        if (!changed) return
        displayName = safeDisplayName
        handle = safeHandle
        bio = safeBio
        scope.launch {
            dataStoreManager.putString(DISPLAY_NAME_KEY, safeDisplayName)
            dataStoreManager.putString(HANDLE_KEY, safeHandle)
            dataStoreManager.putString(BIO_KEY, safeBio)
        }
    }

    private fun stableYouTubeAccountKey(source: String): String {
        var hash = FNV_OFFSET_BASIS
        source.forEach { character ->
            hash = (hash xor character.code.toLong()) * FNV_PRIME
        }
        return "yt-${hash.toULong().toString(16).padStart(16, '0')}"
    }

    private fun normalizeHandle(value: String): String {
        return value.trim().removePrefix("@").lowercase()
            .replace(Regex("[^a-z0-9_.-]"), "")
            .take(MAX_HANDLE_LENGTH)
            .ifBlank { "nefy-${userId.removePrefix("guest-").takeLast(8).lowercase()}" }
    }

    private companion object {
        const val USER_ID_KEY = "nefy_social_user_id"
        const val DISPLAY_NAME_KEY = "nefy_social_display_name"
        const val HANDLE_KEY = "nefy_social_handle"
        const val BIO_KEY = "nefy_social_bio"
        const val YOUTUBE_ACCOUNT_KEY = "nefy_linked_youtube_account"
        const val FNV_OFFSET_BASIS = -3750763034362895579L
        const val FNV_PRIME = 1099511628211L
        const val DEFAULT_DISPLAY_NAME = "Nefy listener"
        const val LEGACY_DEFAULT_HANDLE = "nefy-listener"
        const val MAX_DISPLAY_NAME_LENGTH = 32
        const val MAX_HANDLE_LENGTH = 24
        const val MAX_BIO_LENGTH = 120
    }
}
