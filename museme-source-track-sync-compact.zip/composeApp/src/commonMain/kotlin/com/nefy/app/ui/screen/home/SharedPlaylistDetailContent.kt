package com.nefy.app.ui.screen.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import com.nefy.app.expect.shareUrl
import com.nefy.app.social.listening.ListeningRoomController
import com.nefy.app.social.listening.ListeningTrack
import com.nefy.app.social.listening.NefySavedPlaylist
import com.nefy.app.ui.icon.Add
import com.nefy.app.ui.icon.MoreVert
import com.nefy.app.ui.icon.Pause
import com.nefy.app.ui.icon.PlayArrow
import com.nefy.app.ui.icon.Share
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.navigation.destination.search.SharedPlaylistSearchDestination
import com.nefy.app.ui.theme.NefySocialPalette
import com.nefy.app.ui.theme.typo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SharedPlaylistDetailContent(
    playlist: NefySavedPlaylist,
    currentUserId: String,
    currentTrack: ListeningTrack?,
    isPlaying: Boolean,
    navController: NavController,
    roomController: ListeningRoomController,
    onPlayTrack: (ListeningTrack) -> Unit,
    onCreateInvite: () -> Unit,
    palette: NefySocialPalette,
) {
    var showMembers by remember { mutableStateOf(false) }
    val gradient = remember(playlist.id, playlist.coverArtUrl) {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFFE7494C),
                Color(0xFF8B5A63),
                palette.pageBackground,
            ),
        )
    }
    val canEdit = playlist.collaborationEnabled && currentUserId.isNotBlank()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(gradient)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = "${playlist.tracks.size} tracks",
                style = typo().bodyMedium,
                color = palette.secondaryText,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = { showMembers = true }) {
                Text("Members", color = palette.primaryText)
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.linearGradient(
                        listOf(palette.accent.copy(alpha = 0.85f), palette.accentContainer),
                    ),
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (playlist.coverArtUrl.isNullOrBlank()) {
                Text(
                    text = playlist.name.take(2).uppercase(),
                    style = typo().displayLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                )
            } else {
                AsyncImage(
                    model = playlist.coverArtUrl,
                    contentDescription = playlist.name,
                    modifier = Modifier.fillMaxWidth().height(250.dp),
                    contentScale = ContentScale.Crop,
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = playlist.name,
                style = typo().headlineLarge,
                fontWeight = FontWeight.Bold,
                color = palette.primaryText,
            )
            Text(
                text = playlist.description.ifBlank { "Shared Nefy playlist" },
                style = typo().titleMedium,
                color = palette.primaryText,
            )
            Text(
                text = "Created by ${playlist.contributors.firstOrNull { it.userId == playlist.ownerId }?.displayName ?: "You"}",
                style = typo().bodyMedium,
                color = palette.secondaryText,
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            FilledTonalButton(
                modifier = Modifier.weight(1f),
                enabled = playlist.tracks.isNotEmpty(),
                onClick = {
                    playlist.tracks.firstOrNull()?.let { track ->
                        onPlayTrack(track.toListeningTrack())
                    }
                },
            ) {
                Icon(
                    imageVector = if (isPlaying) SimpIcons.Pause else SimpIcons.PlayArrow,
                    contentDescription = null,
                )
                Spacer(Modifier.width(8.dp))
                Text(if (isPlaying) "Pause" else "Play")
            }
            OutlinedButton(
                onClick = onCreateInvite,
                border = BorderStroke(1.dp, palette.outline),
            ) {
                Icon(SimpIcons.Share, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Share")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            FilledTonalButton(
                modifier = Modifier.weight(1f),
                onClick = { navController.navigate(SharedPlaylistSearchDestination(playlist.id)) },
            ) {
                Icon(SimpIcons.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Add song")
            }
            OutlinedButton(
                modifier = Modifier.weight(1f),
                onClick = { showMembers = true },
            ) {
                Text("${playlist.contributors.size.coerceAtLeast(1)} contributors")
            }
        }

        Text(
            text = "Sort by: Older first",
            style = typo().labelLarge,
            color = palette.secondaryText,
            modifier = Modifier
                .clip(RoundedCornerShape(18.dp))
                .background(palette.card.copy(alpha = 0.64f))
                .padding(horizontal = 14.dp, vertical = 10.dp),
        )

        if (playlist.tracks.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = palette.card.copy(alpha = 0.7f)),
            ) {
                Text(
                    text = "No songs yet. Add the first one from Search.",
                    modifier = Modifier.padding(18.dp),
                    color = palette.secondaryText,
                )
            }
        } else {
            playlist.tracks.forEach { track ->
                val playableTrack = track.toListeningTrack()
                val canRemove = playlist.ownerId == currentUserId || track.addedBy == currentUserId
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { onPlayTrack(playableTrack) },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    if (track.artworkUrl.isNullOrBlank()) {
                        Surface(
                            modifier = Modifier.size(54.dp),
                            shape = RoundedCornerShape(10.dp),
                            color = palette.accentContainer,
                        ) {
                            Text(
                                text = track.title.take(1).uppercase(),
                                modifier = Modifier.padding(15.dp),
                                color = palette.accent,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    } else {
                        AsyncImage(
                            model = track.artworkUrl,
                            contentDescription = track.title,
                            modifier = Modifier.size(54.dp).clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop,
                        )
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(track.title, style = typo().bodyLarge, color = palette.primaryText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(track.artist, style = typo().bodySmall, color = palette.secondaryText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "Added by ${track.addedByDisplayName ?: "YouTube account"}",
                            style = typo().labelSmall,
                            color = palette.secondaryText,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (canRemove) {
                        TextButton(onClick = { roomController.removePlaylistTrack(playlist.id, track.videoId) }) {
                            Text("Remove", color = palette.danger)
                        }
                    } else {
                        Icon(SimpIcons.MoreVert, contentDescription = null, tint = palette.secondaryText)
                    }
                }
                Divider(color = palette.outline.copy(alpha = 0.45f))
            }
        }

        if (socialInviteAvailable(playlist, roomController)) {
            TextButton(
                onClick = {
                    val code = roomController.socialState.value.lastInviteCode
                    if (!code.isNullOrBlank()) {
                        shareUrl(
                            title = "Join my Nefy playlist",
                            url = "nefy://playlist/$code\nhttps://museme-room-server.onrender.com/playlist/$code",
                        )
                    }
                },
            ) {
                Text("Share invite link", color = palette.accent)
            }
        }
    }

    if (showMembers) {
        ModalBottomSheet(onDismissRequest = { showMembers = false }) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Contributors", style = typo().headlineSmall, color = palette.primaryText)
                if (playlist.contributors.isEmpty()) {
                    Text("You are the owner of this playlist.", color = palette.secondaryText)
                } else {
                    playlist.contributors.forEach { contributor ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Surface(modifier = Modifier.size(38.dp), shape = CircleShape, color = palette.accentContainer) {
                                Text(contributor.displayName.take(1).uppercase(), modifier = Modifier.padding(10.dp), color = palette.accent)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(contributor.displayName, color = palette.primaryText)
                                Text(contributor.role, style = typo().labelSmall, color = palette.secondaryText)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

private fun socialInviteAvailable(playlist: NefySavedPlaylist, roomController: ListeningRoomController): Boolean =
    roomController.socialState.value.lastInvitePlaylistId == playlist.id &&
        !roomController.socialState.value.lastInviteCode.isNullOrBlank()

private fun com.nefy.app.social.listening.NefyPlaylistTrack.toListeningTrack(): ListeningTrack =
    ListeningTrack(
        videoId = videoId,
        title = title,
        artist = artist,
        artworkUrl = artworkUrl,
        durationMs = durationMs,
    )
