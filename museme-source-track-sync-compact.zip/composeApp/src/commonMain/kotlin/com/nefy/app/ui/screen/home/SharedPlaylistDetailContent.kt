package com.nefy.app.ui.screen.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import com.nefy.app.social.listening.ListeningRoomController
import com.nefy.app.social.listening.ListeningTrack
import com.nefy.app.social.listening.NefySavedPlaylist
import com.nefy.app.ui.icon.Add
import com.nefy.app.ui.icon.AddPhotoAlternate
import com.nefy.app.ui.icon.Delete
import com.nefy.app.ui.icon.Edit
import com.nefy.app.ui.icon.ArrowBackIosNew
import com.nefy.app.ui.icon.MoreVert
import com.nefy.app.ui.icon.Pause
import com.nefy.app.ui.icon.QueueMusic
import com.nefy.app.ui.icon.PlayArrow
import com.nefy.app.ui.icon.Share
import com.nefy.app.ui.icon.Shuffle
import com.nefy.app.ui.icon.Sort
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.navigation.destination.search.SharedPlaylistSearchDestination
import com.nefy.app.ui.theme.NefySocialPalette
import com.nefy.app.ui.theme.typo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SharedPlaylistDetailContent(
    playlist: NefySavedPlaylist,
    currentUserId: String,
    currentTrack: ListeningTrack?,
    isPlaying: Boolean,
    navController: NavController,
    roomController: ListeningRoomController,
    onBack: () -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onCreateInvite: () -> Unit,
    onAddToQueue: () -> Unit,
    onUpdateTitle: (String) -> Unit,
    onUpdateCoverArt: (String?) -> Unit,
    onDelete: () -> Unit,
    palette: NefySocialPalette,
) {
    var showMembers by remember { mutableStateOf(false) }
    var showActions by remember { mutableStateOf(false) }
    var showEditTitle by remember { mutableStateOf(false) }
    var showThumbnailChooser by remember { mutableStateOf(false) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var editedTitle by remember(playlist.name) { mutableStateOf(playlist.name) }
    val canManage = playlist.ownerId == currentUserId
    val gradient = remember(playlist.id, playlist.coverArtUrl, palette.pageBackground) {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFFE7494C),
                Color(0xFFB56A69),
                Color(0xFF3D8374),
                palette.pageBackground,
            ),
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .windowInsetsPadding(WindowInsets.statusBars)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = 152.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(52.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(SimpIcons.ArrowBackIosNew, contentDescription = "Back", tint = Color.White)
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onCreateInvite) {
                Icon(SimpIcons.Share, contentDescription = "Share playlist", tint = Color.White)
            }
            IconButton(onClick = { showActions = true }) {
                Icon(SimpIcons.MoreVert, contentDescription = "Playlist actions", tint = Color.White)
            }
        }

        Column(
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(
                playlist.name,
                style = typo().headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                "Shared playlist",
                style = typo().titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color.White.copy(alpha = 0.94f),
                textAlign = TextAlign.Center,
            )
            Text(
                "Created by ${playlist.contributors.firstOrNull { it.userId == playlist.ownerId }?.displayName ?: "You"}",
                style = typo().bodyMedium,
                color = Color.White.copy(alpha = 0.78f),
                textAlign = TextAlign.Center,
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CompactPlaylistCircleButton(
                enabled = playlist.tracks.isNotEmpty(),
                onClick = { playlist.tracks.shuffled().firstOrNull()?.let { onPlayTrack(it.toListeningTrack()) } },
            ) {
                Icon(SimpIcons.Shuffle, contentDescription = "Shuffle", tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Button(
                onClick = {
                    if (isPlaying) currentTrack?.let(onPlayTrack)
                    else playlist.tracks.firstOrNull()?.let { onPlayTrack(it.toListeningTrack()) }
                },
                enabled = playlist.tracks.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color(0xFF151515),
                    disabledContainerColor = Color.White.copy(alpha = 0.25f),
                    disabledContentColor = Color.White.copy(alpha = 0.58f),
                ),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.height(48.dp),
            ) {
                Icon(if (isPlaying) SimpIcons.Pause else SimpIcons.PlayArrow, contentDescription = null, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (isPlaying) "Pause" else "Play", style = typo().labelLarge, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            CompactPlaylistCircleButton(onClick = onCreateInvite) {
                Icon(SimpIcons.Share, contentDescription = "Share", tint = Color.White, modifier = Modifier.size(22.dp))
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${playlist.tracks.size} tracks",
                style = typo().titleMedium,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = { showMembers = true }) {
                Text("Members", color = Color.White, style = typo().labelLarge, fontWeight = FontWeight.Bold)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { roomController.setPlaylistSortMode(playlist.id, if (playlist.sortMode == "ranked") "manual" else "ranked") },
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.32f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.weight(1f),
            ) {
                Icon(SimpIcons.Sort, contentDescription = null, tint = Color.White, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (playlist.sortMode == "ranked") "Sort: Ranked" else "Sort: Older first", color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
            Button(
                onClick = { navController.navigate(SharedPlaylistSearchDestination(playlist.id)) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.18f), contentColor = Color.White),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.weight(0.82f),
            ) {
                Icon(SimpIcons.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(5.dp))
                Text("Add song", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }

        if (playlist.tracks.isEmpty()) {
            Text(
                "No songs yet. Add the first one from Search.",
                modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp),
                style = typo().bodyMedium,
                color = Color.White.copy(alpha = 0.82f),
                textAlign = TextAlign.Center,
            )
        } else {
            playlist.tracks.forEach { track ->
                val playableTrack = track.toListeningTrack()
                val canRemove = canManage || track.addedBy == currentUserId
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { onPlayTrack(playableTrack) }.padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (track.artworkUrl.isNullOrBlank()) {
                        Surface(modifier = Modifier.size(52.dp), shape = RoundedCornerShape(8.dp), color = Color.White.copy(alpha = 0.16f)) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(track.title.take(1).uppercase(), color = Color.White, style = typo().titleLarge, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        AsyncImage(
                            model = track.artworkUrl,
                            contentDescription = track.title,
                            modifier = Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop,
                        )
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Text(track.title, style = typo().bodyLarge, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(track.artist, style = typo().bodySmall, color = Color.White.copy(alpha = 0.82f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Added by ${track.addedByDisplayName ?: "YouTube account"}", style = typo().labelSmall, color = Color.White.copy(alpha = 0.68f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (canRemove) {
                        IconButton(onClick = { roomController.removePlaylistTrack(playlist.id, track.videoId) }) {
                            Icon(SimpIcons.MoreVert, contentDescription = "Remove track", tint = Color.White.copy(alpha = 0.86f))
                        }
                    }
                }
                HorizontalDivider(color = Color.White.copy(alpha = 0.16f))
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("${playlist.contributors.size.coerceAtLeast(1)} contributors", style = typo().bodyMedium, color = Color.White.copy(alpha = 0.78f), modifier = Modifier.weight(1f))
            TextButton(onClick = { showMembers = true }) { Text("View members", color = Color.White, fontWeight = FontWeight.Bold) }
        }
    }

    if (showMembers) {
        ModalBottomSheet(onDismissRequest = { showMembers = false }) {
            Column(modifier = Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Contributors", style = typo().headlineSmall, color = palette.primaryText)
                if (playlist.contributors.isEmpty()) {
                    Text("You are the owner of this playlist.", color = palette.secondaryText)
                } else {
                    playlist.contributors.forEach { contributor ->
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Surface(modifier = Modifier.size(38.dp), shape = CircleShape, color = palette.accentContainer) {
                                Box(contentAlignment = Alignment.Center) { Text(contributor.displayName.take(1).uppercase(), color = palette.accent, fontWeight = FontWeight.Bold) }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(contributor.displayName, color = palette.primaryText)
                                Text(contributor.role, style = typo().labelSmall, color = palette.secondaryText)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    if (showActions) {
        ModalBottomSheet(onDismissRequest = { showActions = false }) {
            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Playlist actions", style = typo().titleLarge, color = palette.primaryText, modifier = Modifier.padding(vertical = 8.dp))
                if (canManage) {
                    SharedPlaylistActionRow(SimpIcons.Edit, "Edit title") { showActions = false; editedTitle = playlist.name; showEditTitle = true }
                    SharedPlaylistActionRow(SimpIcons.AddPhotoAlternate, "Edit thumbnail") { showActions = false; showThumbnailChooser = true }
                }
                SharedPlaylistActionRow(SimpIcons.QueueMusic, "Add to queue") { showActions = false; onAddToQueue() }
                SharedPlaylistActionRow(SimpIcons.Share, "Share playlist") { showActions = false; onCreateInvite() }
                if (canManage) {
                    SharedPlaylistActionRow(SimpIcons.Delete, "Delete playlist", danger = true) { showActions = false; showDeleteConfirmation = true }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    if (showEditTitle) {
        AlertDialog(
            onDismissRequest = { showEditTitle = false },
            title = { Text("Edit playlist title") },
            text = {
                OutlinedTextField(value = editedTitle, onValueChange = { editedTitle = it.take(96) }, singleLine = true, label = { Text("Playlist title") })
            },
            confirmButton = {
                TextButton(enabled = editedTitle.isNotBlank(), onClick = { showEditTitle = false; onUpdateTitle(editedTitle.trim()) }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showEditTitle = false }) { Text("Cancel") } },
        )
    }

    if (showThumbnailChooser) {
        ModalBottomSheet(onDismissRequest = { showThumbnailChooser = false }) {
            Column(modifier = Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Choose playlist artwork", style = typo().headlineSmall, color = palette.primaryText)
                Text("Use artwork from a song in this shared playlist.", style = typo().bodySmall, color = palette.secondaryText)
                playlist.tracks.filter { !it.artworkUrl.isNullOrBlank() }.distinctBy { it.artworkUrl }.forEach { track ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { showThumbnailChooser = false; onUpdateCoverArt(track.artworkUrl) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        AsyncImage(model = track.artworkUrl, contentDescription = null, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
                        Text(track.title, color = palette.primaryText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (playlist.coverArtUrl != null) {
                    TextButton(onClick = { showThumbnailChooser = false; onUpdateCoverArt(null) }) { Text("Remove custom artwork", color = palette.danger) }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { Text("Delete playlist?") },
            text = { Text("This shared playlist and its collaboration history will be removed for everyone.") },
            confirmButton = { TextButton(onClick = { showDeleteConfirmation = false; onDelete() }) { Text("Delete", color = palette.danger) } },
            dismissButton = { TextButton(onClick = { showDeleteConfirmation = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun CompactPlaylistCircleButton(
    enabled: Boolean = true,
    onClick: () -> Unit,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = if (enabled) 0.14f else 0.07f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun SharedPlaylistActionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    danger: Boolean = false,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Icon(icon, contentDescription = null, tint = if (danger) Color(0xFFE85D68) else Color.Unspecified, modifier = Modifier.size(24.dp))
        Text(label, style = typo().bodyLarge, color = if (danger) Color(0xFFE85D68) else Color.Unspecified)
    }
}

private fun com.nefy.app.social.listening.NefyPlaylistTrack.toListeningTrack(): ListeningTrack =
    ListeningTrack(videoId = videoId, title = title, artist = artist, artworkUrl = artworkUrl, durationMs = durationMs)
