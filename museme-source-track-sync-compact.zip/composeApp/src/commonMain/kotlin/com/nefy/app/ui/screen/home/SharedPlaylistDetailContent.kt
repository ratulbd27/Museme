package com.nefy.app.ui.screen.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import com.nefy.app.expect.shareUrl
import com.nefy.app.social.listening.ListeningRoomController
import com.nefy.app.social.listening.ListeningTrack
import com.nefy.app.social.listening.NefySavedPlaylist
import com.nefy.app.ui.icon.Add
import com.nefy.app.ui.icon.ArrowBackIosNew
import com.nefy.app.ui.icon.MoreVert
import com.nefy.app.ui.icon.Pause
import com.nefy.app.ui.icon.PlayArrow
import com.nefy.app.ui.icon.Share
import com.nefy.app.ui.icon.Shuffle
import com.nefy.app.ui.icon.Sort
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.navigation.destination.search.SharedPlaylistSearchDestination
import com.nefy.app.ui.theme.NefySocialPalette
import com.nefy.app.ui.theme.typo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SharedPlaylistDetailContent(
    playlist: NefySavedPlaylist,
    currentUserId: String,
    currentTrack: ListeningTrack?,
    isPlaying: Boolean,
    navController: NavController,
    roomController: ListeningRoomController,
    onBack: () -> Unit,
    onPlayTrack: (ListeningTrack) -> Unit,
    onCreateInvite: () -> Unit,
    palette: NefySocialPalette,
) {
    var showMembers by remember { mutableStateOf(false) }
    val gradient = remember(playlist.id, playlist.coverArtUrl, palette.pageBackground) {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFFE7494C),
                Color(0xFFB56A69),
                Color(0xFF3D8374),
                palette.pageBackground,
            ),
        )
    }
    val canRemoveAny = playlist.ownerId == currentUserId
    val contributorCount = playlist.contributors.size.coerceAtLeast(1)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .windowInsetsPadding(WindowInsets.statusBars)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 176.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(56.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(SimpIcons.ArrowBackIosNew, contentDescription = "Back", tint = Color.White)
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onCreateInvite) {
                Icon(SimpIcons.Share, contentDescription = "Share playlist", tint = Color.White)
            }
        }

        Spacer(Modifier.height(20.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                playlist.name,
                style = typo().displaySmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                playlist.description.ifBlank { "Shared playlist" },
                style = typo().titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color.White.copy(alpha = 0.96f),
                textAlign = TextAlign.Center,
            )
            Text(
                "Created by ${playlist.contributors.firstOrNull { it.userId == playlist.ownerId }?.displayName ?: "You"}",
                style = typo().bodyLarge,
                color = Color.White.copy(alpha = 0.88f),
                textAlign = TextAlign.Center,
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(
                onClick = {
                    playlist.tracks.shuffled().firstOrNull()?.let { onPlayTrack(it.toListeningTrack()) }
                },
                enabled = playlist.tracks.isNotEmpty(),
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.16f)),
            ) {
                Icon(SimpIcons.Shuffle, contentDescription = "Shuffle", tint = Color.White, modifier = Modifier.size(28.dp))
            }
            Spacer(Modifier.width(14.dp))
            Button(
                onClick = {
                    if (isPlaying) {
                        currentTrack?.let(onPlayTrack)
                    } else {
                        playlist.tracks.firstOrNull()?.let { onPlayTrack(it.toListeningTrack()) }
                    }
                },
                enabled = playlist.tracks.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color(0xFF151515),
                    disabledContainerColor = Color.White.copy(alpha = 0.28f),
                    disabledContentColor = Color.White.copy(alpha = 0.62f),
                ),
                shape = RoundedCornerShape(32.dp),
                modifier = Modifier.height(58.dp),
            ) {
                Icon(
                    if (isPlaying) SimpIcons.Pause else SimpIcons.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(if (isPlaying) "Pause" else "Play", style = typo().titleMedium, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(14.dp))
            IconButton(
                onClick = onCreateInvite,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.16f)),
            ) {
                Icon(SimpIcons.Share, contentDescription = "Share", tint = Color.White, modifier = Modifier.size(28.dp))
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "${playlist.tracks.size} tracks",
                style = typo().titleMedium,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = { showMembers = true }) {
                Text("Members", color = Color.White, style = typo().labelLarge, fontWeight = FontWeight.Bold)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            OutlinedButton(
                onClick = { },
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.34f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                shape = RoundedCornerShape(24.dp),
            ) {
                Icon(SimpIcons.Sort, contentDescription = null, tint = Color.White)
                Spacer(Modifier.width(8.dp))
                Text("Sort: Older first", color = Color.White, fontWeight = FontWeight.SemiBold)
            }
            Button(
                onClick = { navController.navigate(SharedPlaylistSearchDestination(playlist.id)) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White.copy(alpha = 0.18f),
                    contentColor = Color.White,
                ),
                shape = RoundedCornerShape(24.dp),
            ) {
                Icon(SimpIcons.Add, contentDescription = null, tint = Color.White)
                Spacer(Modifier.width(7.dp))
                Text("Add song", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        if (playlist.tracks.isEmpty()) {
            Text(
                "No songs yet. Add the first one from Search.",
                modifier = Modifier.fillMaxWidth().padding(vertical = 22.dp),
                style = typo().bodyLarge,
                color = Color.White.copy(alpha = 0.86f),
                textAlign = TextAlign.Center,
            )
        } else {
            playlist.tracks.forEach { track ->
                val playableTrack = track.toListeningTrack()
                val canRemove = canRemoveAny || track.addedBy == currentUserId
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { onPlayTrack(playableTrack) }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    if (track.artworkUrl.isNullOrBlank()) {
                        Surface(
                            modifier = Modifier.size(56.dp),
                            shape = RoundedCornerShape(8.dp),
                            color = Color.White.copy(alpha = 0.18f),
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    track.title.take(1).uppercase(),
                                    color = Color.White,
                                    style = typo().titleLarge,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                    } else {
                        AsyncImage(
                            model = track.artworkUrl,
                            contentDescription = track.title,
                            modifier = Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop,
                        )
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(track.title, style = typo().bodyLarge, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(track.artist, style = typo().bodyMedium, color = Color.White.copy(alpha = 0.82f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "Added by ${track.addedByDisplayName ?: "YouTube account"}",
                            style = typo().labelSmall,
                            color = Color.White.copy(alpha = 0.72f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (canRemove) {
                        IconButton(onClick = { roomController.removePlaylistTrack(playlist.id, track.videoId) }) {
                            Icon(SimpIcons.MoreVert, contentDescription = "Remove track", tint = Color.White.copy(alpha = 0.9f))
                        }
                    }
                }
                HorizontalDivider(color = Color.White.copy(alpha = 0.20f))
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                "$contributorCount contributors",
                style = typo().bodyMedium,
                color = Color.White.copy(alpha = 0.84f),
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = { showMembers = true }) {
                Text("View members", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showMembers) {
        ModalBottomSheet(onDismissRequest = { showMembers = false }) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Contributors", style = typo().headlineSmall, color = palette.primaryText)
                if (playlist.contributors.isEmpty()) {
                    Text("You are the owner of this playlist.", color = palette.secondaryText)
                } else {
                    playlist.contributors.forEach { contributor ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Surface(modifier = Modifier.size(38.dp), shape = CircleShape, color = palette.accentContainer) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(contributor.displayName.take(1).uppercase(), color = palette.accent, fontWeight = FontWeight.Bold)
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(contributor.displayName, color = palette.primaryText)
                                Text(contributor.role, style = typo().labelSmall, color = palette.secondaryText)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

private fun com.nefy.app.social.listening.NefyPlaylistTrack.toListeningTrack(): ListeningTrack =
    ListeningTrack(
        videoId = videoId,
        title = title,
        artist = artist,
        artworkUrl = artworkUrl,
        durationMs = durationMs,
    )
