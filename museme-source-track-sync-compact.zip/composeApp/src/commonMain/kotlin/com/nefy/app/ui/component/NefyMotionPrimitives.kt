package com.nefy.app.ui.component

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer

private val NefyTapSpring = spring<Float>(
    dampingRatio = Spring.DampingRatioMediumBouncy,
    stiffness = Spring.StiffnessMedium,
)

/**
 * Shared tap feedback for the experimental Nefy UI. It is deliberately a modifier
 * rather than a replacement for existing buttons, so stable player surfaces remain
 * untouched until they are explicitly migrated.
 */
fun Modifier.nefyPressScale(
    pressedScale: Float = 0.96f,
    pressedAlpha: Float = 0.92f,
    interactionSource: MutableInteractionSource? = null,
): Modifier = composed {
    val source = interactionSource ?: remember { MutableInteractionSource() }
    val isPressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) pressedScale else 1f,
        animationSpec = NefyTapSpring,
        label = "nefyTapScale",
    )
    val alpha by animateFloatAsState(
        targetValue = if (isPressed) pressedAlpha else 1f,
        animationSpec = androidx.compose.animation.core.tween(NefyExpressiveMotion.short),
        label = "nefyTapAlpha",
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
            this.alpha = alpha
        }
}

@Composable
fun rememberNefyInteractionSource(): MutableInteractionSource = remember { MutableInteractionSource() }
