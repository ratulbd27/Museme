package com.nefy.app.ui.component

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nefy.app.ui.icon.Done
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.theme.nefySocialPalette
import com.nefy.app.ui.theme.typo

@Composable
fun Chip(
    isAnimated: Boolean = false,
    isSelected: Boolean = false,
    text: String,
    onClick: () -> Unit,
) {
    val palette = nefySocialPalette()
    val interactionSource = rememberNefyInteractionSource()
    val containerColor = if (isSelected) palette.accent else palette.cardElevated
    val contentColor = if (isSelected) palette.pageBackground else palette.primaryText

    Surface(
        modifier = Modifier
            .height(56.dp)
            .nefyPressScale(interactionSource = interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                role = Role.Tab,
                onClick = onClick,
            )
            .semantics { role = Role.Tab },
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(50.dp),
        tonalElevation = if (isSelected) 2.dp else 0.dp,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AnimatedContent(
                targetState = isSelected,
                label = "chipSelectionIcon",
            ) { selected ->
                if (selected) {
                    Icon(
                        imageVector = SimpIcons.Done,
                        contentDescription = null,
                    )
                }
            }
            Text(
                text = text,
                style = typo().titleMedium,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = contentColor,
                maxLines = 1,
            )
        }
    }
}
