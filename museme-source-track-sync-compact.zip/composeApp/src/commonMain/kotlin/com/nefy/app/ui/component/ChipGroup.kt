package com.nefy.app.ui.component

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nefy.app.ui.icon.Done
import com.nefy.app.ui.icon.SimpIcons
import com.nefy.app.ui.theme.nefySocialPalette
import com.nefy.app.ui.theme.typo

@Composable
fun Chip(
    isAnimated: Boolean = false,
    isSelected: Boolean = false,
    text: String,
    large: Boolean = false,
    onClick: () -> Unit,
) {
    val palette = nefySocialPalette()
    val interactionSource = rememberNefyInteractionSource()
    val containerColor = if (isSelected) palette.accent else palette.cardElevated
    val contentColor = if (isSelected) palette.pageBackground else palette.primaryText
    val pillHeight = if (large) 56.dp else 40.dp
    val pillRadius = if (large) 28.dp else 20.dp
    val horizontalPadding = if (large) 20.dp else 16.dp
    val contentSpacing = if (large) 8.dp else 6.dp

    Surface(
        modifier = Modifier
            .height(pillHeight)
            .nefyPressScale(interactionSource = interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                role = Role.Tab,
                onClick = onClick,
            )
            .semantics { role = Role.Tab },
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(pillRadius),
        tonalElevation = if (isSelected) 2.dp else 0.dp,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = horizontalPadding),
            horizontalArrangement = Arrangement.spacedBy(contentSpacing),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AnimatedContent(
                targetState = isSelected,
                label = "chipSelectionIcon",
            ) { selected ->
                if (selected) {
                    Icon(
                        imageVector = SimpIcons.Done,
                        contentDescription = null,
                        modifier = Modifier.size(if (large) 20.dp else 18.dp),
                    )
                }
            }
            Text(
                text = text,
                style = if (large) typo().titleMedium else typo().labelLarge,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = contentColor,
                maxLines = 1,
            )
        }
    }
}
