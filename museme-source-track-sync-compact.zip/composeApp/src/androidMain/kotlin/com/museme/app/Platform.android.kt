package com.museme.app

actual fun getPlatform(): Platform = Platform.Android