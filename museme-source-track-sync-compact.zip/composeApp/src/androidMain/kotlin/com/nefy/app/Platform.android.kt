package com.nefy.app

actual fun getPlatform(): Platform = Platform.Android