package com.museme.app

import platform.UIKit.UIDevice
actual fun getPlatform(): Platform = Platform.iOS