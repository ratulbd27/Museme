package com.nefy.app

import platform.UIKit.UIDevice
actual fun getPlatform(): Platform = Platform.iOS