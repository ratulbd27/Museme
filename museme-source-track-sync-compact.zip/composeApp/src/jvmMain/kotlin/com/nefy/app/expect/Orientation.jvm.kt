package com.nefy.app.expect

actual fun currentOrientation(): Orientation = Orientation.LANDSCAPE