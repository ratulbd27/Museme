package com.nefy.app.expect

actual fun getDownloadFolderPath(): String = System.getProperty("user.home") + "/Downloads"