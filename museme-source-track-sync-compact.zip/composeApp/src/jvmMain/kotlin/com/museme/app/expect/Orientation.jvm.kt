package com.museme.app.expect

actual fun currentOrientation(): Orientation = Orientation.LANDSCAPE