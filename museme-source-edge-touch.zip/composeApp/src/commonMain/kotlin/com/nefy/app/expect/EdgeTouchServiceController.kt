package com.nefy.app.expect

/** Bind the Android activity/application context used by the optional edge-touch service. */
expect fun bindEdgeTouchServiceContext(context: Any)

/** Reconcile the Android service with the persisted edge-touch and notification-pill settings. */
expect fun syncEdgeTouchService()

/** Open the platform settings page needed for system edge-touch controls, when supported. */
expect fun openEdgeTouchPermission()
