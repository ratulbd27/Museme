package com.nefy.app.expect

import androidx.compose.runtime.Composable

@Composable
expect fun NefyBackHandler(
    enabled: Boolean,
    onBack: () -> Unit,
)
