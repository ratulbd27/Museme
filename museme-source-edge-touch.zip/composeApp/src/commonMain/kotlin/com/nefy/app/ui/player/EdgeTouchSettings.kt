package com.nefy.app.ui.player

/**
 * User-configurable actions for the optional edge/notch touch surface.
 * The contract lives in common code; Android owns the system overlay and notification plumbing.
 */
enum class EdgeTouchAction(
    val wireValue: String,
) {
    PREVIOUS("previous"),
    NEXT("next"),
    PLAY_PAUSE("play_pause"),
    NONE("none"),
    ;

    companion object {
        fun fromWireValue(value: String?): EdgeTouchAction =
            entries.firstOrNull { it.wireValue == value } ?: NEXT
    }
}

object EdgeTouchSettings {
    const val ENABLED_KEY = "nefy_edge_touch_enabled"
    const val NOTIFICATION_PILL_ENABLED_KEY = "nefy_notification_pill_enabled"
    const val LEFT_ACTION_KEY = "nefy_edge_touch_left_action"
    const val RIGHT_ACTION_KEY = "nefy_edge_touch_right_action"
    const val OVERLAY_PERMISSION_GUIDE_KEY = "nefy_edge_touch_overlay_guide_seen"

    const val DEFAULT_LEFT_ACTION = "previous"
    const val DEFAULT_RIGHT_ACTION = "next"
}

fun EdgeTouchAction.displayName(): String =
    when (this) {
        EdgeTouchAction.PREVIOUS -> "Previous track"
        EdgeTouchAction.NEXT -> "Next track"
        EdgeTouchAction.PLAY_PAUSE -> "Play / pause"
        EdgeTouchAction.NONE -> "Disabled"
    }

fun EdgeTouchAction.nextForPicker(): EdgeTouchAction =
    when (this) {
        EdgeTouchAction.PREVIOUS -> EdgeTouchAction.NEXT
        EdgeTouchAction.NEXT -> EdgeTouchAction.PLAY_PAUSE
        EdgeTouchAction.PLAY_PAUSE -> EdgeTouchAction.NONE
        EdgeTouchAction.NONE -> EdgeTouchAction.PREVIOUS
    }
