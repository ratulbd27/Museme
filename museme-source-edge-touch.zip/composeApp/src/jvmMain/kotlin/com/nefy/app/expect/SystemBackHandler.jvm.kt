package com.nefy.app.expect

import androidx.compose.runtime.Composable

@Composable
actual fun NefyBackHandler(
    enabled: Boolean,
    onBack: () -> Unit,
) {
    // Desktop window navigation owns system back behavior.
}
