package com.nefy.app.expect

actual fun bindEdgeTouchServiceContext(context: Any) = Unit

actual fun syncEdgeTouchService() = Unit

actual fun openEdgeTouchPermission() = Unit
