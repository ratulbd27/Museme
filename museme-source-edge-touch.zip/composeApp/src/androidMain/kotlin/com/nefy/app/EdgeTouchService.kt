package com.nefy.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.nefy.app.composeapp.R
import com.nefy.app.ui.player.EdgeTouchAction
import com.nefy.app.ui.player.EdgeTouchSettings
import com.maxrave.domain.manager.DataStoreManager
import com.maxrave.domain.manager.DataStoreManager.Values.TRUE
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject

/**
 * Opt-in Android-only edge controls and a compact ongoing media notification.
 *
 * The service never owns playback state. It connects to Nefy’s existing MediaSession and sends
 * standard Player commands, so the Pixel player, queue, social rooms, and Watch Together remain the
 * source of truth.
 */
class EdgeTouchService : Service() {
    private val dataStoreManager: DataStoreManager by inject()
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val windowManager by lazy { getSystemService(WindowManager::class.java) }
    private val notificationManager by lazy { getSystemService(NotificationManager::class.java) }

    private var controller: MediaController? = null
    private var controllerFuture: com.google.common.util.concurrent.ListenableFuture<MediaController>? = null
    private var settingsJob: Job? = null
    private var leftRail: View? = null
    private var rightRail: View? = null
    private var edgeTouchEnabled = false
    private var notificationPillEnabled = true
    private var leftAction = EdgeTouchSettings.DEFAULT_LEFT_ACTION
    private var rightAction = EdgeTouchSettings.DEFAULT_RIGHT_ACTION

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startAsForeground()
        observeSettings()
        connectToMediaSession()
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int,
    ): Int {
        when (intent?.action) {
            ACTION_PLAY_PAUSE -> controller?.let { if (it.isPlaying) it.pause() else it.play() }
            ACTION_PREVIOUS -> controller?.seekToPreviousMediaItem()
            ACTION_NEXT -> controller?.seekToNextMediaItem()
            ACTION_OPEN_APP -> openApp()
        }
        updateNotification()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun observeSettings() {
        settingsJob?.cancel()
        settingsJob = serviceScope.launch {
            launch {
                dataStoreManager
                    .getString(EdgeTouchSettings.ENABLED_KEY)
                    .map { it == TRUE }
                    .distinctUntilChanged()
                    .collectLatest {
                        edgeTouchEnabled = it
                        reconcileSurface()
                        reconcileLifetime()
                    }
            }
            launch {
                dataStoreManager
                    .getString(EdgeTouchSettings.NOTIFICATION_PILL_ENABLED_KEY)
                    .map { it?.let { value -> value == TRUE } ?: true }
                    .distinctUntilChanged()
                    .collectLatest {
                        notificationPillEnabled = it
                        updateNotification()
                        reconcileLifetime()
                    }
            }
            launch {
                dataStoreManager
                    .getString(EdgeTouchSettings.LEFT_ACTION_KEY)
                    .map { it ?: EdgeTouchSettings.DEFAULT_LEFT_ACTION }
                    .distinctUntilChanged()
                    .collectLatest { leftAction = it }
            }
            launch {
                dataStoreManager
                    .getString(EdgeTouchSettings.RIGHT_ACTION_KEY)
                    .map { it ?: EdgeTouchSettings.DEFAULT_RIGHT_ACTION }
                    .distinctUntilChanged()
                    .collectLatest { rightAction = it }
            }
        }
    }

    private fun reconcileLifetime() {
        if (!edgeTouchEnabled && !notificationPillEnabled) {
            stopSelf()
        }
    }

    private fun connectToMediaSession() {
        val token =
            SessionToken(
                this,
                ComponentName(this, "com.maxrave.media3.service.SimpleMediaService"),
            )
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener(
            {
                runCatching {
                    controller = controllerFuture?.get()
                    controller?.addListener(
                        object : Player.Listener {
                            override fun onIsPlayingChanged(isPlaying: Boolean) = updateNotification()

                            override fun onMediaItemTransition(
                                mediaItem: androidx.media3.common.MediaItem?,
                                reason: Int,
                            ) = updateNotification()

                            override fun onPlaybackStateChanged(playbackState: Int) = updateNotification()
                        },
                    )
                    updateNotification()
                }
            },
            mainExecutor,
        )
    }

    private fun startAsForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        notificationManager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Nefy live player",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Persistent Nefy playback controls"
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            },
        )
    }

    private fun updateNotification() {
        if (!notificationPillEnabled) return
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val current = controller?.currentMediaItem
        val metadata = current?.mediaMetadata
        val title = metadata?.title?.toString()?.takeIf { it.isNotBlank() } ?: "Nefy"
        val artist = metadata?.artist?.toString()?.takeIf { it.isNotBlank() } ?: "Music player"
        val contentIntent =
            PendingIntent.getActivity(
                this,
                REQUEST_OPEN_APP,
                appLaunchIntent(),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )

        val builder =
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.nefy_notification_icon)
                .setContentTitle(title)
                .setContentText(artist)
                .setSubText("Nefy")
                .setContentIntent(contentIntent)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .setOngoing(edgeTouchEnabled || notificationPillEnabled)
                .setAutoCancel(false)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setColor(0xFF77E0C0.toInt())
                .addAction(action(android.R.drawable.ic_media_previous, "Previous", ACTION_PREVIOUS))
                .addAction(
                    action(
                        if (controller?.isPlaying == true) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                        if (controller?.isPlaying == true) "Pause" else "Play",
                        ACTION_PLAY_PAUSE,
                    ),
                )
                .addAction(action(android.R.drawable.ic_media_next, "Next", ACTION_NEXT))

        metadata?.artworkData?.let { bytes ->
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let(builder::setLargeIcon)
        }

        val duration = controller?.duration ?: 0L
        if (duration > 0L) {
            builder.setProgress(duration.toInt().coerceAtMost(Int.MAX_VALUE), controller?.currentPosition?.toInt() ?: 0, false)
        }
        if (Build.VERSION.SDK_INT >= 36) {
            builder.setRequestPromotedOngoing(true)
        }
        return builder.build()
    }

    private fun action(
        icon: Int,
        title: String,
        action: String,
    ): Notification.Action =
        Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(this, icon),
            title,
            PendingIntent.getService(
                this,
                action.hashCode(),
                Intent(this, EdgeTouchService::class.java).setAction(action),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            ),
        ).build()

    private fun reconcileSurface() {
        if (edgeTouchEnabled && Settings.canDrawOverlays(this)) {
            addRailsIfNeeded()
        } else {
            removeRails()
        }
    }

    private fun addRailsIfNeeded() {
        if (leftRail == null) leftRail = createRail(isLeft = true)
        if (rightRail == null) rightRail = createRail(isLeft = false)
    }

    private fun createRail(isLeft: Boolean): View {
        val view = EdgeRailView(this, isLeft)
        val params =
            WindowManager.LayoutParams(
                dp(38),
                dp(210),
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    WindowManager.LayoutParams.TYPE_PHONE
                },
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or if (isLeft) Gravity.START else Gravity.END
                y = dp(52)
                alpha = 0.01f
                title = "Nefy edge touch rail"
            }
        runCatching { windowManager.addView(view, params) }
            .onFailure { if (isLeft) leftRail = null else rightRail = null }
        return view
    }

    private fun removeRails() {
        listOf(leftRail, rightRail).forEach { view ->
            if (view != null) runCatching { windowManager.removeView(view) }
        }
        leftRail = null
        rightRail = null
    }

    private fun dispatchEdgeAction(actionValue: String) {
        when (EdgeTouchAction.fromWireValue(actionValue)) {
            EdgeTouchAction.PREVIOUS -> controller?.seekToPreviousMediaItem()
            EdgeTouchAction.NEXT -> controller?.seekToNextMediaItem()
            EdgeTouchAction.PLAY_PAUSE -> controller?.let { if (it.isPlaying) it.pause() else it.play() }
            EdgeTouchAction.NONE -> Unit
        }
        updateNotification()
    }

    private fun openApp() {
        startActivity(appLaunchIntent())
    }

    private fun appLaunchIntent(): Intent =
        packageManager.getLaunchIntentForPackage(packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        } ?: Intent().apply {
            setClassName(packageName, "$packageName.MainActivity")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        removeRails()
        settingsJob?.cancel()
        controllerFuture?.cancel(false)
        controller?.release()
        serviceScope.cancel()
        super.onDestroy()
    }

    private inner class EdgeRailView(
        context: Context,
        private val isLeft: Boolean,
    ) : View(context) {
        private var downX = 0f
        private var downY = 0f
        private val tapSlop = dp(22)

        init {
            background = ColorDrawable(android.graphics.Color.TRANSPARENT)
            isClickable = true
        }

        override fun performClick(): Boolean {
            super.performClick()
            return true
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (kotlin.math.abs(dx) < tapSlop && kotlin.math.abs(dy) < tapSlop) {
                        dispatchEdgeAction(EdgeTouchAction.PLAY_PAUSE.wireValue)
                    } else if (kotlin.math.abs(dx) >= kotlin.math.abs(dy)) {
                        val mapped = if (dx < 0f) leftAction else rightAction
                        dispatchEdgeAction(mapped)
                    }
                    performClick()
                    return true
                }
                MotionEvent.ACTION_CANCEL -> return true
            }
            return true
        }
    }

    companion object {
        private const val CHANNEL_ID = "nefy_live_player"
        private const val NOTIFICATION_ID = 9042
        private const val REQUEST_OPEN_APP = 9043
        private const val ACTION_PLAY_PAUSE = "com.nefy.app.edge.PLAY_PAUSE"
        private const val ACTION_PREVIOUS = "com.nefy.app.edge.PREVIOUS"
        private const val ACTION_NEXT = "com.nefy.app.edge.NEXT"
        private const val ACTION_OPEN_APP = "com.nefy.app.edge.OPEN_APP"
    }
}
