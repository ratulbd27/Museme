package com.nefy.app.expect

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.nefy.app.EdgeTouchService

private var edgeServiceContext: Context? = null

actual fun bindEdgeTouchServiceContext(context: Any) {
    edgeServiceContext = (context as? Context)?.applicationContext
}

actual fun syncEdgeTouchService() {
    val context = edgeServiceContext ?: return
    runCatching {
        ContextCompat.startForegroundService(
            context,
            Intent(context, EdgeTouchService::class.java),
        )
    }
}

actual fun openEdgeTouchPermission() {
    val context = edgeServiceContext ?: return
    runCatching {
        context.startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}"),
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}
