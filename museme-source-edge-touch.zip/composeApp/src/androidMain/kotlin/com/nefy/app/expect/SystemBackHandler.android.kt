package com.nefy.app.expect

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable

@Composable
actual fun NefyBackHandler(
    enabled: Boolean,
    onBack: () -> Unit,
) {
    BackHandler(enabled = enabled, onBack = onBack)
}
